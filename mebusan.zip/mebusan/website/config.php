<?php
/**
 * Mebusan · Master Configuration
 * All credentials live here. Loaded by every API endpoint.
 */

// ── Environment ────────────────────────────────────────────────
define('MB_ENV', 'production');
define('MB_DEBUG', false);
define('MB_SITE_URL', 'https://mebusan.com');
define('MB_CONTACT_EMAIL', 'k.a@mebusan.com');
define('MB_COMPANY_NAME', 'MEBUSAN AI PTE LTD');
define('MB_COMPANY_UEN', ''); // Add after ACRA registration
define('MB_FOUNDED', '2026');

// ── Anthropic (signals, briefings, blog) ───────────────────────
define('ANTHROPIC_API_KEY', getenv('ANTHROPIC_API_KEY') ?: '');
define('ANTHROPIC_MODEL', 'claude-sonnet-4-5');

// ── Stripe ─────────────────────────────────────────────────────
define('STRIPE_PUBLISHABLE_KEY', getenv('STRIPE_PUBLISHABLE_KEY') ?: '');
define('STRIPE_SECRET_KEY',      getenv('STRIPE_SECRET_KEY')      ?: '');
define('STRIPE_WEBHOOK_SECRET',  getenv('STRIPE_WEBHOOK_SECRET')  ?: '');
define('STRIPE_PRICE_MONITOR_MONTHLY',  getenv('STRIPE_PRICE_MONITOR_MONTHLY')  ?: '');
define('STRIPE_PRICE_MONITOR_ANNUAL',   getenv('STRIPE_PRICE_MONITOR_ANNUAL')   ?: '');
define('STRIPE_PRICE_ADVISORY_MONTHLY', getenv('STRIPE_PRICE_ADVISORY_MONTHLY') ?: '');
define('STRIPE_PRICE_ADVISORY_ANNUAL',  getenv('STRIPE_PRICE_ADVISORY_ANNUAL')  ?: '');
define('STRIPE_PRICE_PRIVATE_MONTHLY',  getenv('STRIPE_PRICE_PRIVATE_MONTHLY')  ?: '');
define('STRIPE_PRICE_PRIVATE_ANNUAL',   getenv('STRIPE_PRICE_PRIVATE_ANNUAL')   ?: '');

// ── Twilio (alerts) — ROTATE old compromised token before live ─
define('TWILIO_ACCOUNT_SID', getenv('TWILIO_ACCOUNT_SID') ?: '');
define('TWILIO_AUTH_TOKEN',  getenv('TWILIO_AUTH_TOKEN')  ?: '');
define('TWILIO_PHONE',       getenv('TWILIO_PHONE')       ?: '');

// ── Apple Sign In ──────────────────────────────────────────────
define('APPLE_CLIENT_ID',    'com.mebusan.app');
define('APPLE_TEAM_ID',      getenv('APPLE_TEAM_ID')          ?: '');
define('APPLE_KEY_ID',       getenv('APPLE_KEY_ID')           ?: '');
define('APPLE_PRIVATE_KEY',  getenv('APPLE_PRIVATE_KEY_PATH') ?: '');

// ── hCaptcha ───────────────────────────────────────────────────
define('HCAPTCHA_SITE_KEY', getenv('HCAPTCHA_SITE_KEY') ?: '');
define('HCAPTCHA_SECRET',   getenv('HCAPTCHA_SECRET')   ?: '');

// ── Admin ──────────────────────────────────────────────────────
define('ADMIN_PASSWORD_HASH',  getenv('ADMIN_PASSWORD_HASH')  ?: '');
define('ADMIN_SESSION_SECRET', getenv('ADMIN_SESSION_SECRET') ?: 'change-me-in-production');

/**
 * TIER DEFINITIONS — single source of truth for all pricing
 */
$MEBUSAN_TIERS = [
    'monitor' => [
        'name' => 'Monitor',
        'monthly' => 290,
        'annual_per_month' => 245,
        'annual_total' => 2940,
        'jurisdictions' => 4,
        'response_hours' => 48,
        'briefing_frequency' => 'weekly',
        'analyst_contact' => false,
        'direct_line' => false,
        'human_required' => false,
        'stripe_monthly' => STRIPE_PRICE_MONITOR_MONTHLY,
        'stripe_annual'  => STRIPE_PRICE_MONITOR_ANNUAL,
        'features' => [
            'Up to 4 jurisdictions',
            'Weekly structured briefing',
            'Threshold alerts, automated',
            'Portal and app access',
            '48 hour response',
        ],
    ],
    'advisory' => [
        'name' => 'Advisory',
        'monthly' => 690,
        'annual_per_month' => 585,
        'annual_total' => 7020,
        'jurisdictions' => 8,
        'response_hours' => 24,
        'briefing_frequency' => 'weekly',
        'analyst_contact' => true,
        'direct_line' => false,
        'human_required' => false,
        'stripe_monthly' => STRIPE_PRICE_ADVISORY_MONTHLY,
        'stripe_annual'  => STRIPE_PRICE_ADVISORY_ANNUAL,
        'features' => [
            'Up to 8 jurisdictions',
            'Weekly briefing + real-time alerts',
            'Named analyst contact',
            'Scenario modelling per jurisdiction',
            '24 hour response',
        ],
    ],
    'private' => [
        'name' => 'Private',
        'monthly' => 1200,
        'annual_per_month' => 1020,
        'annual_total' => 12240,
        'jurisdictions' => 999,
        'response_hours' => 4,
        'briefing_frequency' => 'daily',
        'analyst_contact' => true,
        'direct_line' => true,
        'human_required' => true,
        'stripe_monthly' => STRIPE_PRICE_PRIVATE_MONTHLY,
        'stripe_annual'  => STRIPE_PRICE_PRIVATE_ANNUAL,
        'features' => [
            'Unlimited jurisdictions',
            'Daily brief, dedicated analyst',
            'Direct line, phone and Signal',
            'Quarterly strategic review',
            'Emergency protocol access',
        ],
    ],
];

/**
 * AUTO-TIER RULES — applicants routed automatically based on this
 */
function mebusan_auto_tier($jurisdiction_count, $concern_level, $contact_preference) {
    if ($contact_preference === 'dedicated') return 'private';
    if ($concern_level === 'high' && $jurisdiction_count >= 8) return 'private';
    if ($contact_preference === 'alert' || $jurisdiction_count >= 5) return 'advisory';
    return 'monitor';
}

/**
 * PATHS
 */
define('MB_ROOT',        __DIR__);
define('MB_CACHE_DIR',   MB_ROOT . '/cache');
define('MB_CACHE_BLOG',  MB_CACHE_DIR . '/blog');
define('MB_CACHE_FOREX', MB_CACHE_DIR . '/forex');
define('MB_CACHE_INTEL', MB_CACHE_DIR . '/intel');
define('MB_CACHE_RISK',  MB_CACHE_DIR . '/risk');
define('MB_CACHE_ALERTS',MB_CACHE_DIR . '/alerts');
define('MB_CACHE_KA',    MB_CACHE_DIR . '/ka');
define('MB_DATA_DIR',    MB_ROOT . '/data');
define('MB_LOGS_DIR',    MB_ROOT . '/logs');

foreach ([MB_CACHE_BLOG, MB_CACHE_FOREX, MB_CACHE_INTEL, MB_CACHE_RISK, MB_CACHE_ALERTS, MB_CACHE_KA, MB_DATA_DIR, MB_LOGS_DIR] as $_d) {
    if (!is_dir($_d)) @mkdir($_d, 0755, true);
}

// ── Helpers ────────────────────────────────────────────────────
function mb_log($channel, $msg) {
    $line = '[' . date('Y-m-d H:i:s') . "] [$channel] $msg\n";
    @file_put_contents(MB_LOGS_DIR . '/' . $channel . '.log', $line, FILE_APPEND);
}

function mb_json($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function mb_client_id() {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $id = 'MB-';
    for ($i = 0; $i < 4; $i++) $id .= $chars[random_int(0, 31)];
    $id .= '-';
    for ($i = 0; $i < 4; $i++) $id .= $chars[random_int(0, 31)];
    return $id;
}

function mb_tier_for_price($price_id) {
    if (!$price_id) return null;
    if ($price_id === STRIPE_PRICE_MONITOR_MONTHLY  || $price_id === STRIPE_PRICE_MONITOR_ANNUAL)  return 'monitor';
    if ($price_id === STRIPE_PRICE_ADVISORY_MONTHLY || $price_id === STRIPE_PRICE_ADVISORY_ANNUAL) return 'advisory';
    if ($price_id === STRIPE_PRICE_PRIVATE_MONTHLY  || $price_id === STRIPE_PRICE_PRIVATE_ANNUAL)  return 'private';
    return null;
}
