<?php
/**
 * MEBUSAN — Alert Dispatcher
 * Sends email alerts when risk thresholds are breached
 * Monitors: currency devaluation, GDACS events, OFAC changes, news keywords
 *
 * POST /api/alerts.php { type, data }
 * GET  /api/alerts.php?run=1 (cron: check all thresholds)
 * GET  /api/alerts.php?history=1 (recent alerts log)
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

define('CACHE_DIR', __DIR__ . '/../cache/alerts/');
define('ALERT_LOG',  __DIR__ . '/../cache/alerts/alert_log.json');
define('SMTP_FROM',  'alerts@mebusan.com');
define('SMTP_NAME',  'Mebusan Intelligence');

// Email config — configure SMTP in production
// For Hostinger: use PHP mail() or configure SMTP via phpmailer
define('USE_SMTP', false); // Set true and configure below for SMTP
define('SMTP_HOST', 'smtp.mebusan.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'alerts@mebusan.com');
define('SMTP_PASS', 'YOUR_SMTP_PASSWORD'); // Set in production

if (!is_dir(CACHE_DIR)) mkdir(CACHE_DIR, 0755, true);

function loadLog() {
  if (!file_exists(ALERT_LOG)) return [];
  return json_decode(file_get_contents(ALERT_LOG), true) ?? [];
}
function saveLog($log) {
  file_put_contents(ALERT_LOG, json_encode(array_slice($log, -1000))); // keep last 1000
}

function sendAlert($to, $subject, $body, $priority = 'normal') {
  $headers = [
    'From: ' . SMTP_NAME . ' <' . SMTP_FROM . '>',
    'X-Priority: ' . ($priority === 'high' ? '1' : '3'),
    'X-Mailer: Mebusan Intelligence Engine',
    'Content-Type: text/html; charset=UTF-8',
    'MIME-Version: 1.0',
  ];
  $htmlBody = "<!DOCTYPE html><html><body style='font-family:monospace;background:#070707;color:#e8e2d4;padding:32px'>
    <div style='max-width:560px;margin:0 auto'>
      <div style='font-size:11px;letter-spacing:3px;color:#5a5648;margin-bottom:24px'>MEBUSAN · INTELLIGENCE ALERT</div>
      <div style='font-size:20px;font-weight:200;color:#e8e2d4;margin-bottom:16px'>".htmlspecialchars($subject)."</div>
      <div style='font-size:13px;color:#9e9888;line-height:1.8;border-left:2px solid #3a7a58;padding-left:16px'>".nl2br(htmlspecialchars($body))."</div>
      <div style='margin-top:32px;padding-top:16px;border-top:1px solid #1a1a1a;font-size:10px;color:#3a3530'>
        MEBUSAN AI PTE LTD · SINGAPORE · mebusan.com<br>
        To manage your alert preferences, contact your advisor.
      </div>
    </div></body></html>";

  if (USE_SMTP) {
    // In production: use PHPMailer or similar
    // require 'vendor/phpmailer/src/PHPMailer.php';
    // ... SMTP config
  }

  // PHP mail() — works on most hosting including Hostinger
  $result = mail($to, $subject, $htmlBody, implode("\r\n", $headers));

  // Log alert
  $log = loadLog();
  $log[] = [
    'ts'       => time(),
    'to'       => $to,
    'subject'  => $subject,
    'priority' => $priority,
    'sent'     => $result,
    'date'     => date('c'),
  ];
  saveLog($log);

  return $result;
}

// ── Alert Templates ──────────────────────────────────────────────
$ALERT_TEMPLATES = [
  'currency_spike' => [
    'subject' => '⚠ Currency Alert: {currency} move exceeds {threshold}% — {pair}',
    'body'    => "Currency monitoring alert for your jurisdiction coverage.\n\n{pair} has moved {change}% in the past 7 days, breaching your configured alert threshold of {threshold}%.\n\nCurrent rate: {rate}\nPrevious rate: {prev_rate}\nChange: {change}%\n\nThis level of movement is consistent with {analysis}.\n\nAction may be required. Please review your exposure and contact your advisor if needed.\n\n— Mebusan Intelligence",
    'priority'=> 'high',
  ],
  'gdacs_red' => [
    'subject' => '🔴 Critical Event: {event_type} — {country}',
    'body'    => "GDACS has issued a RED alert for the following event:\n\n{title}\nCountry: {country}\nAlert Level: RED (Major event)\nScore: {score}\n\nThis event may affect stability, logistics, and operational security in the affected region.\n\nMonitoring is active. Your advisor will assess implications for your specific exposures.\n\n— Mebusan Intelligence",
    'priority'=> 'high',
  ],
  'regulatory_new' => [
    'subject' => '📋 Regulatory Signal: {jurisdiction} — {summary}',
    'body'    => "New regulatory signal detected for a jurisdiction in your coverage:\n\n{details}\n\nThis development may require review of your structures, accounts, or reporting obligations in {jurisdiction}.\n\nYour weekly briefing will include full analysis. For urgent assessment, contact your advisor directly.\n\n— Mebusan Intelligence",
    'priority'=> 'normal',
  ],
  'weekly_briefing' => [
    'subject' => '📄 Weekly Intelligence Briefing — {week}',
    'body'    => "Your weekly intelligence briefing for week {week_num} of {year}.\n\n{summary}\n\nFull briefing: {portal_link}\n\nKey developments this week:\n{developments}\n\nIf you have questions or require immediate assessment of any item, contact your advisor.\n\n— Mebusan Intelligence",
    'priority'=> 'normal',
  ],
];

function formatTemplate($template, $vars) {
  $text = $template;
  foreach ($vars as $k => $v) {
    $text = str_replace('{'.$k.'}', $v, $text);
  }
  return $text;
}

// ── Threshold monitoring (runs via cron) ──────────────────────────
function runThresholdChecks() {
  $results = [];

  // 1. Check forex thresholds via our own API
  $forexUrl = 'http://localhost' . dirname($_SERVER['SCRIPT_NAME']) . '/forex.php?mode=monitored';
  $ctx = stream_context_create(['http'=>['timeout'=>10,'ignore_errors'=>true]]);
  $fxData = @file_get_contents($forexUrl, false, $ctx);

  if ($fxData) {
    $fx = json_decode($fxData, true);
    if ($fx['success'] ?? false) {
      foreach ($fx['currencies'] as $currency) {
        if ($currency['alert'] ?? false) {
          $results[] = [
            'type'     => 'currency_spike',
            'currency' => $currency['code'],
            'change'   => $currency['change7d'],
            'pair'     => $currency['pair'],
            'country'  => $currency['country'],
          ];
          // In production: lookup clients monitoring this country and send alert
          // sendAlert($client_email, formatTemplate(...), $vars, 'high');
        }
      }
    }
  }

  // 2. Check GDACS for red alerts
  $gdacsCtx = stream_context_create(['http'=>['timeout'=>10,'user_agent'=>'Mebusan/1.0']]);
  $gdacsXml = @file_get_contents('https://www.gdacs.org/xml/rss.xml', false, $gdacsCtx);
  if ($gdacsXml) {
    libxml_use_internal_errors(true);
    $xml = simplexml_load_string($gdacsXml);
    if ($xml) {
      foreach ($xml->channel->item as $item) {
        $gdacs = $item->children('gdacs', true);
        $level = strtolower((string)($gdacs->alertlevel ?? ''));
        if ($level === 'red') {
          $results[] = [
            'type'    => 'gdacs_red',
            'title'   => (string)$item->title,
            'country' => (string)($gdacs->country ?? ''),
            'score'   => (float)($gdacs->alertscore ?? 0),
          ];
        }
      }
    }
  }

  // Log check
  $log = loadLog();
  $log[] = ['ts'=>time(), 'type'=>'threshold_check', 'findings'=>count($results), 'date'=>date('c')];
  saveLog($log);

  return $results;
}

// ── Routes ───────────────────────────────────────────────────────
if (!empty($_GET['run'])) {
  // Should be triggered by server cron: wget -q /api/alerts.php?run=1&cron_key=YOUR_KEY
  $cronKey = $_GET['cron_key'] ?? '';
  // Add cron key verification in production
  $results = runThresholdChecks();
  echo json_encode(['success'=>true, 'checks_run'=>true, 'alerts_found'=>count($results), 'results'=>$results]);
  exit;
}

if (!empty($_GET['history'])) {
  $log = array_reverse(loadLog());
  echo json_encode(['success'=>true, 'alerts'=>array_slice($log, 0, 50)]);
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $body = json_decode(file_get_contents('php://input'), true) ?? [];
  $type = $body['type'] ?? '';
  $data = $body['data'] ?? [];
  $to   = $body['to']   ?? '';

  if (!$type || !$to) {
    http_response_code(400);
    echo json_encode(['error'=>'type and to are required']);
    exit;
  }

  $template = $ALERT_TEMPLATES[$type] ?? null;
  if (!$template) {
    http_response_code(400);
    echo json_encode(['error'=>'Unknown alert type']);
    exit;
  }

  $subject = formatTemplate($template['subject'], $data);
  $body    = formatTemplate($template['body'], $data);
  $sent    = sendAlert($to, $subject, $body, $template['priority']);

  echo json_encode(['success'=>true, 'sent'=>$sent, 'to'=>$to, 'subject'=>$subject]);
  exit;
}

echo json_encode([
  'success' => true,
  'endpoints' => [
    'GET ?run=1&cron_key=KEY' => 'Run threshold checks',
    'GET ?history=1'          => 'View alert log',
    'POST {type,to,data}'     => 'Send specific alert',
  ],
  'templates' => array_keys($ALERT_TEMPLATES),
]);
