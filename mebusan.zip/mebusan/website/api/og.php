<?php
/**
 * MEBUSAN · Dynamic OG image generator
 * ──────────────────────────────────────────────────────────────
 * Produces on-the-fly 1200×630 branded Open Graph cards for any
 * page. Called like:
 *   /api/og.php?t=Signal%20Wall&s=Live%20intelligence%20excerpt
 * Output is cached to disk for 7 days.
 *
 * Uses PHP GD (ships with every Hostinger / cPanel install).
 * No external image libraries. No network calls.
 */

declare(strict_types=1);

// ─── Config ───────────────────────────────────────────────────
$W = 1200; $H = 630;
$CACHE_TTL = 86400 * 7;
$CACHE_DIR = __DIR__ . '/../cache/og';
if (!is_dir($CACHE_DIR)) @mkdir($CACHE_DIR, 0755, true);

// ─── Parse params ─────────────────────────────────────────────
$title = substr(trim($_GET['t'] ?? 'Private Intelligence'), 0, 80);
$subtitle = substr(trim($_GET['s'] ?? 'Monitoring wealth across borders'), 0, 120);
$kind = substr(trim($_GET['k'] ?? 'default'), 0, 32);

// ─── Cache hit? ───────────────────────────────────────────────
$cacheKey = md5($title . '|' . $subtitle . '|' . $kind);
$cachePath = $CACHE_DIR . '/' . $cacheKey . '.png';

if (file_exists($cachePath) && (time() - filemtime($cachePath)) < $CACHE_TTL) {
    header('Content-Type: image/png');
    header('Cache-Control: public, max-age=604800, immutable');
    header('Content-Length: ' . filesize($cachePath));
    readfile($cachePath);
    exit;
}

// ─── Render ───────────────────────────────────────────────────
$img = imagecreatetruecolor($W, $H);
imageantialias($img, true);

// Colours
$bg = imagecolorallocate($img, 7, 6, 5);
$bgTop = imagecolorallocate($img, 10, 9, 7);
$cream = imagecolorallocate($img, 232, 226, 212);
$muted = imagecolorallocate($img, 158, 152, 136);
$faint = imagecolorallocate($img, 90, 86, 72);
$line1 = imagecolorallocate($img, 26, 24, 20);
$line2 = imagecolorallocate($img, 42, 39, 33);
$amber = imagecolorallocate($img, 200, 160, 58);

// Vertical gradient background (subtle)
for ($y = 0; $y < $H; $y++) {
    $pct = $y / $H;
    $r = (int)(10 * (1 - $pct) + 5 * $pct);
    $g = (int)(9 * (1 - $pct) + 4 * $pct);
    $b = (int)(7 * (1 - $pct) + 3 * $pct);
    $clr = imagecolorallocate($img, $r, $g, $b);
    imageline($img, 0, $y, $W, $y, $clr);
}

// Architectural inner frame
imageline($img, 60, 60, $W - 60, 60, $line1);
imageline($img, 60, $H - 60, $W - 60, $H - 60, $line1);
imageline($img, 60, 60, 60, $H - 60, $line1);
imageline($img, $W - 60, 60, $W - 60, $H - 60, $line1);

// Horizontal split line
imageline($img, 60, 200, $W - 60, 200, $line2);
imageline($img, 60, $H - 180, $W - 60, $H - 180, $line2);

// Dot grid (faint, architectural)
for ($x = 84; $x < $W - 60; $x += 48) {
    for ($y = 220; $y < $H - 200; $y += 48) {
        imagefilledrectangle($img, $x, $y, $x, $y, $line2);
    }
}

// Find available font
$fontCandidates = [
    '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
    '/usr/share/fonts/TTF/DejaVuSans.ttf',
    __DIR__ . '/fonts/Inter.ttf',
    __DIR__ . '/fonts/DejaVuSans.ttf'
];
$font = null;
foreach ($fontCandidates as $f) {
    if (file_exists($f)) { $font = $f; break; }
}

if ($font) {
    // MEBUSAN wordmark top-left (micro-caps)
    imagettftext($img, 16, 0, 100, 140, $muted, $font, 'MEBUSAN');

    // Small accent line next to wordmark
    imagefilledrectangle($img, 205, 132, 265, 132, $muted);

    // Kind label top-right
    if ($kind && $kind !== 'default') {
        $kUp = strtoupper($kind);
        $bbox = imagettfbbox(12, 0, $font, $kUp);
        $tw = $bbox[2] - $bbox[0];
        imagettftext($img, 12, 0, $W - 100 - $tw, 140, $faint, $font, $kUp);
    }

    // Title — big, centered-left, on the canvas
    $titleLines = wrapTitle($title, $font, 60, $W - 200);
    $titleSize = 60;
    if (count($titleLines) > 2) $titleSize = 48;
    if (count($titleLines) > 3) $titleSize = 42;
    $y = 300;
    foreach ($titleLines as $line) {
        imagettftext($img, $titleSize, 0, 100, $y, $cream, $font, $line);
        $y += (int)($titleSize * 1.1);
    }

    // Subtitle
    $subY = $H - 140;
    $subLines = wrapTitle($subtitle, $font, 18, $W - 200);
    $subSize = 18;
    foreach (array_slice($subLines, 0, 2) as $line) {
        imagettftext($img, $subSize, 0, 100, $subY, $muted, $font, $line);
        $subY += (int)($subSize * 1.5);
    }

    // URL footer
    imagettftext($img, 12, 0, 100, $H - 90, $faint, $font, 'MEBUSAN.COM');

    // Status dot (top-right, accent)
    imagefilledellipse($img, $W - 100, 128, 8, 8, $amber);

} else {
    // Fallback: built-in font (always works but less elegant)
    imagestring($img, 5, 100, 100, 'MEBUSAN', $cream);
    imagestring($img, 5, 100, 300, substr($title, 0, 60), $cream);
    imagestring($img, 3, 100, $H - 120, substr($subtitle, 0, 80), $muted);
}

// Output
imagepng($img, $cachePath, 9);
imagedestroy($img);

header('Content-Type: image/png');
header('Cache-Control: public, max-age=604800, immutable');
header('Content-Length: ' . filesize($cachePath));
readfile($cachePath);

// ─── Helpers ──────────────────────────────────────────────────
function wrapTitle(string $text, string $font, int $size, int $maxWidth): array {
    if (!$font || !file_exists($font)) {
        // Rough char-based wrap
        return explode("\n", wordwrap($text, 25, "\n", true));
    }
    $words = explode(' ', $text);
    $lines = [];
    $current = '';
    foreach ($words as $word) {
        $try = $current === '' ? $word : $current . ' ' . $word;
        $bbox = imagettfbbox($size, 0, $font, $try);
        $w = $bbox[2] - $bbox[0];
        if ($w > $maxWidth && $current !== '') {
            $lines[] = $current;
            $current = $word;
        } else {
            $current = $try;
        }
    }
    if ($current !== '') $lines[] = $current;
    return $lines;
}
