<?php
/**
 * MEBUSAN — AI Intelligence Analysis
 * Uses Anthropic API to analyze news items, generate risk assessments,
 * and produce structured intelligence briefings
 *
 * POST /api/intel.php { action: "analyze", text: "..." }
 * POST /api/intel.php { action: "briefing", jurisdictions: [...], signals: [...] }
 * POST /api/intel.php { action: "assess", country: "LB", context: "..." }
 * POST /api/intel.php { action: "chat", messages: [...] } (advisor chat)
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error'=>'POST required']); exit; }

// Load API key from config
define('ANTHROPIC_KEY', defined('ANTHROPIC_API_KEY') ? ANTHROPIC_API_KEY : (
  file_exists(__DIR__.'/../config.php') ? (include __DIR__.'/../config.php') : 'YOUR_ANTHROPIC_API_KEY'
));
define('API_URL', 'https://api.anthropic.com/v1/messages');
define('MODEL',   'claude-sonnet-4-20250514');

// Cache config
define('CACHE_DIR', __DIR__ . '/../cache/intel/');
define('CACHE_TTL', 3600); // 1h for analysis results
if (!is_dir(CACHE_DIR)) mkdir(CACHE_DIR, 0755, true);

function callAnthropic($system, $messages, $maxTokens = 800) {
  // Check for key
  $key = ANTHROPIC_KEY;
  if ($key === 'YOUR_ANTHROPIC_API_KEY' || empty($key)) {
    return ['error' => 'Anthropic API key not configured. Set it in config.php'];
  }

  $payload = json_encode([
    'model'      => MODEL,
    'max_tokens' => $maxTokens,
    'system'     => $system,
    'messages'   => $messages,
  ]);

  $ch = curl_init(API_URL);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_HTTPHEADER     => [
      'Content-Type: application/json',
      'x-api-key: ' . $key,
      'anthropic-version: 2023-06-01',
    ],
  ]);
  $response  = curl_exec($ch);
  $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($httpCode !== 200) return ['error' => 'API error: ' . $httpCode];
  $data = json_decode($response, true);
  return $data['content'][0]['text'] ?? ['error' => 'No content'];
}

// ── System Prompts ──────────────────────────────────────────────
$SYSTEMS = [

  'analyze' => 'You are a senior analyst at Mebusan, a private intelligence firm. Your role is to analyze news items and assess their implications for private wealth holders — individuals with significant cross-border assets. Focus on: capital control risk, banking sector stability, regulatory changes affecting offshore structures, sanctions exposure, and currency risk. Be precise, direct, and specific. Output as JSON: {"risk_level":"high|elevated|monitor|low","categories":["financial","political","regulatory","banking"],"summary":"1-2 sentences","implications":"what this means for wealth holders","action_required":true|false,"action":"what should be reviewed","countries":["ISO2"]}',

  'briefing' => 'You are a senior intelligence briefer at Mebusan. Generate a structured weekly intelligence briefing from the provided signals. Focus on developments most relevant to high-net-worth individuals with cross-border assets. Be precise and authoritative. Format: start with "SITUATION SUMMARY" (2-3 sentences of the key week), then "KEY DEVELOPMENTS" (4-6 bullet points with bold jurisdiction names), then "ITEMS FOR REVIEW" (specific actions clients should consider), then "OUTLOOK" (next 2 weeks). Professional tone. No fluff.',

  'assess' => 'You are a country risk analyst at Mebusan. Provide a structured risk assessment for the given jurisdiction and context. Output JSON: {"country":"name","risk_level":"high|elevated|monitor|low","composite_score":0-100,"political":{"score":0-100,"key_risks":["..."],"outlook":"..."},"banking":{"score":0-100,"key_risks":["..."],"outlook":"..."},"regulatory":{"score":0-100,"key_risks":["..."],"outlook":"..."},"capital_controls":{"score":0-100,"key_risks":["..."],"outlook":"..."},"summary":"2-3 sentences","recommended_actions":["..."]}',

  'chat' => 'You are the Mebusan senior advisory assistant. Mebusan is a private intelligence firm serving high-net-worth individuals with cross-border assets. You provide precise, substantive intelligence analysis and service information. Be direct, authoritative, and helpful. You cover: jurisdiction risk monitoring across 132 countries, banking intelligence, regulatory changes, sanctions, capital control risk, and private wealth protection. Never give financial advice. Do give detailed, substantive intelligence context. When asked about specific countries or situations, give your best informed assessment. MEBUSAN AI PTE LTD · Singapore.',

  'signals' => 'You are a signals analyst at Mebusan. Given a set of recent news items, identify which ones represent genuine risk signals for high-net-worth individuals and classify them. Output JSON array: [{"title":"...","signal_type":"capital_control|banking_stress|regulatory_change|political_instability|sanctions|currency_risk|other","risk_level":"high|elevated|monitor","countries":["ISO2"],"wealth_impact":"what this means for private wealth holders","urgency":"immediate|soon|routine"}]',
];

$body   = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $body['action'] ?? 'chat';

switch ($action) {

  case 'analyze':
    $text = trim($body['text'] ?? '');
    if (!$text) { http_response_code(400); echo json_encode(['error'=>'text required']); exit; }

    $cacheKey = CACHE_DIR . md5($text) . '.json';
    if (file_exists($cacheKey) && (time() - filemtime($cacheKey)) < CACHE_TTL) {
      echo file_get_contents($cacheKey); exit;
    }

    $result = callAnthropic($SYSTEMS['analyze'], [['role'=>'user','content'=>"Analyze this signal:\n\n{$text}"]]);
    if (is_array($result) && isset($result['error'])) { echo json_encode($result); exit; }

    // Try to parse JSON from response
    $jsonMatch = [];
    if (preg_match('/\{.*\}/s', $result, $jsonMatch)) {
      $parsed = json_decode($jsonMatch[0], true);
      if ($parsed) {
        file_put_contents($cacheKey, json_encode(['success'=>true,'analysis'=>$parsed]));
        echo json_encode(['success'=>true,'analysis'=>$parsed]);
        exit;
      }
    }
    echo json_encode(['success'=>true,'analysis'=>['summary'=>$result]]);
    break;

  case 'briefing':
    $jurisdictions = $body['jurisdictions'] ?? [];
    $signals       = $body['signals'] ?? [];
    $period        = $body['period'] ?? date('Y W');

    $signalsText = implode("\n\n", array_map(fn($s) => "• {$s['title']}: {$s['body']}", array_slice($signals, 0, 20)));
    $prompt = "Generate a weekly intelligence briefing for week {$period}.\n\nJurisdictions in scope: ".implode(', ', $jurisdictions)."\n\nKey signals this week:\n\n{$signalsText}";

    $result = callAnthropic($SYSTEMS['briefing'], [['role'=>'user','content'=>$prompt]], 1200);
    if (is_array($result) && isset($result['error'])) { echo json_encode($result); exit; }
    echo json_encode(['success'=>true,'briefing'=>$result,'period'=>$period]);
    break;

  case 'assess':
    $country = trim($body['country'] ?? '');
    $context = trim($body['context'] ?? '');
    if (!$country) { http_response_code(400); echo json_encode(['error'=>'country required']); exit; }

    $prompt = "Provide a risk assessment for: {$country}".($context ? "\n\nAdditional context: {$context}" : "");
    $result = callAnthropic($SYSTEMS['assess'], [['role'=>'user','content'=>$prompt]], 1000);
    if (is_array($result) && isset($result['error'])) { echo json_encode($result); exit; }

    $jsonMatch = [];
    if (preg_match('/\{.*\}/s', $result, $jsonMatch)) {
      $parsed = json_decode($jsonMatch[0], true);
      if ($parsed) { echo json_encode(['success'=>true,'assessment'=>$parsed]); exit; }
    }
    echo json_encode(['success'=>true,'assessment'=>['raw'=>$result]]);
    break;

  case 'signals':
    $items = $body['items'] ?? [];
    if (!$items) { http_response_code(400); echo json_encode(['error'=>'items required']); exit; }
    $prompt = "Classify these news items as intelligence signals:\n\n".json_encode(array_slice($items, 0, 15));
    $result = callAnthropic($SYSTEMS['signals'], [['role'=>'user','content'=>$prompt]], 1200);
    if (is_array($result) && isset($result['error'])) { echo json_encode($result); exit; }
    $jsonMatch = [];
    if (preg_match('/\[.*\]/s', $result, $jsonMatch)) {
      $parsed = json_decode($jsonMatch[0], true);
      if ($parsed) { echo json_encode(['success'=>true,'signals'=>$parsed]); exit; }
    }
    echo json_encode(['success'=>true,'raw'=>$result]);
    break;

  case 'chat':
  default:
    $messages = $body['messages'] ?? [];
    if (!$messages) { http_response_code(400); echo json_encode(['error'=>'messages required']); exit; }
    // Limit history
    if (count($messages) > 20) $messages = array_slice($messages, -20);
    $result = callAnthropic($SYSTEMS['chat'], $messages, 600);
    if (is_array($result) && isset($result['error'])) { echo json_encode($result); exit; }
    echo json_encode(['success'=>true,'reply'=>$result]);
    break;
}
