<?php
/**
 * MEBUSAN — Risk Intelligence Engine
 * Aggregates World Bank + IMF + GDACS + internal scores into unified risk profiles
 * Usage: /api/risk.php?country=LB (ISO2)
 * /api/risk.php?all=1 (all monitored countries)
 * /api/risk.php?scores=1 (risk score matrix)
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=3600');

define('CACHE_DIR', __DIR__ . '/../cache/risk/');
define('CACHE_TTL', 3600 * 6); // 6 hour cache for risk data

if (!is_dir(CACHE_DIR)) mkdir(CACHE_DIR, 0755, true);

function rCache($key) { return CACHE_DIR . md5($key) . '.json'; }
function rGet($key) {
 $f = rCache($key);
 if (file_exists($f) && (time() - filemtime($f)) < CACHE_TTL)
 return json_decode(file_get_contents($f), true);
 return null;
}
function rSet($key, $d) { file_put_contents(rCache($key), json_encode($d)); }

function fetchJson($url) {
 $ctx = stream_context_create(['http'=>['timeout'=>10,'user_agent'=>'Mebusan/1.0','ignore_errors'=>true]]);
 $r = @file_get_contents($url, false, $ctx);
 return $r ? json_decode($r, true) : null;
}

// ── World Bank Indicators ──────────────────────────────────────
// GDP growth, inflation, current account, political stability
$WB_INDICATORS = [
 'NY.GDP.MKTP.KD.ZG' => 'gdp_growth', // GDP growth
 'FP.CPI.TOTL.ZG' => 'inflation', // CPI inflation
 'BX.KLT.DINV.WD.GD.ZS' => 'fdi_pct_gdp', // FDI
 'GC.DOD.TOTL.GD.ZS' => 'debt_pct_gdp', // Govt debt
 'PV.EST' => 'political_stability', // Political stability (WGI)
 'RL.EST' => 'rule_of_law', // Rule of law (WGI)
];

function getWorldBankData($iso3) {
 $key = "wb-{$iso3}";
 $cached = rGet($key);
 if ($cached) return $cached;

 $results = [];
 $year = date('Y') - 2; // WB data lags 1-2 years
 foreach (['NY.GDP.MKTP.KD.ZG','FP.CPI.TOTL.ZG','GC.DOD.TOTL.GD.ZS','PV.EST','RL.EST'] as $ind) {
 $url = "https://api.worldbank.org/v2/country/{$iso3}/indicator/{$ind}?format=json&mrv=3&per_page=3";
 $data = fetchJson($url);
 if ($data && !empty($data[1])) {
 foreach ($data[1] as $point) {
 if ($point['value'] !== null) {
 $results[$ind] = ['value'=>round((float)$point['value'],2), 'year'=>$point['date']];
 break;
 }
 }
 }
 usleep(100000); // 100ms rate limiting
 }

 rSet($key, $results);
 return $results;
}

// ── GDACS — Active alerts for a country ──────────────────────────
function getGDACSAlerts($countryName) {
 $key = 'gdacs-alerts';
 $cached = rGet($key);

 if (!$cached) {
 $ctx = stream_context_create(['http'=>['timeout'=>8,'user_agent'=>'Mebusan/1.0']]);
 $xml_str = @file_get_contents('https://www.gdacs.org/xml/rss.xml', false, $ctx);
 $alerts = [];
 if ($xml_str) {
 libxml_use_internal_errors(true);
 $xml = simplexml_load_string($xml_str);
 if ($xml) {
 foreach ($xml->channel->item as $item) {
 $gdacs = $item->children('gdacs', true);
 $alerts[] = [
 'title' => (string)$item->title,
 'country' => (string)($gdacs->country ?? ''),
 'level' => strtolower((string)($gdacs->alertlevel ?? 'green')),
 'score' => (float)($gdacs->alertscore ?? 0),
 'type' => (string)($gdacs->eventtype ?? ''),
 'date' => (string)$item->pubDate,
 ];
 }
 }
 }
 $cached = $alerts;
 rSet($key, $alerts);
 }

 return array_filter($cached, fn($a) => stripos($a['country'], $countryName) !== false);
}

// ── Risk Score Calculator ──────────────────────────────────────
// Combines WB data + internal analyst scores + GDACS alerts
// Returns 0-100 composite risk score per category

$COUNTRY_PROFILES = [
 // ISO2 => [name, iso3, flag, base_scores{political,banking,regulatory,capital}]
 'LB' => ['Lebanon', 'LBN', '', [85,92,72,90], 'middle-east'],
 'TR' => ['Turkey', 'TUR', '', [72,68,65,75], 'europe'],
 'NG' => ['Nigeria', 'NGA', '', [70,68,65,72], 'africa'],
 'RU' => ['Russia', 'RUS', '', [90,85,75,88], 'europe'],
 'UA' => ['Ukraine', 'UKR', '', [92,80,70,85], 'europe'],
 'AR' => ['Argentina', 'ARG', '', [68,72,60,80], 'americas'],
 'EG' => ['Egypt', 'EGY', '', [68,70,65,75], 'africa'],
 'PK' => ['Pakistan', 'PAK', '', [72,68,62,70], 'asia'],
 'VE' => ['Venezuela', 'VEN', '', [90,88,78,92], 'americas'],
 'SY' => ['Syria', 'SYR', '', [95,90,80,95], 'middle-east'],
 'IR' => ['Iran', 'IRN', '', [88,90,75,92], 'middle-east'],
 'BY' => ['Belarus', 'BLR', '', [85,75,80,70], 'europe'],
 'AE' => ['UAE', 'ARE', '', [40,32,62,22], 'middle-east'],
 'CH' => ['Switzerland', 'CHE', '', [12,18,45,8], 'europe'],
 'SG' => ['Singapore', 'SGP', '', [18,15,55,10], 'asia'],
 'GB' => ['United Kingdom','GBR','', [32,28,48,15], 'europe'],
 'ZW' => ['Zimbabwe', 'ZWE', '', [75,80,65,82], 'africa'],
 'LY' => ['Libya', 'LBY', '', [88,80,72,85], 'africa'],
 'SD' => ['Sudan', 'SDN', '', [90,85,78,88], 'africa'],
 'SA' => ['Saudi Arabia', 'SAU', '', [45,35,48,30], 'middle-east'],
];

function calculateRiskScore($iso2, $wbData, $gdacsAlerts) {
 global $COUNTRY_PROFILES;
 $profile = $COUNTRY_PROFILES[$iso2] ?? null;
 if (!$profile) return null;

 [$name, $iso3, $flag, $base, $region] = $profile;
 [$pol, $bank, $reg, $cap] = $base;

 // Adjust from World Bank data
 $inflation = $wbData['FP.CPI.TOTL.ZG']['value'] ?? null;
 $gdpGrowth = $wbData['NY.GDP.MKTP.KD.ZG']['value'] ?? null;
 $polStab = $wbData['PV.EST']['value'] ?? null;
 $ruleOfLaw = $wbData['RL.EST']['value'] ?? null;
 $debt = $wbData['GC.DOD.TOTL.GD.ZS']['value'] ?? null;

 // Inflation adjustment
 if ($inflation !== null) {
 if ($inflation > 100) $cap = min(100, $cap + 20);
 elseif ($inflation > 50) $cap = min(100, $cap + 12);
 elseif ($inflation > 20) $cap = min(100, $cap + 6);
 elseif ($inflation < 3) $cap = max(0, $cap - 5);
 }

 // GDP growth adjustment
 if ($gdpGrowth !== null) {
 if ($gdpGrowth < -5) { $bank = min(100, $bank + 10); $cap = min(100, $cap + 8); }
 elseif ($gdpGrowth < 0) { $bank = min(100, $bank + 5); }
 }

 // WGI Political Stability (-2.5 to 2.5 scale, normalize to 0-100)
 if ($polStab !== null) {
 $normalised = (($polStab + 2.5) / 5) * 100; // 0=worst, 100=best
 $pol = (int)round($pol * 0.7 + (100 - $normalised) * 0.3);
 $pol = max(0, min(100, $pol));
 }

 // GDACS active alerts
 $critAlerts = count(array_filter($gdacsAlerts, fn($a) => $a['level'] === 'red'));
 $warnAlerts = count(array_filter($gdacsAlerts, fn($a) => $a['level'] === 'orange'));
 if ($critAlerts > 0) { $pol = min(100, $pol + 15); $bank = min(100, $bank + 10); }
 elseif ($warnAlerts > 0) { $pol = min(100, $pol + 8); }

 $composite = (int)round(($pol * 0.3 + $bank * 0.25 + $reg * 0.2 + $cap * 0.25));

 $riskLevel = 'monitor';
 if ($composite >= 70) $riskLevel = 'high';
 elseif ($composite >= 50) $riskLevel = 'elevated';
 elseif ($composite < 25) $riskLevel = 'low';

 return [
 'iso2' => $iso2,
 'iso3' => $iso3,
 'name' => $name,
 'flag' => $flag,
 'region' => $region,
 'risk_level'=> $riskLevel,
 'composite' => $composite,
 'scores' => ['political'=>$pol, 'banking'=>$bank, 'regulatory'=>$reg, 'capital'=>$cap],
 'wb_data' => $wbData,
 'gdacs_alerts' => count($gdacsAlerts),
 'calculated_at' => date('c'),
 ];
}

// ── Route ────────────────────────────────────────────────────────
$iso2 = strtoupper($_GET['country'] ?? '');

if ($iso2 && isset($COUNTRY_PROFILES[$iso2])) {
 $profile = $COUNTRY_PROFILES[$iso2];
 $iso3 = $profile[1];
 $name = $profile[0];

 $wbData = getWorldBankData($iso3);
 $gdacs = getGDACSAlerts($name);
 $riskScore = calculateRiskScore($iso2, $wbData, $gdacs);

 echo json_encode(['success'=>true, 'country'=>$riskScore]);
 exit;
}

if (!empty($_GET['all'])) {
 $results = [];
 foreach (array_keys($COUNTRY_PROFILES) as $iso2) {
 $ckey = "risk-{$iso2}";
 $cached = rGet($ckey);
 if ($cached) { $results[] = $cached; continue; }
 $profile = $COUNTRY_PROFILES[$iso2];
 $wbData = getWorldBankData($profile[1]);
 $gdacs = getGDACSAlerts($profile[0]);
 $score = calculateRiskScore($iso2, $wbData, $gdacs);
 if ($score) { rSet($ckey, $score); $results[] = $score; }
 usleep(200000); // 200ms between WB requests
 }
 usort($results, fn($a,$b) => $b['composite'] - $a['composite']);
 echo json_encode(['success'=>true, 'count'=>count($results), 'countries'=>$results]);
 exit;
}

// Scores matrix
echo json_encode([
 'success' => true,
 'countries' => array_keys($COUNTRY_PROFILES),
 'note' => 'Use ?country=ISO2 for detailed profile or ?all=1 for all countries',
]);
