<?php
/**
 * MEBUSAN · Critical alert phone-call dispatcher
 * ─────────────────────────────────────────────────────────────────
 * Triggered when a critical threshold fires on a client's coverage.
 *
 * Flow:
 *   1. Server-side code calls this endpoint with the alert payload
 *   2. We place an automated voice call via Twilio Programmable Voice
 *   3. Twilio fetches TwiML from alert-twiml.php which plays:
 *         "This is Mebusan. A critical alert has been issued on your
 *          [jurisdiction] coverage. Open the Mebusan app now to review,
 *          or press 1 to acknowledge. Press 2 to request an analyst
 *          callback within fifteen minutes."
 *   4. Acknowledgement is recorded via the status callback endpoint
 *   5. If not acknowledged within 90 seconds, the analyst is paged
 *
 * Authentication: same internal-key scheme as other endpoints.
 *
 * Environment:
 *   TWILIO_ACCOUNT_SID
 *   TWILIO_AUTH_TOKEN
 *   TWILIO_FROM_NUMBER       (your Mebusan number)
 *   TWILIO_VOICE_CALLBACK_BASE   (e.g. https://mebusan.com — used to build TwiML URL)
 *   MEBUSAN_INTERNAL_KEY
 */

declare(strict_types=1);

header('Content-Type: application/json');

// Auth
$expected = getenv('MEBUSAN_INTERNAL_KEY') ?: '';
$provided = $_GET['key'] ?? ($_SERVER['HTTP_X_MEBUSAN_KEY'] ?? '');
if ($expected && $provided !== $expected) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

$body = json_decode(file_get_contents('php://input') ?: '', true) ?: [];

$to            = $body['phone']         ?? '';
$clientId      = $body['client_id']     ?? 'unknown';
$alertId       = $body['alert_id']      ?? ('ALRT-' . bin2hex(random_bytes(4)));
$jurisdiction  = $body['jurisdiction']  ?? 'your coverage';
$headline      = $body['headline']      ?? 'A critical situation has developed';
$analystPhone  = $body['analyst_phone'] ?? '';
$clientName    = $body['client_name']   ?? '';

if (!$to || !preg_match('/^\+\d{7,15}$/', $to)) {
    http_response_code(400);
    echo json_encode(['error' => 'valid E.164 phone required']);
    exit;
}

// Record the alert for audit + in-app display
$root = dirname(__DIR__);
$dir  = $root . '/cache/critical_alerts';
if (!is_dir($dir)) @mkdir($dir, 0755, true);
$alertRecord = [
    'alert_id'     => $alertId,
    'client_id'    => $clientId,
    'client_name'  => $clientName,
    'phone'        => $to,
    'jurisdiction' => $jurisdiction,
    'headline'     => $headline,
    'issued_at'    => date('c'),
    'acknowledged' => false,
    'analyst_phone' => $analystPhone,
    'escalation_at' => date('c', time() + 90),
    'call_sid'     => null,
    'call_status'  => 'queued',
];
file_put_contents($dir . '/' . $alertId . '.json', json_encode($alertRecord, JSON_PRETTY_PRINT));

// Build TwiML URL (Twilio fetches this to know what to say)
$callbackBase = getenv('TWILIO_VOICE_CALLBACK_BASE') ?: 'https://mebusan.com';
$twimlUrl     = rtrim($callbackBase, '/') . '/api/alert-twiml.php?alert=' . urlencode($alertId);
$statusUrl    = rtrim($callbackBase, '/') . '/api/alert-call-status.php?alert=' . urlencode($alertId);

// Twilio API call
$sid   = getenv('TWILIO_ACCOUNT_SID') ?: '';
$token = getenv('TWILIO_AUTH_TOKEN')  ?: '';
$from  = getenv('TWILIO_FROM_NUMBER') ?: '';

if (!$sid || !$token || !$from) {
    // In dev — record but don't fail
    $alertRecord['call_status'] = 'no_twilio_config';
    file_put_contents($dir . '/' . $alertId . '.json', json_encode($alertRecord, JSON_PRETTY_PRINT));
    echo json_encode([
        'success'    => false,
        'alert_id'   => $alertId,
        'reason'     => 'Twilio not configured · alert recorded · in-app overlay will still fire',
    ]);
    exit;
}

$postFields = [
    'To'                       => $to,
    'From'                     => $from,
    'Url'                      => $twimlUrl,
    'Method'                   => 'POST',
    'StatusCallback'           => $statusUrl,
    'StatusCallbackMethod'     => 'POST',
    'StatusCallbackEvent'      => 'initiated ringing answered completed',
    'Timeout'                  => 30,
    'MachineDetection'         => 'DetectMessageEnd',
];

$ch = curl_init('https://api.twilio.com/2010-04-01/Accounts/' . $sid . '/Calls.json');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => http_build_query($postFields),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_USERPWD        => $sid . ':' . $token,
    CURLOPT_TIMEOUT        => 20,
]);
$respBody = curl_exec($ch);
$code     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$resp = json_decode((string)$respBody, true) ?: [];

if ($code >= 200 && $code < 300) {
    $alertRecord['call_sid']    = $resp['sid'] ?? null;
    $alertRecord['call_status'] = $resp['status'] ?? 'queued';
    file_put_contents($dir . '/' . $alertId . '.json', json_encode($alertRecord, JSON_PRETTY_PRINT));
    echo json_encode(['success' => true, 'alert_id' => $alertId, 'call_sid' => $resp['sid'] ?? null]);
} else {
    $alertRecord['call_status'] = 'failed';
    $alertRecord['error']       = $resp['message'] ?? 'Twilio error';
    file_put_contents($dir . '/' . $alertId . '.json', json_encode($alertRecord, JSON_PRETTY_PRINT));
    http_response_code(502);
    echo json_encode(['success' => false, 'error' => $alertRecord['error']]);
}
