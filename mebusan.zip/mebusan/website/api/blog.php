<?php
/**
 * MEBUSAN — Automated Intelligence Blog
 * Pulls from monitored sources, rewrites via Anthropic API in Mebusan's voice,
 * and publishes as a structured blog post.
 *
 * GET  /api/blog.php             → List published posts
 * GET  /api/blog.php?action=generate → Generate and publish a new post
 * GET  /api/blog.php?action=list     → List posts with pagination
 * GET  /api/blog.php?id=SLUG         → Get single post
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../config.php';
define('BLOG_DIR', __DIR__ . '/../cache/blog/');

if (!is_dir(BLOG_DIR)) { mkdir(BLOG_DIR, 0755, true); }

$action = $_GET['action'] ?? 'list';
$id     = $_GET['id'] ?? '';

// ── Rate limit: max 1 generation per 4 hours ──────────────────
function canGenerate(): bool {
    $lockFile = BLOG_DIR . '.last_generated';
    if (file_exists($lockFile)) {
        $last = (int)file_get_contents($lockFile);
        if (time() - $last < 14400) return false; // 4 hours
    }
    return true;
}
function markGenerated(): void {
    file_put_contents(BLOG_DIR . '.last_generated', time());
}

// ── Pull a fresh signal from RSS sources ──────────────────────
function fetchFreshSignal(): ?array {
    $sources = [
        ['url'=>'https://feeds.reuters.com/reuters/businessNews','label'=>'Reuters'],
        ['url'=>'https://www.fatf-gafi.org/content/fatf-gafi/en/news.rss.xml','label'=>'FATF'],
        ['url'=>'https://home.treasury.gov/system/files/126/ofac.xml','label'=>'US Treasury OFAC'],
        ['url'=>'https://www.europol.europa.eu/newsroom/rss','label'=>'Europol'],
        ['url'=>'https://www.bis.org/rss/press.rss','label'=>'BIS'],
        ['url'=>'https://www.imf.org/en/News/rss?language=eng','label'=>'IMF'],
        ['url'=>'https://www.chathamhouse.org/rss.xml','label'=>'Chatham House'],
        ['url'=>'https://fcpablog.com/feed/','label'=>'FCPA Blog'],
        ['url'=>'https://www.lawfaremedia.org/feed','label'=>'Lawfare'],
        ['url'=>'https://occrp.org/en/articles/rss','label'=>'OCCRP'],
    ];

    // Pick a random source and fetch
    $src = $sources[array_rand($sources)];
    $ctx = stream_context_create(['http'=>['timeout'=>8,'user_agent'=>'Mebusan/2.0']]);
    $xml = @file_get_contents($src['url'], false, $ctx);
    if (!$xml) return null;

    $feed = @simplexml_load_string($xml);
    if (!$feed) return null;

    $items = $feed->channel->item ?? $feed->entry ?? [];
    if (!count($items)) return null;

    // Pick one of the first 5 items randomly
    $item = $items[rand(0, min(4, count($items)-1))];
    return [
        'title'   => (string)($item->title ?? ''),
        'desc'    => strip_tags((string)($item->description ?? $item->summary ?? '')),
        'link'    => (string)($item->link ?? ''),
        'source'  => $src['label'],
        'date'    => date('c'),
    ];
}

// ── Rewrite via Anthropic API ─────────────────────────────────
function rewriteForMebusan(array $signal): ?array {
    if (empty(ANTHROPIC_API_KEY)) {
        // Dev mode — generate a placeholder
        return [
            'title'    => 'Intelligence Note: ' . substr($signal['title'], 0, 60),
            'slug'     => slugify($signal['title']),
            'body'     => "This intelligence note examines recent developments from {$signal['source']} and their implications for individuals with cross-border assets. The signal below has been reviewed and contextualised by the Mebusan intelligence team.\n\n" . $signal['desc'],
            'category' => 'regulatory',
            'region'   => 'global',
            'source'   => $signal['source'],
            'date'     => $signal['date'],
        ];
    }

    $prompt = "You are a writer for Mebusan. Mebusan is a private service that monitors environments affecting client assets. You never mention sources, RSS feeds, or external publications. Never use "according to", "as reported by", "sources say", or attribute anything to an external organisation. Write as if Mebusan observed this directly. You write in first person plural — "We have noted...", "We have been tracking...", "We are flagging...". You never attribute information to external organisations. Write as if Mebusan discovered this directly. Never use phrases like "according to", "as reported by", or "sources say". Keep language calm, direct, and professional."source']}:
Title: {$signal['title']}
Content: " . substr($signal['desc'], 0, 600) . "

Write an intelligence note for Mebusan clients. Follow these rules exactly:
- Write in Mebusan's voice: direct, authoritative, no fluff, no corporate jargon
- DO NOT use em-dashes (—) anywhere
- DO NOT use numbered lists (1. 2. 3.)
- DO NOT say 'it is worth noting' or 'it is important to' or similar filler
- DO NOT use the word 'leverage', 'robust', 'comprehensive', 'utilize', 'innovative'
- Write 3-4 short paragraphs of actual intelligence analysis
- First paragraph: what the signal is, stated plainly
- Second paragraph: what it means for private wealth holders specifically
- Third paragraph: what to watch next, what the timeline looks like
- Optional fourth paragraph: what similar historical signals preceded

Return ONLY a JSON object with these fields:
{
  \"headline\": \"short compelling headline, max 80 chars, no clickbait\",
  \"category\": \"one of: banking, regulatory, sanctions, political, financial\",
  \"region\": \"one of: europe, middle-east, asia, americas, africa, global\",
  \"body\": \"the full intelligence note as plain text, paragraphs separated by \\n\\n\"
}";

    $resp = @file_get_contents('https://api.anthropic.com/v1/messages', false,
        stream_context_create(['http'=>[
            'method'  => 'POST',
            'timeout' => 30,
            'header'  => "Content-Type: application/json\r\nX-API-Key: " . ANTHROPIC_API_KEY . "\r\nAnthropic-Version: 2023-06-01",
            'content' => json_encode([
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 800,
                'messages'   => [['role'=>'user','content'=>$prompt]],
            ]),
        ]])
    );

    if (!$resp) return null;
    $data = json_decode($resp, true);
    $text = $data['content'][0]['text'] ?? '';

    // Strip JSON fences
    $text = preg_replace('/```json|```/', '', $text);
    $parsed = json_decode(trim($text), true);
    if (!$parsed) return null;

    return [
        'title'    => $parsed['headline'] ?? $signal['title'],
        'slug'     => slugify($parsed['headline'] ?? $signal['title']),
        'body'     => $parsed['body'] ?? '',
        'category' => $parsed['category'] ?? 'financial',
        'region'   => $parsed['region'] ?? 'global',
        'source'   => $signal['source'],
        'date'     => $signal['date'],
    ];
}

function slugify(string $s): string {
    $s = strtolower(trim($s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    $s = trim($s, '-');
    return substr($s, 0, 80) . '-' . substr(md5($s.time()), 0, 6);
}

// ── Persist post ──────────────────────────────────────────────
function savePost(array $post): string {
    $filename = BLOG_DIR . $post['slug'] . '.json';
    $post['published_at'] = date('c');
    $post['excerpt'] = substr(strip_tags($post['body']), 0, 200) . '...';
    // Generate unique og:image URL — 1200x630 PNG, B&W themed, Google-indexable
    $post['og_image'] = 'https://mebusan.com/api/og-image.php?bw=1&t=' . urlencode(substr($post['title'],0,80))
        . '&c=' . urlencode($post['category']) . '&d=' . urlencode(date('j F Y', strtotime($post['published_at'])));
    // Article structured data for Google
    $post['schema'] = [
        '@context' => 'https://schema.org',
        '@type'    => 'Article',
        'headline' => $post['title'],
        'image'    => $post['og_image'],
        'description' => $post['excerpt'],
        'author'   => ['@type'=>'Organization','name'=>'Mebusan Intelligence','url'=>'https://mebusan.com'],
        'publisher'=> ['@type'=>'Organization','name'=>'Mebusan','logo'=>['@type'=>'ImageObject','url'=>'https://mebusan.com/favicon.ico']],
        'datePublished' => $post['published_at'],
        'url'      => 'https://mebusan.com/blog.html?post=' . $post['slug'],
        'mainEntityOfPage' => 'https://mebusan.com/blog.html?post=' . $post['slug'],
    ];
    file_put_contents($filename, json_encode($post, JSON_PRETTY_PRINT));
    updateBlogIndex($post);
    return $post['slug'];
}

function updateBlogIndex(array $post): void {
    $indexFile = BLOG_DIR . '_index.json';
    $index = file_exists($indexFile) ? json_decode(file_get_contents($indexFile), true) : [];
    // Remove existing entry for same slug
    $index = array_filter($index, fn($p) => $p['slug'] !== $post['slug']);
    array_unshift($index, [
        'slug'         => $post['slug'],
        'title'        => $post['title'],
        'excerpt'      => $post['excerpt'],
        'category'     => $post['category'],
        'region'       => $post['region'],
        'source'       => $post['source'],
        'published_at' => $post['published_at'],
    ]);
    // Keep last 100 posts in index
    file_put_contents($indexFile, json_encode(array_values(array_slice($index, 0, 100))));
}

// ── Route ─────────────────────────────────────────────────────
if ($action === 'generate') {
    if (!canGenerate()) {
        echo json_encode(['success'=>false,'error'=>'Rate limited. Next generation available in 4 hours.']);
        exit;
    }
    $signal = fetchFreshSignal();
    if (!$signal) {
        echo json_encode(['success'=>false,'error'=>'No signal available']);
        exit;
    }
    $post = rewriteForMebusan($signal);
    if (!$post) {
        echo json_encode(['success'=>false,'error'=>'Rewrite failed']);
        exit;
    }
    $slug = savePost($post);
    markGenerated();
    echo json_encode(['success'=>true,'slug'=>$slug,'title'=>$post['title']]);
    exit;
}

if ($action === 'list' || !$action) {
    $indexFile = BLOG_DIR . '_index.json';
    $index = file_exists($indexFile) ? json_decode(file_get_contents($indexFile), true) : [];
    $page = max(1, (int)($_GET['page'] ?? 1));
    $perPage = 12;
    $offset = ($page - 1) * $perPage;
    $cat = $_GET['cat'] ?? 'all';
    if ($cat !== 'all') {
        $index = array_values(array_filter($index, fn($p) => $p['category'] === $cat));
    }
    echo json_encode([
        'success' => true,
        'posts'   => array_slice($index, $offset, $perPage),
        'total'   => count($index),
        'page'    => $page,
        'pages'   => ceil(count($index) / $perPage),
    ]);
    exit;
}

if ($id) {
    $file = BLOG_DIR . preg_replace('/[^a-z0-9-]/', '', $id) . '.json';
    if (!file_exists($file)) {
        http_response_code(404);
        echo json_encode(['success'=>false,'error'=>'Post not found']);
        exit;
    }
    echo file_get_contents($file);
    exit;
}

echo json_encode(['success'=>false,'error'=>'Unknown action']);
