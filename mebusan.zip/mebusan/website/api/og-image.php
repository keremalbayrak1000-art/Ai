<?php
/**
 * MEBUSAN — OG Image Generator
 * Generates real 1200x630 PNG images for Google indexing and social sharing.
 * Uses PHP GD library (available on Hostinger, no external dependencies).
 * 
 * Endpoints:
 *   /api/og-image.php?t=TITLE&c=CATEGORY&d=DATE           → Mebusan branding
 *   /api/og-image.php?t=TITLE&c=CATEGORY&d=DATE&brand=ka  → keremalbayrak branding
 *
 * Theme is deterministic per title (same title = same theme, always).
 * Output: image/png at 1200x630px — crisp, HD, Google-indexable
 */

$title    = substr(strip_tags($_GET['t'] ?? 'Mebusan Intelligence'), 0, 90);
$category = strtolower(strip_tags($_GET['c'] ?? 'intelligence'));
$date     = strip_tags($_GET['d'] ?? date('j F Y'));
$brand    = strtolower($_GET['brand'] ?? 'mebusan');
$bw = isset($_GET['bw']) || $brand === 'blog'; // B&W mode for blog posts

// ── Deterministic theme selection (hash of title) ──────────────
$themes = ['grid','diagonal','dots','waves','circuit','clean'];
$themeIdx = abs(crc32($title)) % count($themes);
$theme = $themes[$themeIdx];

// ── Category colour mapping ────────────────────────────────────
$catColors = [
    'banking'    => [200, 160, 58],
    'financial'  => [200, 160, 58],
    'regulatory' => [58,  122, 88],
    'sanctions'  => [138, 42,  34],
    'political'  => [224, 112, 48],
    'crypto'     => [100, 180, 220],
    'default'    => [200, 160, 58],
];
$accentRGB = $bw ? [200, 200, 200] : ($catColors[$category] ?? $catColors['default']);

// B&W: override background to pure near-black
if ($bw) {
    // Slightly lighter grey scale tones
    $bgTone = 8;
} else {
    $bgTone = 10;
}

// ── GD canvas ─────────────────────────────────────────────────
$W = 1200; $H = 630;
$img = imagecreatetruecolor($W, $H);
imagealphablending($img, true);
imagesavealpha($img, true);

// Background — near-black with slight warmth
$bg = imagecolorallocate($img, $bgTone ?? 10, ($bgTone ?? 10)-1, ($bgTone ?? 10)-3);
imagefilledrectangle($img, 0, 0, $W, $H, $bg);

// ── Theme pattern rendering ───────────────────────────────────
$lineCol = imagecolorallocatealpha($img, 40, 36, 28, 115);  // very subtle line
$accentA = imagecolorallocatealpha($img, $accentRGB[0], $accentRGB[1], $accentRGB[2], 100); // faint accent

switch($theme) {
    case 'grid':
        // Technical grid pattern
        for($x = 0; $x < $W; $x += 48) imageline($img, $x, 0, $x, $H, $lineCol);
        for($y = 0; $y < $H; $y += 48) imageline($img, 0, $y, $W, $y, $lineCol);
        // Accent highlight at grid intersections near centre
        $cx = $W/2; $cy = $H/2;
        $accentB = imagecolorallocatealpha($img, $accentRGB[0], $accentRGB[1], $accentRGB[2], 120);
        imagearc($img, $cx, $cy, 300, 300, 0, 360, $accentB);
        imagearc($img, $cx, $cy, 200, 200, 0, 360, $accentB);
        break;

    case 'diagonal':
        // Diagonal line pattern — like a Bloomberg terminal
        for($i = -$H; $i < $W + $H; $i += 32) {
            imageline($img, $i, 0, $i + $H, $H, $lineCol);
        }
        break;

    case 'dots':
        // Subtle dot grid
        for($x = 24; $x < $W; $x += 40) {
            for($y = 24; $y < $H; $y += 40) {
                imagefilledellipse($img, $x, $y, 2, 2, $lineCol);
            }
        }
        break;

    case 'waves':
        // Sine wave lines — sophisticated
        for($wave = 0; $wave < 8; $wave++) {
            $prevX = 0; $prevY = $H/2 + sin(0) * 40;
            for($x = 1; $x < $W; $x += 2) {
                $y = ($H / 2) + sin(($x / $W * M_PI * 3) + $wave * M_PI/4) * (40 + $wave * 8);
                imageline($img, $prevX, $prevY, $x, $y, $lineCol);
                $prevX = $x; $prevY = $y;
            }
        }
        break;

    case 'circuit':
        // Circuit board inspired
        for($i = 0; $i < 20; $i++) {
            $x1 = rand(0, $W); $y1 = rand(0, $H);
            $x2 = $x1 + rand(-120, 120); $y2 = $y1;
            imageline($img, $x1, $y1, $x2, $y2, $lineCol);
            $x3 = $x2; $y3 = $y2 + rand(-80, 80);
            imageline($img, $x2, $y2, $x3, $y3, $lineCol);
        }
        break;

    case 'clean':
    default:
        // Minimal — just a subtle radial vignette
        break;
}

// ── Left accent bar ────────────────────────────────────────────
$accentSolid = imagecolorallocate($img, $accentRGB[0], $accentRGB[1], $accentRGB[2]);
imagefilledrectangle($img, 0, 0, 4, $H, $accentSolid);

// ── Top gradient simulation (darker top) ───────────────────────
for($y = 0; $y < 120; $y++) {
    $alpha = (int)(120 - ($y / 120 * 120));
    $fadeCol = imagecolorallocatealpha($img, 7, 7, 7, $alpha);
    imageline($img, 5, $y, $W, $y, $fadeCol);
}

// ── Bottom bar ────────────────────────────────────────────────
imagefilledrectangle($img, 0, $H - 56, $W, $H, imagecolorallocate($img, 13, 11, 8));
imageline($img, 0, $H - 56, $W, $H - 56, imagecolorallocatealpha($img, 200, 160, 58, 100));

// ── Text rendering function ───────────────────────────────────
function drawText($img, $text, $x, $y, $size, $r, $g, $b, $a = 0) {
    $col = $a > 0 ? imagecolorallocatealpha($img, $r, $g, $b, $a) : imagecolorallocate($img, $r, $g, $b);
    // Use built-in GD fonts (no TTF needed)
    // Font 5 = large, Font 4 = medium, Font 3 = normal, Font 2 = small, Font 1 = tiny
    imagestring($img, $size, $x, $y, $text, $col);
}

function drawTextWrap($img, $text, $x, $y, $maxWidth, $fontSize, $r, $g, $b) {
    $charWidth = imagefontwidth($fontSize);
    $lineHeight = imagefontheight($fontSize) + 8;
    $charsPerLine = max(1, (int)($maxWidth / $charWidth));
    $lines = wordwrap($text, $charsPerLine, "\n", false);
    $lineArr = explode("\n", $lines);
    $col = imagecolorallocate($img, $r, $g, $b);
    foreach($lineArr as $i => $line) {
        imagestring($img, $fontSize, $x, $y + $i * $lineHeight, $line, $col);
    }
    return count($lineArr);
}

// ── Brand / logo area ─────────────────────────────────────────
if($brand === 'ka') {
    // keremalbayrak.com branding
    drawText($img, 'KEREM ALBAYRAK', 32, 32, 3, $accentRGB[0], $accentRGB[1], $accentRGB[2]);
    drawText($img, 'keremalbayrak.com', 32, 52, 2, 90, 84, 72);
} else {
    // MEBUSAN branding
    drawText($img, 'MEBUSAN', 32, 32, 4, 232, 226, 212);
    drawText($img, 'Intelligence  Singapore', 32, 58, 2, 90, 84, 72);
}

// ── Category badge ────────────────────────────────────────────
$catUpper = strtoupper($category);
$badgeW = strlen($catUpper) * imagefontwidth(2) + 20;
$badgeCol = imagecolorallocatealpha($img, $accentRGB[0], $accentRGB[1], $accentRGB[2], 100);
imagefilledrectangle($img, 32, $H - 44, 32 + $badgeW, $H - 28, $badgeCol);
drawText($img, $catUpper, 42, $H - 44, 2, $accentRGB[0], $accentRGB[1], $accentRGB[2]);

// ── Date ─────────────────────────────────────────────────────
$dateX = $W - strlen($date) * imagefontwidth(2) - 32;
drawText($img, $date, $dateX, $H - 40, 2, 90, 84, 72);

// ── Title — the main event ────────────────────────────────────
// Large, wrapped, cream coloured
$titleLines = drawTextWrap($img, strtoupper($title), 32, $H - 220, $W - 80, 4, $bw?255:232, $bw?255:226, $bw?255:212);

// If title is short, also draw a subtitle line
if(strlen($title) < 60) {
    drawText($img, 'Intelligence Signal', 32, $H - 160, 3, $accentRGB[0], $accentRGB[1], $accentRGB[2], 60);
}

// ── Horizontal rule above title ───────────────────────────────
imageline($img, 32, $H - 230, 200, $H - 230, $accentSolid);

// ── Output PNG ────────────────────────────────────────────────
header('Content-Type: image/png');
header('Cache-Control: public, max-age=86400');
header('X-Image-Theme: ' . $theme);
imagepng($img, null, 6);  // compression 6 = good quality/size balance
imagedestroy($img);
