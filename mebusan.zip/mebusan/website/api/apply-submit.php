<?php
/**
 * Mebusan · Application Submission Handler
 *
 * POST endpoint for /apply.html and /pricing.html
 *
 * Flow:
 *   1. Validate input + hCaptcha
 *   2. Auto-determine recommended tier (jurisdictions + concern + contact)
 *   3. Save application to data/applications/
 *   4. If Monitor or Advisory: auto-create Stripe Checkout, return URL (ZERO HUMAN)
 *   5. If Private: queue for analyst review, send notification to principal
 *   6. Return JSON with next step
 *
 * The principle: Monitor and Advisory complete without a human touching anything.
 * Only Private applicants are routed to a human, and only for their first contact.
 */

require_once __DIR__ . '/../config.php';
global $MEBUSAN_TIERS;

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') mb_json(['error' => 'method_not_allowed'], 405);

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data) $data = $_POST;

// ─── Input validation ─────────────────────────────────────────
$jurisdiction_count = (int)($data['jurisdiction_count']  ?? 0);
$asset_types        = (array)($data['asset_types']       ?? []);
$concern_level      = (string)($data['concern_level']    ?? 'low');
$contact_preference = (string)($data['contact_preference']?? 'weekly');
$billing_cycle      = (string)($data['billing_cycle']    ?? 'monthly');
$email              = trim((string)($data['email']       ?? ''));
$alias              = trim((string)($data['alias']       ?? ''));
$chosen_tier        = (string)($data['chosen_tier']      ?? ''); // optional override
$captcha_token      = (string)($data['hcaptcha_token']   ?? '');
$jurisdictions      = (array)($data['jurisdictions']     ?? []);

// Basic validation
if ($jurisdiction_count < 1) mb_json(['error' => 'jurisdictions_required'], 400);
if (!in_array($concern_level, ['low','medium','high'])) $concern_level = 'low';
if (!in_array($contact_preference, ['weekly','alert','dedicated'])) $contact_preference = 'weekly';
if (!in_array($billing_cycle, ['monthly','annual'])) $billing_cycle = 'monthly';
if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) mb_json(['error' => 'email_required'], 400);

// hCaptcha verification (skip if not configured yet)
if (HCAPTCHA_SECRET && $captcha_token) {
    $verify = @file_get_contents('https://hcaptcha.com/siteverify?' . http_build_query([
        'secret' => HCAPTCHA_SECRET,
        'response' => $captcha_token,
    ]));
    $res = $verify ? json_decode($verify, true) : null;
    if (!$res || empty($res['success'])) mb_json(['error' => 'captcha_failed'], 400);
}

// ─── Auto-tier assignment ────────────────────────────────────
$recommended_tier = mebusan_auto_tier($jurisdiction_count, $concern_level, $contact_preference);

// Client can override but with guards: can't downgrade from Private auto-recommendation
$final_tier = $recommended_tier;
if ($chosen_tier && in_array($chosen_tier, ['monitor','advisory','private'])) {
    // Allow upgrade, disallow bypassing Private auto-route
    if ($recommended_tier === 'private' && $chosen_tier !== 'private') {
        $final_tier = 'private'; // force
    } else {
        $final_tier = $chosen_tier;
    }
}

// ─── Create application record ───────────────────────────────
$app_id = mb_client_id();
$application = [
    'id'                  => $app_id,
    'submitted_at'        => time(),
    'ip_hash'             => hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . ADMIN_SESSION_SECRET),
    'email'               => $email,
    'alias'               => $alias ?: null,
    'jurisdiction_count'  => $jurisdiction_count,
    'jurisdictions'       => array_slice($jurisdictions, 0, 40),
    'asset_types'         => $asset_types,
    'concern_level'       => $concern_level,
    'contact_preference'  => $contact_preference,
    'billing_cycle'       => $billing_cycle,
    'recommended_tier'    => $recommended_tier,
    'chosen_tier'         => $chosen_tier ?: null,
    'final_tier'          => $final_tier,
    'status'              => 'pending',
];

$apps_dir = MB_DATA_DIR . '/applications';
if (!is_dir($apps_dir)) @mkdir($apps_dir, 0755, true);
@file_put_contents($apps_dir . '/' . $app_id . '.json', json_encode($application, JSON_PRETTY_PRINT));

mb_log('apply', "New application: $app_id tier=$final_tier email=" . substr($email, 0, 3) . '***');

// ─── Route by tier ───────────────────────────────────────────
if ($final_tier === 'private') {
    // Human required. Notify principal analyst.
    notify_private_applicant($application);

    // Return friendly "we'll be in touch" response
    mb_json([
        'ok' => true,
        'tier' => 'private',
        'app_id' => $app_id,
        'message' => 'Application received. An advisor will reach out within 24 hours using your preferred channel.',
        'next' => 'wait_for_analyst',
    ]);
}

// ─── Monitor / Advisory: fully automated ─────────────────────
// Create Stripe Checkout session, redirect user to payment.
// On successful payment, stripe-webhook.php auto-activates the client.
$tier_config = $MEBUSAN_TIERS[$final_tier];
$price_id = $billing_cycle === 'annual' ? $tier_config['stripe_annual'] : $tier_config['stripe_monthly'];

if (!$price_id || !STRIPE_SECRET_KEY) {
    // Stripe not configured yet — fall back to human review
    notify_private_applicant($application, true);
    mb_json([
        'ok' => true,
        'tier' => $final_tier,
        'app_id' => $app_id,
        'message' => 'Application received. We will send activation instructions within 24 hours.',
        'next' => 'awaiting_setup',
    ]);
}

$checkout_url = create_stripe_checkout($app_id, $email, $price_id, $final_tier);
if (!$checkout_url) {
    mb_json(['error' => 'checkout_create_failed', 'app_id' => $app_id], 500);
}

mark_application_checkout_created($app_id, $checkout_url);

mb_json([
    'ok' => true,
    'tier' => $final_tier,
    'app_id' => $app_id,
    'checkout_url' => $checkout_url,
    'message' => 'Continue to payment to activate access.',
    'next' => 'checkout',
]);


/**
 * ═══════════════════════════════════════════════════════════════
 * Stripe checkout creation
 * ═══════════════════════════════════════════════════════════════
 */
function create_stripe_checkout($app_id, $email, $price_id, $tier) {
    $payload = http_build_query([
        'mode' => 'subscription',
        'success_url' => MB_SITE_URL . '/apply.html?success=1&app=' . $app_id,
        'cancel_url'  => MB_SITE_URL . '/apply.html?cancelled=1&app=' . $app_id,
        'customer_email' => $email,
        'client_reference_id' => $app_id,
        'line_items[0][price]' => $price_id,
        'line_items[0][quantity]' => 1,
        'metadata[app_id]' => $app_id,
        'metadata[tier]' => $tier,
        'allow_promotion_codes' => 'true',
        'billing_address_collection' => 'auto',
    ]);

    $ch = curl_init('https://api.stripe.com/v1/checkout/sessions');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . STRIPE_SECRET_KEY,
            'Content-Type: application/x-www-form-urlencoded',
        ],
        CURLOPT_TIMEOUT => 10,
    ]);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code !== 200 || !$res) {
        mb_log('stripe', "Checkout creation failed: HTTP $code");
        return null;
    }
    $body = json_decode($res, true);
    return $body['url'] ?? null;
}

function mark_application_checkout_created($app_id, $url) {
    $f = MB_DATA_DIR . '/applications/' . $app_id . '.json';
    if (!file_exists($f)) return;
    $a = json_decode(file_get_contents($f), true);
    $a['checkout_url'] = $url;
    $a['status'] = 'checkout_created';
    @file_put_contents($f, json_encode($a, JSON_PRETTY_PRINT));
}

function notify_private_applicant($app, $fallback = false) {
    $subject = $fallback
        ? 'Mebusan · Application needs manual setup (Stripe not configured)'
        : 'Mebusan · New Private applicant';
    $body  = "Application: {$app['id']}\n";
    $body .= "Email: {$app['email']}\n";
    $body .= "Alias: " . ($app['alias'] ?: 'not provided') . "\n";
    $body .= "Jurisdictions: {$app['jurisdiction_count']}\n";
    $body .= "Concern: {$app['concern_level']}\n";
    $body .= "Contact pref: {$app['contact_preference']}\n";
    $body .= "Billing: {$app['billing_cycle']}\n\n";
    $body .= "Review: https://mebusan.com/admin/applications.php?id={$app['id']}\n";
    $headers = "From: Mebusan System <k.a@mebusan.com>\r\n";
    @mail(MB_CONTACT_EMAIL, $subject, $body, $headers);
}
