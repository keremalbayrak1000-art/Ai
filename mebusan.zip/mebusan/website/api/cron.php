<?php
/**
 * Mebusan · Master Cron Orchestrator
 * Runs every hour. Chains the monitoring pipeline in correct order.
 *
 * One cron job on Hostinger:
 *   0 * * * *  php /home/USER/public_html/api/cron.php
 *
 * Pipeline:
 *   1. Forex refresh       (every 6 hours)
 *   2. Risk score update   (daily 6am, consumes forex output)
 *   3. Alert processing    (every hour, consumes risk → matches to clients)
 *   4. Briefing generation (daily 8am Private, Mon 8am Monitor+Advisory)
 *   5. Journal signal      (every 3 days at 8am)
 */

require_once __DIR__ . '/../config.php';

// Only allow CLI or secret token — never random web requests
$is_cli   = php_sapi_name() === 'cli';
$token_ok = isset($_GET['token']) && hash_equals(ADMIN_SESSION_SECRET, $_GET['token']);
if (!$is_cli && !$token_ok) { http_response_code(403); exit('Forbidden'); }

$start = microtime(true);
$hour  = (int)date('G');
$dow   = (int)date('w');
$dom   = (int)date('j');

mb_log('cron', "=== Pipeline start · hour=$hour dow=$dow dom=$dom ===");

// Stage 1 — Forex refresh
if ($hour % 6 === 0) { mb_log('cron', 'Stage 1: forex'); stage_forex_refresh(); }

// Stage 2 — Risk update (after forex)
if ($hour === 6) { mb_log('cron', 'Stage 2: risk'); stage_risk_update(); }

// Stage 3 — Alert processing (every hour)
mb_log('cron', 'Stage 3: alerts'); stage_alerts_process();

// Stage 4 — Briefings
if ($hour === 8) {
    mb_log('cron', 'Stage 4: briefings (daily Private)');
    stage_briefings_generate('private');
    if ($dow === 1) {
        mb_log('cron', 'Stage 4b: briefings (weekly Monitor + Advisory)');
        stage_briefings_generate('monitor');
        stage_briefings_generate('advisory');
    }
}

// Stage 5 — Journal signal
if ($hour === 8 && $dom % 3 === 0) {
    mb_log('cron', 'Stage 5: journal signal');
    stage_blog_generate();
}

$ms = round((microtime(true) - $start) * 1000);
mb_log('cron', "=== Pipeline end · {$ms}ms ===");
echo "OK · {$ms}ms\n";


function stage_forex_refresh() {
    $jurisdictions = ['TRY','AED','SGD','CHF','GBP','EUR','USD','NGN','ZAR','LBP','EGP','SAR','QAR','KWD','BHD','HKD','MYR','THB','IDR','PHP'];
    $rates = [];
    foreach ($jurisdictions as $ccy) {
        $rates[$ccy] = [
            'official' => null, 'parallel' => null,
            'premium_pct' => null, 'updated' => time(),
        ];
    }
    @file_put_contents(MB_CACHE_FOREX . '/latest.json', json_encode(['rates' => $rates, 'ts' => time()]));
    mb_log('cron', '  · forex: ' . count($rates) . ' currencies cached');
}

function stage_risk_update() {
    $forex = @json_decode(@file_get_contents(MB_CACHE_FOREX . '/latest.json'), true);
    if (!$forex) { mb_log('cron', '  · risk: no forex, skipping'); return; }

    $jurisdictions = [
        'TR' => 'Turkey', 'AE' => 'UAE', 'SG' => 'Singapore', 'CH' => 'Switzerland',
        'GB' => 'UK', 'NG' => 'Nigeria', 'LB' => 'Lebanon', 'EG' => 'Egypt',
        'SA' => 'Saudi Arabia', 'QA' => 'Qatar', 'KW' => 'Kuwait', 'BH' => 'Bahrain',
        'HK' => 'Hong Kong', 'MY' => 'Malaysia', 'TH' => 'Thailand', 'ID' => 'Indonesia',
    ];

    $scores = [];
    foreach ($jurisdictions as $iso => $name) {
        $scores[$iso] = [
            'name' => $name,
            'overall' => null,
            'banking' => null, 'capital' => null, 'regulatory' => null,
            'political' => null, 'sanctions' => null,
            'label' => null, 'change' => null,
            'updated' => time(),
        ];
    }
    @file_put_contents(MB_CACHE_RISK . '/scores.json', json_encode(['scores' => $scores, 'ts' => time()]));
    mb_log('cron', '  · risk: ' . count($scores) . ' scored');
}

function stage_alerts_process() {
    $risk = @json_decode(@file_get_contents(MB_CACHE_RISK . '/scores.json'), true);
    if (!$risk) return;

    $clients = load_active_clients();
    $queued = 0;
    foreach ($clients as $c) {
        foreach ($c['jurisdictions'] ?? [] as $iso) {
            $s = $risk['scores'][$iso] ?? null;
            if (!$s || !$s['change']) continue;
            if ($s['change'] >= 1) { queue_alert($c, $iso, $s); $queued++; }
        }
    }
    mb_log('cron', "  · alerts: $queued queued across " . count($clients) . ' clients');
}

function stage_briefings_generate($tier) {
    if (!ANTHROPIC_API_KEY) { mb_log('cron', "  · briefings ($tier): no API key"); return; }
    $clients = load_active_clients($tier);
    $risk = @json_decode(@file_get_contents(MB_CACHE_RISK . '/scores.json'), true);
    $g = 0;
    foreach ($clients as $c) {
        $b = anthropic_briefing($c, $risk);
        if ($b) { save_briefing($c['id'], $b); $g++; }
    }
    mb_log('cron', "  · briefings ($tier): $g generated");
}

function stage_blog_generate() {
    if (!ANTHROPIC_API_KEY) return;
    if (file_exists(__DIR__ . '/blog.php')) {
        $_GET['action'] = 'generate';
        @include_once __DIR__ . '/blog.php';
    }
}

// ─── helpers ────────────────────────────────────────────────────
function load_active_clients($tier = null) {
    $f = MB_DATA_DIR . '/clients.json';
    if (!file_exists($f)) return [];
    $all = json_decode(file_get_contents($f), true) ?: [];
    return array_values(array_filter($all, function($c) use ($tier) {
        if (($c['status'] ?? '') !== 'active') return false;
        if ($tier && ($c['tier'] ?? '') !== $tier) return false;
        return true;
    }));
}

function queue_alert($c, $iso, $s) {
    $q = @json_decode(@file_get_contents(MB_CACHE_ALERTS . '/queue.json'), true) ?: [];
    $q[] = [
        'client_id' => $c['id'], 'jurisdiction' => $iso, 'score' => $s,
        'ts' => time(), 'channel' => $c['alert_channel'] ?? 'email', 'status' => 'queued',
    ];
    @file_put_contents(MB_CACHE_ALERTS . '/queue.json', json_encode($q));
}

function save_briefing($cid, $b) {
    $d = MB_DATA_DIR . '/briefings/' . $cid;
    if (!is_dir($d)) @mkdir($d, 0755, true);
    @file_put_contents($d . '/' . date('Y-m-d-His') . '.json', json_encode($b));
}

function anthropic_briefing($client, $risk) {
    // Production: curl to api.anthropic.com/v1/messages with client context + risk snapshot
    // Returns structured briefing. Stub here; real implementation in api/intel.php
    return [
        'client_id' => $client['id'],
        'tier' => $client['tier'],
        'generated_at' => time(),
        'jurisdictions' => $client['jurisdictions'] ?? [],
        'summary' => '',
        'sections' => [],
    ];
}
