<?php
/**
 * MEBUSAN · Sign submission
 * ─────────────────────────────────────────────────────────────────
 * POST application/json with {t, method, strokes?, canvas_w?, canvas_h?,
 *                             typed_name?, consent, session_ms, interactions}
 *
 * Flow:
 *   1. Validate HMAC token → load session
 *   2. Reject if already signed or expired
 *   3. Bot heuristics (session_ms, interactions)
 *   4. Generate signed PDF with signature embedded
 *   5. Compute SHA-256, store signed PDF, update session file
 *   6. Append immutable audit record
 *   7. Email countersigned PDF to client via engagement-signed template
 *   8. Return success
 */

declare(strict_types=1);
header('Content-Type: application/json');
require_once __DIR__ . '/_security.php';
require_once __DIR__ . '/../emails/lib/mailer.php';
MebusanSecurity::applyApiHeaders();

MebusanSecurity::rateLimit('sign-submit', 5, 600); // max 5 attempts per 10 min

$raw = file_get_contents('php://input') ?: '';
if (strlen($raw) > 2_000_000) { // 2 MB cap on signature payload
    http_response_code(413);
    echo json_encode(['success' => false, 'error' => 'payload too large']);
    exit;
}

$body = json_decode($raw, true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'invalid json']);
    exit;
}

$token       = (string)($body['t'] ?? '');
$method      = (string)($body['method'] ?? '');
$consent     = !empty($body['consent']);
$sessionMs   = (int)($body['session_ms'] ?? 0);
$interactions = (int)($body['interactions'] ?? 0);

// Bot heuristics
if (!$consent) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'consent required']);
    exit;
}
if ($sessionMs < 3000 || $interactions < 3) {
    // Likely automated — quiet failure
    MebusanSecurity::auditLog('sign-submit-rejected', ['reason' => 'heuristic', 'ms' => $sessionMs, 'ints' => $interactions]);
    http_response_code(429);
    echo json_encode(['success' => false, 'error' => 'please try again']);
    exit;
}

// Load session
try {
    $session = MebusanSecurity::verifySigningToken($token);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'invalid token']);
    exit;
}
if (!$session) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'session not found']);
    exit;
}
if (!empty($session['expires_at']) && strtotime((string)$session['expires_at']) < time()) {
    http_response_code(410);
    echo json_encode(['success' => false, 'error' => 'session expired']);
    exit;
}
if (!empty($session['signed'])) {
    http_response_code(409);
    echo json_encode(['success' => false, 'error' => 'already signed']);
    exit;
}

// Validate signature payload based on method
if ($method === 'drawn') {
    $strokes = $body['strokes'] ?? [];
    if (!is_array($strokes) || empty($strokes)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'signature required']);
        exit;
    }
    // Sanitise strokes — only allow {x,y,p} floats, cap sizes
    $cleaned = [];
    foreach ($strokes as $stroke) {
        if (!is_array($stroke)) continue;
        $pts = [];
        foreach ($stroke as $pt) {
            if (!is_array($pt)) continue;
            $pts[] = [
                'x' => max(0.0, min(10000.0, (float)($pt['x'] ?? 0))),
                'y' => max(0.0, min(10000.0, (float)($pt['y'] ?? 0))),
                'p' => max(0.0, min(1.0, (float)($pt['p'] ?? 0.5))),
            ];
            if (count($pts) > 2000) break;
        }
        if (count($pts) >= 2) $cleaned[] = $pts;
        if (count($cleaned) > 60) break;
    }
    if (empty($cleaned)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'signature too brief']);
        exit;
    }
    $sigPayload = [
        'method'    => 'drawn',
        'strokes'   => $cleaned,
        'canvas_w'  => (float)($body['canvas_w'] ?? 520),
        'canvas_h'  => (float)($body['canvas_h'] ?? 180),
    ];
} elseif ($method === 'typed') {
    $typed = trim((string)($body['typed_name'] ?? ''));
    if (mb_strlen($typed) < 2 || mb_strlen($typed) > 120) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'name required']);
        exit;
    }
    $sigPayload = [
        'method'     => 'typed',
        'typed_name' => $typed,
    ];
} else {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'unknown method']);
    exit;
}

// Compute base-document hash for anchoring (hash the unsigned bytes)
$root = dirname(__DIR__);
$generator = require $root . '/emails/pdf/engagement-letter.php';
$unsigned = $generator([
    'name'            => $session['name'] ?? '',
    'name_slug'       => $session['name_slug'] ?? '',
    'tier'            => $session['tier'] ?? '',
    'confirmation_id' => $session['confirmation_id'] ?? '',
    'signature'       => null,
]);
$baseHash = hash('sha256', $unsigned['content']);

// Compose attestation metadata
$ipMasked = MebusanSecurity::maskIp($_SERVER['REMOTE_ADDR'] ?? '');
$sigPayload['signed_at']   = date('c');
$sigPayload['ip_masked']   = $ipMasked;
$sigPayload['document_id'] = $session['document_id'] ?? '';
$sigPayload['base_hash']   = $baseHash;

// Generate signed PDF
$signed = $generator([
    'name'            => $session['name'] ?? '',
    'name_slug'       => $session['name_slug'] ?? '',
    'tier'            => $session['tier'] ?? '',
    'confirmation_id' => $session['confirmation_id'] ?? '',
    'signature'       => $sigPayload,
]);
$signedBytes = $signed['content'];
$signedHash  = hash('sha256', $signedBytes);

// Persist signed PDF
$signedDir = $root . '/cache/signed_documents';
if (!is_dir($signedDir)) @mkdir($signedDir, 0755, true);
$sessionSafeId = preg_replace('/[^A-Za-z0-9_-]/', '', $session['session_id']);
file_put_contents($signedDir . '/' . $sessionSafeId . '.pdf', $signedBytes);

// Update session
$session['signed']         = true;
$session['signed_at']      = $sigPayload['signed_at'];
$session['method']         = $method;
$session['document_hash']  = $signedHash;
$session['base_hash']      = $baseHash;
$session['ip_masked']      = $ipMasked;
$session['user_agent']     = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 400);
$session['session_ms']     = $sessionMs;
$session['interactions']   = $interactions;
$session['tz_offset']      = (int)($body['tz_offset'] ?? 0);
MebusanSecurity::saveSigningSession($session);

// Immutable audit log
MebusanSecurity::auditLog('signed', [
    'session_id'    => $session['session_id'],
    'document_id'   => $session['document_id'],
    'email_masked'  => MebusanSecurity::maskEmail($session['email'] ?? ''),
    'tier'          => $session['tier'] ?? '',
    'method'        => $method,
    'document_hash' => $signedHash,
    'base_hash'     => $baseHash,
    'ip_masked'     => $ipMasked,
    'ua'            => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 200),
    'session_ms'    => $sessionMs,
    'interactions'  => $interactions,
]);

// Email countersigned copy
try {
    $mailer = new MebusanMailer();
    $mailer->send([
        'to'         => $session['email'],
        'to_name'    => $session['name'] ?? '',
        'template'   => 'engagement-signed',
        'vars'       => array_merge($session, [
            'signed_at_human' => date('j M Y · H:i') . ' UTC',
            'document_hash_short' => substr($signedHash, 0, 16) . '…',
        ]),
        'attach_raw_pdf'      => [
            'filename' => 'mebusan-engagement-' . ($session['name_slug'] ?? 'signed') . '-signed.pdf',
            'content'  => $signedBytes,
        ],
        'category'   => 'transactional',
    ]);
} catch (Throwable $e) {
    // Log but do not fail the sign — audit + session already recorded
    MebusanSecurity::auditLog('sign-email-failed', ['session' => $session['session_id'], 'err' => $e->getMessage()]);
}

echo json_encode([
    'success'       => true,
    'document_hash' => $signedHash,
]);
