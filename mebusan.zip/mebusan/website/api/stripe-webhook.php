<?php
/**
 * Mebusan · Stripe Webhook Handler
 * Auto-manages client subscriptions. No human touches this.
 *
 * Endpoint: https://mebusan.com/api/stripe-webhook.php
 *
 * Events handled:
 *   - checkout.session.completed        → activate client, send onboarding
 *   - customer.subscription.created     → log + tier assignment
 *   - customer.subscription.updated     → tier changes (upgrade/downgrade)
 *   - customer.subscription.deleted     → deactivate client
 *   - invoice.payment_succeeded         → extend access period
 *   - invoice.payment_failed            → flag, notify on second failure
 *
 * Configure in Stripe dashboard:
 *   Dashboard → Developers → Webhooks → Add endpoint
 *   URL: https://mebusan.com/api/stripe-webhook.php
 *   Events: the six above
 *   Copy signing secret to STRIPE_WEBHOOK_SECRET in config.php
 */

require_once __DIR__ . '/../config.php';

// Verify Stripe signature to prevent forgery
$payload = @file_get_contents('php://input');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

if (!$sig_header || !STRIPE_WEBHOOK_SECRET) {
    mb_log('stripe', 'Missing signature or secret');
    http_response_code(400); exit;
}

// Parse signature (format: t=timestamp,v1=signature)
$parts = [];
foreach (explode(',', $sig_header) as $p) {
    $kv = explode('=', $p, 2);
    if (count($kv) === 2) $parts[$kv[0]] = $kv[1];
}
$timestamp = $parts['t'] ?? null;
$expected = $parts['v1'] ?? null;
if (!$timestamp || !$expected) { http_response_code(400); exit; }

$signed_payload = $timestamp . '.' . $payload;
$computed = hash_hmac('sha256', $signed_payload, STRIPE_WEBHOOK_SECRET);
if (!hash_equals($computed, $expected)) {
    mb_log('stripe', 'Signature mismatch'); http_response_code(400); exit;
}

// Reject events older than 5 minutes (replay protection)
if (abs(time() - (int)$timestamp) > 300) {
    mb_log('stripe', 'Event too old'); http_response_code(400); exit;
}

$event = json_decode($payload, true);
if (!$event) { http_response_code(400); exit; }

$type = $event['type'] ?? '';
$obj  = $event['data']['object'] ?? [];

mb_log('stripe', "Event received: $type");

try {
    switch ($type) {
        case 'checkout.session.completed':       handle_checkout_completed($obj);       break;
        case 'customer.subscription.created':    handle_subscription_created($obj);     break;
        case 'customer.subscription.updated':    handle_subscription_updated($obj);     break;
        case 'customer.subscription.deleted':    handle_subscription_deleted($obj);     break;
        case 'invoice.payment_succeeded':        handle_payment_succeeded($obj);        break;
        case 'invoice.payment_failed':           handle_payment_failed($obj);           break;
        default:
            mb_log('stripe', "Unhandled event: $type");
    }
    mb_json(['received' => true]);
} catch (Exception $e) {
    mb_log('stripe', 'Handler error: ' . $e->getMessage());
    mb_json(['error' => 'handler_failed'], 500);
}


function handle_checkout_completed($session) {
    // Fires when user completes Stripe Checkout
    $client_ref = $session['client_reference_id'] ?? null; // application ID we passed in
    $customer   = $session['customer'] ?? null;
    $sub        = $session['subscription'] ?? null;
    $email      = $session['customer_email'] ?? null;

    if (!$client_ref) {
        mb_log('stripe', 'Checkout completed without client_reference_id'); return;
    }

    // Load the application, promote to client, activate immediately
    $application = load_application($client_ref);
    if (!$application) {
        mb_log('stripe', "Application $client_ref not found"); return;
    }

    $client = [
        'id'              => mb_client_id(),
        'application_id'  => $client_ref,
        'stripe_customer' => $customer,
        'stripe_sub'      => $sub,
        'email'           => $email ?: $application['email'] ?? null,
        'alias'           => $application['alias'] ?? null,
        'tier'            => $application['recommended_tier'],
        'jurisdictions'   => $application['jurisdictions'] ?? [],
        'asset_types'     => $application['asset_types'] ?? [],
        'alert_channel'   => $application['contact_preference'] ?? 'email',
        'status'          => 'active',
        'activated_at'    => time(),
        'onboarded'       => false,
    ];

    save_client($client);
    mark_application_converted($client_ref, $client['id']);

    // Kick off automated onboarding — no human needed
    send_onboarding_email($client);

    // Private tier: also notify the dedicated analyst (Kerem)
    if ($client['tier'] === 'private') {
        notify_principal_analyst($client);
    }

    mb_log('stripe', "Client activated: {$client['id']} tier={$client['tier']}");
}

function handle_subscription_created($sub) {
    // Recorded at handle_checkout_completed; this is secondary confirmation
    mb_log('stripe', 'Subscription created: ' . ($sub['id'] ?? '?'));
}

function handle_subscription_updated($sub) {
    // Tier change (upgrade/downgrade). Update client record.
    $client = find_client_by_stripe_sub($sub['id'] ?? '');
    if (!$client) return;

    $new_price = $sub['items']['data'][0]['price']['id'] ?? null;
    $new_tier = mb_tier_for_price($new_price);
    if (!$new_tier) return;

    if ($new_tier !== $client['tier']) {
        $client['tier'] = $new_tier;
        $client['tier_changed_at'] = time();
        save_client($client);
        mb_log('stripe', "Tier changed: {$client['id']} → $new_tier");

        // If upgraded to Private, notify analyst
        if ($new_tier === 'private') notify_principal_analyst($client);
    }
}

function handle_subscription_deleted($sub) {
    $client = find_client_by_stripe_sub($sub['id'] ?? '');
    if (!$client) return;
    $client['status'] = 'cancelled';
    $client['cancelled_at'] = time();
    save_client($client);
    mb_log('stripe', "Client cancelled: {$client['id']}");
}

function handle_payment_succeeded($invoice) {
    // Extend access; log for accounting
    $sub_id = $invoice['subscription'] ?? null;
    if (!$sub_id) return;
    $client = find_client_by_stripe_sub($sub_id);
    if (!$client) return;
    $client['last_payment'] = time();
    $client['next_renewal'] = $invoice['period_end'] ?? null;
    save_client($client);
    mb_log('stripe', "Payment ok: {$client['id']}");
}

function handle_payment_failed($invoice) {
    $sub_id = $invoice['subscription'] ?? null;
    if (!$sub_id) return;
    $client = find_client_by_stripe_sub($sub_id);
    if (!$client) return;
    $fails = ($client['payment_fails'] ?? 0) + 1;
    $client['payment_fails'] = $fails;
    save_client($client);
    mb_log('stripe', "Payment failed ($fails): {$client['id']}");
    // After 2 failures, notify principal for manual intervention
    if ($fails >= 2) notify_principal_analyst($client, 'payment_failure');
}


/**
 * ═══════════════════════════════════════════════════════════════
 * Data helpers — flat JSON store for now, swap for DB later
 * ═══════════════════════════════════════════════════════════════
 */
function load_application($id) {
    $f = MB_DATA_DIR . '/applications/' . $id . '.json';
    return file_exists($f) ? json_decode(file_get_contents($f), true) : null;
}

function mark_application_converted($app_id, $client_id) {
    $app = load_application($app_id);
    if (!$app) return;
    $app['status'] = 'converted';
    $app['client_id'] = $client_id;
    $app['converted_at'] = time();
    @file_put_contents(MB_DATA_DIR . '/applications/' . $app_id . '.json', json_encode($app));
}

function save_client($client) {
    $f = MB_DATA_DIR . '/clients.json';
    $all = file_exists($f) ? (json_decode(file_get_contents($f), true) ?: []) : [];
    $found = false;
    foreach ($all as $i => $c) {
        if ($c['id'] === $client['id']) { $all[$i] = $client; $found = true; break; }
    }
    if (!$found) $all[] = $client;
    @file_put_contents($f, json_encode($all, JSON_PRETTY_PRINT));
}

function find_client_by_stripe_sub($sub_id) {
    $f = MB_DATA_DIR . '/clients.json';
    if (!file_exists($f)) return null;
    $all = json_decode(file_get_contents($f), true) ?: [];
    foreach ($all as $c) { if (($c['stripe_sub'] ?? '') === $sub_id) return $c; }
    return null;
}

/**
 * ═══════════════════════════════════════════════════════════════
 * Onboarding — fully automated for Monitor/Advisory
 * ═══════════════════════════════════════════════════════════════
 */
function send_onboarding_email($client) {
    if (empty($client['email'])) return;
    global $MEBUSAN_TIERS;
    $tier = $MEBUSAN_TIERS[$client['tier']];

    $subject = 'Mebusan · Account active';
    $body = "Your Mebusan account is active.\n\n";
    $body .= "Client ID: {$client['id']}\n";
    $body .= "Tier: {$tier['name']}\n";
    $body .= "Response: within {$tier['response_hours']} hours\n";
    $body .= "Briefings: {$tier['briefing_frequency']}\n\n";
    $body .= "Portal: https://mebusan.com/portal.html\n";
    $body .= "Use your Client ID above to sign in. Your first briefing will arrive within seven days.\n\n";
    if ($client['tier'] === 'advisory') {
        $body .= "A named analyst will be in touch within 24 hours.\n\n";
    }
    $body .= "— Mebusan\n";
    $body .= "Singapore · mebusan.com\n";

    $headers = "From: Mebusan <k.a@mebusan.com>\r\n";
    $headers .= "Reply-To: k.a@mebusan.com\r\n";
    $headers .= "X-Mailer: Mebusan/1.0\r\n";
    @mail($client['email'], $subject, $body, $headers);
    mb_log('onboard', "Sent welcome to {$client['email']} ({$client['id']})");

    // Mark onboarded
    $client['onboarded'] = true;
    save_client($client);
}

function notify_principal_analyst($client, $reason = 'new_private_client') {
    $subject = 'Mebusan · ' . ($reason === 'new_private_client' ? 'New Private client' : 'Intervention needed');
    $body = "Client: {$client['id']}\n";
    $body .= "Tier: {$client['tier']}\n";
    $body .= "Email: " . ($client['email'] ?? 'n/a') . "\n";
    $body .= "Alias: " . ($client['alias'] ?? 'n/a') . "\n";
    $body .= "Jurisdictions: " . implode(', ', $client['jurisdictions'] ?? []) . "\n";
    $body .= "Reason: $reason\n\n";
    $body .= "Admin: https://mebusan.com/admin/clients.php?id={$client['id']}\n";
    @mail(MB_CONTACT_EMAIL, $subject, $body, "From: Mebusan System <k.a@mebusan.com>\r\n");
}
