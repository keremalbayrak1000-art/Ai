<?php
/**
 * MEBUSAN — hCaptcha Verification
 * POST { token: "hcaptcha-response-token" }
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';

$body  = json_decode(file_get_contents('php://input'), true) ?? [];
$token = trim($body['token'] ?? $_POST['h-captcha-response'] ?? '');

if (!$token) {
    echo json_encode(['success'=>false,'error'=>'No captcha token provided.']);
    exit;
}

// Dev mode if secret not configured
if (HCAPTCHA_SECRET === 'YOUR_HCAPTCHA_SECRET_KEY') {
    echo json_encode(['success'=>true,'dev'=>true]);
    exit;
}

$ch = curl_init('https://hcaptcha.com/siteverify');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => http_build_query([
        'secret'   => HCAPTCHA_SECRET,
        'response' => $token,
        'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '',
    ]),
    CURLOPT_TIMEOUT => 10,
]);
$resp = json_decode(curl_exec($ch), true);
curl_close($ch);

if ($resp['success'] ?? false) {
    echo json_encode(['success'=>true]);
} else {
    $errors = implode(', ', $resp['error-codes'] ?? ['verification-failed']);
    echo json_encode(['success'=>false,'error'=>$errors]);
}
