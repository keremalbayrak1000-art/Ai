<?php
/**
 * MEBUSAN — Intelligence Feed Aggregator v2
 * 118 curated sources across 7 categories
 * Self-hosted — no third-party proxy required
 * 15-minute server-side cache
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=900');

define('CACHE_DIR', __DIR__ . '/../cache/');
define('CACHE_TTL', 900);
if (!is_dir(CACHE_DIR)) mkdir(CACHE_DIR, 0755, true);

$SOURCES = [
  // ── Financial / Economic ──────────────────────────────────
  ['url'=>'https://feeds.reuters.com/reuters/businessNews',     'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://feeds.reuters.com/reuters/worldNews',        'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://www.ft.com/world?format=rss',                'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://feeds.bbci.co.uk/news/business/rss.xml',     'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://feeds.bbci.co.uk/news/world/rss.xml',        'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://rss.nytimes.com/services/xml/rss/nyt/Business.xml', 'cat'=>'financial', 'region'=>'global'],
  ['url'=>'https://rss.nytimes.com/services/xml/rss/nyt/Economy.xml',  'cat'=>'financial', 'region'=>'global'],
  // ── Regulatory / Compliance ───────────────────────────────
  ['url'=>'https://www.fatf-gafi.org/content/fatf-gafi/en/news.rss.xml', 'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://eur-lex.europa.eu/rss/daily/EN.xml',         'cat'=>'regulatory', 'region'=>'europe'],
  ['url'=>'https://www.ecb.europa.eu/rss/press.html',           'cat'=>'financial',  'region'=>'europe'],
  ['url'=>'https://www.bis.org/rss/press.rss',                  'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.imf.org/en/News/rss?language=eng',       'cat'=>'financial',  'region'=>'global'],
  // ── Geopolitical / Political ──────────────────────────────
  ['url'=>'https://www.aljazeera.com/xml/rss/all.xml',          'cat'=>'political',  'region'=>'middle-east'],
  ['url'=>'https://foreignpolicy.com/feed/',                    'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://www.politico.eu/feed/',                      'cat'=>'regulatory', 'region'=>'europe'],
  ['url'=>'https://www.theafricareport.com/feed/',              'cat'=>'political',  'region'=>'africa'],
  ['url'=>'https://www.middleeasteye.net/rss',                  'cat'=>'political',  'region'=>'middle-east'],
  ['url'=>'https://asia.nikkei.com/rss/feed/nar',              'cat'=>'financial',  'region'=>'asia'],
  ['url'=>'https://www.scmp.com/rss/91/feed',                   'cat'=>'political',  'region'=>'asia'],
  ['url'=>'https://www.voanews.com/api/zqmqvtmqv',             'cat'=>'political',  'region'=>'global'],
  // ── Crisis / Disaster / Risk ──────────────────────────────
  ['url'=>'https://www.gdacs.org/xml/rss.xml',                  'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://reliefweb.int/headlines/rss.xml',            'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://crisisgroup.org/crisiswatch/feed',           'cat'=>'political',  'region'=>'global'],
  // ── Sanctions / Legal / Enforcement ──────────────────────
  ['url'=>'https://home.treasury.gov/system/files/126/recent_actions.xml','cat'=>'regulatory','region'=>'global'],
  ['url'=>'https://sanctionsnews.bakermckenzie.com/feed/',      'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://www.jonesday.com/en/practices/s/sanctions/rss','cat'=>'regulatory','region'=>'global'],
  // ── Cryptocurrency / Digital Assets ───────────────────────
  ['url'=>'https://cointelegraph.com/rss',                      'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.coindesk.com/arc/outboundfeeds/rss/',    'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://bitcoinmagazine.com/feed',                   'cat'=>'financial',  'region'=>'global'],
  // ── Energy / Commodities / Oil ─────────────────────────────
  ['url'=>'https://oilprice.com/rss/main',                      'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.energymonitor.ai/feed/',                 'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.opec.org/opec_web/en/press_room/rss/pressReleasesRSS.xml','cat'=>'financial','region'=>'global'],
  // ── Real Estate / Property ────────────────────────────────
  ['url'=>'https://www.propertyweek.com/rss',                   'cat'=>'financial',  'region'=>'europe'],
  // ── APAC / Emerging Markets ───────────────────────────────
  ['url'=>'https://www.bangkokpost.com/rss/data/topstories.xml','cat'=>'political',  'region'=>'asia'],
  ['url'=>'https://www.thejakartapost.com/feed/',               'cat'=>'political',  'region'=>'asia'],
  ['url'=>'https://businessday.ng/feed/',                       'cat'=>'financial',  'region'=>'africa'],
  ['url'=>'https://www.moneyweb.co.za/feed/',                   'cat'=>'financial',  'region'=>'africa'],
  ['url'=>'https://egyptindependent.com/feed/',                 'cat'=>'political',  'region'=>'middle-east'],
  // ── Investigative / Transparency ─────────────────────────
  ['url'=>'https://www.transparency.org/feed',                  'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://www.globalwitness.org/en/blog/feed/',        'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://occrp.org/en/articles/rss',                  'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://www.icij.org/feed/',                         'cat'=>'regulatory', 'region'=>'global'],
  // ── Offshore / Wealth / Family Office ────────────────────
  ['url'=>'https://www.step.org/news/rss.xml',                  'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://campdenwealth.com/rss.xml',                  'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.familywealthreport.com/rss/latest_news.xml','cat'=>'financial','region'=>'global'],
  // ── CIS / Russia / Central Asia ──────────────────────────
  ['url'=>'https://www.eurasianet.org/feed',                    'cat'=>'political',  'region'=>'europe'],
  ['url'=>'https://meduza.io/rss2/en/news',                     'cat'=>'political',  'region'=>'europe'],
  // ── Turkey / Middle East / Financial ─────────────────────
  ['url'=>'https://www.hurriyetdailynews.com/rss.aspx',         'cat'=>'political',  'region'=>'europe'],
  ['url'=>'https://www.dailysabah.com/feeds/posts/latest',      'cat'=>'political',  'region'=>'europe'],
  ['url'=>'https://www.arabnews.com/rss.xml',                   'cat'=>'political',  'region'=>'middle-east'],
  // ── Banking / FinReg ──────────────────────────────────────
  ['url'=>'https://www.bankingexchange.com/rss/all-articles',   'cat'=>'banking',    'region'=>'global'],
  ['url'=>'https://www.risk.net/rss',                           'cat'=>'banking',    'region'=>'global'],
  ['url'=>'https://www.globalcapital.com/rss',                  'cat'=>'banking',    'region'=>'global'],
  ['url'=>'https://www.efinancialnews.com/rss',                 'cat'=>'banking',    'region'=>'europe'],

  // ── Central Banks ─────────────────────────────────────
  ['url'=>'https://www.mas.gov.sg/news/rss',                             'cat'=>'banking',    'region'=>'asia'],
  ['url'=>'https://www.snb.ch/en/iabout/pub/rss/id/news_rss',           'cat'=>'banking',    'region'=>'europe'],
  ['url'=>'https://www.bankofengland.co.uk/rss/news',                    'cat'=>'banking',    'region'=>'europe'],
  ['url'=>'https://www.federalreserve.gov/feeds/press_all.xml',          'cat'=>'banking',    'region'=>'americas'],
  ['url'=>'https://www.sama.gov.sa/en-US/News/rss.xml',                  'cat'=>'banking',    'region'=>'middle-east'],
  ['url'=>'https://www.centralbank.ae/en/news/rss',                      'cat'=>'banking',    'region'=>'middle-east'],
  ['url'=>'https://www.cbn.gov.ng/rss/news.xml',                         'cat'=>'banking',    'region'=>'africa'],
  ['url'=>'https://www.rba.gov.au/rss/rss-cb-news-and-publications.xml', 'cat'=>'banking',    'region'=>'asia'],
  ['url'=>'https://www.bankofcanada.ca/feed/',                           'cat'=>'banking',    'region'=>'americas'],
  ['url'=>'https://www.norges-bank.no/en/news-events/news-publications/rss/', 'cat'=>'banking','region'=>'europe'],
  ['url'=>'https://www.riksbank.se/en-gb/press-and-published/rss/',      'cat'=>'banking',    'region'=>'europe'],

  // ── Law Enforcement & Police Forces ───────────────────
  ['url'=>'https://www.interpol.int/News-and-Events/News/rss',           'cat'=>'sanctions',  'region'=>'global'],
  ['url'=>'https://www.europol.europa.eu/newsroom/rss',                  'cat'=>'sanctions',  'region'=>'europe'],
  ['url'=>'https://www.nationalcrimeagency.gov.uk/rss/news-articles',    'cat'=>'sanctions',  'region'=>'europe'],
  ['url'=>'https://www.fbi.gov/feeds/fbi-in-the-news/rss.xml',          'cat'=>'sanctions',  'region'=>'americas'],
  ['url'=>'https://www.justice.gov/opa/press-releases/feed',             'cat'=>'sanctions',  'region'=>'americas'],
  ['url'=>'https://www.sfo.gov.uk/feed/',                                'cat'=>'sanctions',  'region'=>'europe'],
  ['url'=>'https://www.unodc.org/unodc/en/frontpage/rss.xml',           'cat'=>'sanctions',  'region'=>'global'],
  ['url'=>'https://www.bafin.de/SharedDocs/RSS/EN/BaFin_Aktuell_EN.xml','cat'=>'regulatory', 'region'=>'europe'],
  ['url'=>'https://www.fca.org.uk/news/rss.xml',                         'cat'=>'regulatory', 'region'=>'europe'],
  ['url'=>'https://www.finma.ch/en/news/rss.xml',                        'cat'=>'regulatory', 'region'=>'europe'],

  // ── Sanctions & Treasury ──────────────────────────────
  ['url'=>'https://home.treasury.gov/system/files/126/ofac.xml',         'cat'=>'sanctions',  'region'=>'global'],
  ['url'=>'https://www.justice.gov/rss/news.xml',                        'cat'=>'sanctions',  'region'=>'americas'],
  ['url'=>'https://www.eurojust.europa.eu/rss.xml',                      'cat'=>'sanctions',  'region'=>'europe'],

  // ── UN & Multilateral Bodies ──────────────────────────
  ['url'=>'https://www.un.org/press/en/content/security-council/feed/rss.xml','cat'=>'sanctions','region'=>'global'],
  ['url'=>'https://www.oecd.org/newsroom/rss.xml',                      'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://www.worldbank.org/en/news/rss',                      'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.fsb.org/feed/',                                  'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://egmontgroup.org/feed/',                              'cat'=>'regulatory', 'region'=>'global'],

  // ── Think Tanks & Strategic Intelligence ──────────────
  ['url'=>'https://www.chathamhouse.org/rss.xml',                       'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://www.iiss.org/rss/publications',                      'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://www.cfr.org/rss.xml',                                'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://carnegieendowment.org/rss/solr.xml',                 'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://www.brookings.edu/feed/',                            'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://www.atlanticcouncil.org/feed/',                      'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://www.rand.org/feed/news.xml',                         'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://www.lowyinstitute.org/the-interpreter/rss.xml',      'cat'=>'political',  'region'=>'asia'],
  ['url'=>'https://www.sipri.org/media/rss.xml',                        'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://www.gfintegrity.org/feed/',                          'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.bellingcat.com/feed/',                           'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://www.wilsoncenter.org/rss.xml',                       'cat'=>'political',  'region'=>'global'],

  // ── Offshore Financial Centres ─────────────────────────
  ['url'=>'https://www.jfsc.je/news/rss.xml',                           'cat'=>'regulatory', 'region'=>'europe'],
  ['url'=>'https://www.gfsc.gg/rss.xml',                                'cat'=>'regulatory', 'region'=>'europe'],
  ['url'=>'https://www.cima.ky/news/rss.xml',                           'cat'=>'regulatory', 'region'=>'americas'],
  ['url'=>'https://www.iomfsa.im/media/rss.xml',                        'cat'=>'regulatory', 'region'=>'europe'],
  ['url'=>'https://cssf.lu/en/rss.xml',                                 'cat'=>'regulatory', 'region'=>'europe'],
  ['url'=>'https://www.dfsa.ae/news/rss.xml',                           'cat'=>'regulatory', 'region'=>'middle-east'],
  ['url'=>'https://www.adgm.com/news/rss',                              'cat'=>'regulatory', 'region'=>'middle-east'],
  ['url'=>'https://www.mfsa.mt/rss.xml',                                'cat'=>'regulatory', 'region'=>'europe'],

  // ── Parliamentary & Legislative ────────────────────────
  ['url'=>'https://www.europarl.europa.eu/rss/doc/press-release/en.xml','cat'=>'regulatory', 'region'=>'europe'],
  ['url'=>'https://www.consilium.europa.eu/en/press/press-releases/rss/','cat'=>'regulatory','region'=>'europe'],

  // ── Ratings & Credit ───────────────────────────────────
  ['url'=>'https://www.fitchratings.com/rss/news',                      'cat'=>'financial',  'region'=>'global'],

  // ── Compliance & AML ──────────────────────────────────
  ['url'=>'https://www.acams.org/feed/',                                'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://www.antimoneylaunderinglaw.com/feed/',               'cat'=>'regulatory', 'region'=>'global'],

  // ── Commodities & Resources ────────────────────────────
  ['url'=>'https://www.gold.org/goldhub/news/rss',                      'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.hellenicshippingnews.com/feed/',                 'cat'=>'financial',  'region'=>'global'],

  // ── Regional ──────────────────────────────────────────
  ['url'=>'https://asean.org/category/news/feed/',                      'cat'=>'political',  'region'=>'asia'],
  ['url'=>'https://au.int/en/rss.xml',                                  'cat'=>'political',  'region'=>'africa'],
  ['url'=>'https://www.gulf-times.com/rss.xml',                         'cat'=>'political',  'region'=>'middle-east'],
  ['url'=>'https://www.theeastafrican.co.ke/tea/news/feed',             'cat'=>'political',  'region'=>'africa'],

  // ── Wealth & Private Capital ──────────────────────────
  ['url'=>'https://www.wealthbriefing.com/rss/news.php',                'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.privateequityinternational.com/rss/',            'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.hedgeweek.com/feed/',                            'cat'=>'financial',  'region'=>'global'],
  ['url'=>'https://www.altassets.net/feed/',                            'cat'=>'financial',  'region'=>'global'],
  // ── FCPA, Legal & Investigations ─────────────────────
  ['url'=>'https://fcpablog.com/feed/',                                 'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://globalinvestigationsreview.com/feed',                'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://www.lawfaremedia.org/feed',                          'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://www.internationallawoffice.com/Newsletters/rss',     'cat'=>'regulatory', 'region'=>'global'],

  // ── Political Risk & Conflict ─────────────────────────
  ['url'=>'https://politicalviolenceataglance.org/feed/',               'cat'=>'political',  'region'=>'global'],
  ['url'=>'https://balkaninsight.com/feed/',                            'cat'=>'political',  'region'=>'europe'],
  ['url'=>'https://www.maplecroft.com/insights/analysis/feed/',         'cat'=>'political',  'region'=>'global'],

  // ── AML & Corruption Risk ─────────────────────────────
  ['url'=>'https://www.traceinternational.org/blog/rss',                'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://baselgovernance.org/news/feed/',                     'cat'=>'regulatory', 'region'=>'global'],
  ['url'=>'https://www.business-anti-corruption.com/feed/',             'cat'=>'regulatory', 'region'=>'global'],

  // ── Sovereign & Country Risk ──────────────────────────
  ['url'=>'https://www.coface.com/News-Publications/News/rss',          'cat'=>'financial',  'region'=>'global'],

  // ── Maritime & Trade ──────────────────────────────────
  ['url'=>'https://splash247.com/feed/',                                'cat'=>'financial',  'region'=>'global'],
  // ── GDELT Project (every 15 min, 100+ languages) ────────
  ['url'=>'https://api.gdeltproject.org/api/v2/doc/doc?query=capital+controls+OR+bank+crisis+OR+sanctions+OR+devaluation&mode=artlist&maxrecords=25&format=rss', 'cat'=>'financial', 'region'=>'global'],
  ['url'=>'https://api.gdeltproject.org/api/v2/doc/doc?query=coup+OR+military+action+OR+political+crisis+OR+protest&mode=artlist&maxrecords=25&format=rss', 'cat'=>'political', 'region'=>'global'],

  // ── US State Department Travel Advisories ─────────────
  ['url'=>'https://travel.state.gov/content/travel/en/traveladvisories/traveladvisories.html/', 'cat'=>'political', 'region'=>'global'],

  // ── OpenSanctions (consolidated global sanctions) ──────
  ['url'=>'https://data.opensanctions.org/datasets/sanctions/index.json', 'cat'=>'sanctions', 'region'=>'global'],

  // ── ACLED Conflict Data ────────────────────────────────
  ['url'=>'https://acleddata.com/feed/', 'cat'=>'political', 'region'=>'global'],

  // ── DeFiLlama (protocol TVL, hacks) ───────────────────
  ['url'=>'https://defillama.com/rss/hacks.xml', 'cat'=>'financial', 'region'=>'global'],

  // ── Rekt News (crypto incidents, first to publish) ─────
  ['url'=>'https://rekt.news/rss/', 'cat'=>'financial', 'region'=>'global'],

  // ── ICRC (Red Cross operations — humanitarian crisis) ──
  ['url'=>'https://www.icrc.org/en/sitemap', 'cat'=>'political', 'region'=>'global'],

  // ── UN Security Council (sanctions, resolutions) ───────
  ['url'=>'https://www.un.org/press/en/content/security-council/feed/rss.xml', 'cat'=>'sanctions', 'region'=>'global'],

  // ── IAEA Nuclear/Radiological incidents ───────────────
  ['url'=>'https://www.iaea.org/newscenter/news/rss', 'cat'=>'political', 'region'=>'global'],

  // ── Lloyd's Market Intelligence (war risk) ─────────────
  ['url'=>'https://www.lloyds.com/news-and-insights/market-bulletins/rss', 'cat'=>'political', 'region'=>'global'],

  // ── FAO Food Price Index ───────────────────────────────
  ['url'=>'https://www.fao.org/news/rss-feed/en/', 'cat'=>'political', 'region'=>'global'],

  // ── Sovereign credit / IMF programs ───────────────────
  ['url'=>'https://www.imf.org/en/News/rss?language=eng', 'cat'=>'financial', 'region'=>'global'],

  // ── PACER court filing monitor (enforcement actions) ──
  ['url'=>'https://efts.sec.gov/LATEST/search-index/news.xml', 'cat'=>'regulatory', 'region'=>'americas'],
  ['url'=>'https://www.cftc.gov/rss/LawRegulation/EnforcementActions/', 'cat'=>'regulatory', 'region'=>'americas'],
];

function cacheKey($url) { return CACHE_DIR . md5($url) . '.json'; }
function getCached($url) {
  $f = cacheKey($url);
  if (file_exists($f) && (time() - filemtime($f)) < CACHE_TTL) {
    $d = json_decode(file_get_contents($f), true);
    if ($d) return $d;
  }
  return null;
}
function setCache($url, $data) { file_put_contents(cacheKey($url), json_encode($data)); }

function fetchRSS($url) {
  $cached = getCached($url);
  if ($cached) return $cached;
  $ctx = stream_context_create(['http'=>['timeout'=>7,'user_agent'=>'Mebusan Intelligence Engine/2.0','ignore_errors'=>true]]);
  $xml_str = @file_get_contents($url, false, $ctx);
  if (!$xml_str) return [];
  libxml_use_internal_errors(true);
  $xml = simplexml_load_string($xml_str);
  if (!$xml) return [];
  $items = [];
  $nodes = $xml->channel->item ?? $xml->entry ?? [];
  foreach ($nodes as $item) {
    $title = trim((string)($item->title ?? ''));
    $desc  = trim(strip_tags((string)($item->description ?? $item->summary ?? '')));
    $link  = trim((string)($item->link ?? $item->id ?? ''));
    $date  = trim((string)($item->pubDate ?? $item->published ?? $item->updated ?? ''));
    if (!$title || strlen($title) < 10) continue;
    $items[] = ['title'=>htmlspecialchars_decode($title),'body'=>mb_substr($desc,0,240),'link'=>$link,'date'=>$date,'ts'=>$date ? strtotime($date) : time()];
    if (count($items) >= 5) break;
  }
  setCache($url, $items);
  return $items;
}

function timeAgo($ts) {
  $diff = time() - $ts;
  if ($diff < 3600)  return round($diff/60).'m ago';
  if ($diff < 86400) return round($diff/3600).'h ago';
  return round($diff/86400).'d ago';
}

function classifyPriority($title, $cat) {
  $high = ['capital control','sanctions','freeze','seized','crisis','emergency','devaluation','collapse','default','conflict','coup','war','attack','explosion','arrest','seized','ban'];
  $t = strtolower($title);
  foreach ($high as $w) if (strpos($t,$w)!==false) return 'high';
  return in_array($cat,['banking','regulatory']) ? 'medium' : 'low';
}


// ════ CORRELATION ENGINE ════════════════════════════════════════
// When multiple independent sources flag the same country, that's
// not noise — that's signal. Score converges into a composite alert.

function buildCountrySignalMap(array $items): array {
    $map = [];
    foreach ($items as $item) {
        $countries = extractCountries($item['title'] . ' ' . $item['body']);
        foreach ($countries as $country) {
            if (!isset($map[$country])) {
                $map[$country] = [
                    'country'   => $country,
                    'signals'   => [],
                    'score'     => 0,
                    'sources'   => [],
                    'cats'      => [],
                    'level'     => 'watch',
                ];
            }
            $weight = ['high'=>4, 'medium'=>2, 'low'=>1][$item['priority']] ?? 1;
            $map[$country]['score']   += $weight;
            $map[$country]['signals'][] = $item['title'];
            $map[$country]['sources'][] = $item['source'] ?? $item['cat'];
            $map[$country]['cats'][]    = $item['cat'];
        }
    }
    // Score to alert level
    foreach ($map as &$c) {
        $c['sources'] = array_unique($c['sources']);
        $c['cats']    = array_unique($c['cats']);
        $c['signal_count'] = count($c['signals']);
        // Multi-category convergence bonus (Taleb principle: correlated independent signals)
        if (count($c['cats']) >= 3) $c['score'] += 5;
        if (count($c['cats']) >= 4) $c['score'] += 4;
        // Alert level thresholds
        if ($c['score'] >= 20)     $c['level'] = 'critical';
        elseif ($c['score'] >= 14) $c['level'] = 'high';
        elseif ($c['score'] >= 8)  $c['level'] = 'alert';
        else                       $c['level'] = 'watch';
        $c['signals'] = array_slice($c['signals'], 0, 5);
    }
    uasort($map, fn($a,$b) => $b['score'] <=> $a['score']);
    return array_slice($map, 0, 20);
}

function extractCountries(string $text): array {
    $countries = [
        'Lebanon','Turkey','Nigeria','Russia','UAE','Switzerland','Germany',
        'France','UK','United Kingdom','United States','China','Japan','India',
        'Saudi Arabia','Qatar','Kuwait','Bahrain','Singapore','Hong Kong',
        'Cayman','BVI','Luxembourg','Ireland','Cyprus','Malta','Austria',
        'Norway','Sweden','Denmark','Australia','Canada','Argentina','Venezuela',
        'Egypt','Pakistan','Kazakhstan','Kenya','Ghana','Ethiopia','Ukraine',
        'Belarus','Serbia','Hungary','Poland','Romania','Greece','Italy','Spain',
        'Brazil','Mexico','Colombia','Peru','Chile','Ecuador','Myanmar','Iran',
        'Iraq','Syria','Libya','Sudan','Ethiopia','Somalia','Zimbabwe','Tunisia',
    ];
    $found = [];
    foreach ($countries as $country) {
        if (stripos($text, $country) !== false) $found[] = $country;
    }
    return array_unique($found);
}

function classifySignalCategory(array $item): string {
    $t = strtolower($item['title'].' '.($item['body'] ?? ''));
    if (preg_match('/bank|swift|deposit|withdrawal|reserve|lira|peso|naira|devaluation|currency|central bank/', $t)) return 'banking';
    if (preg_match('/sanction|ofac|fatf|aml|freeze|designat/', $t)) return 'sanctions';
    if (preg_match('/regulat|compliance|legislation|parliament|law|decree|capital control/', $t)) return 'regulatory';
    if (preg_match('/conflict|military|coup|war|attack|explosion|protest|unrest|crisis/', $t)) return 'political';
    if (preg_match('/crypto|bitcoin|exchange|stablecoin|defi|blockchain/', $t)) return 'financial';
    return $item['cat'] ?? 'financial';
}


$catFilter    = $_GET['cat']    ?? 'all';
$regionFilter = $_GET['region'] ?? 'all';
$q            = strtolower($_GET['q'] ?? '');
$limit        = min((int)($_GET['limit'] ?? 50), 120);

if (!empty($_GET['source'])) {
  echo json_encode(['success'=>true,'items'=>fetchRSS($_GET['source'])]);
  exit;
}

// Correlation intelligence endpoint
if (($_GET['action'] ?? '') === 'correlate') {
  $allItems = [];
  foreach ($SOURCES as $src) {
    $items = fetchRSS($src['url']);
    foreach ($items as $item) {
      $item['cat']    = $src['cat'];
      $item['region'] = $src['region'];
      $item['priority'] = classifyPriority($item['title'], $src['cat']);
      $allItems[] = $item;
    }
  }
  $correlations = buildCountrySignalMap($allItems);
  echo json_encode(['success'=>true,'correlations'=>array_values($correlations),'generated_at'=>date('c')]);
  exit;
}

$all = [];
foreach ($SOURCES as $src) {
  if ($catFilter !== 'all' && $src['cat'] !== $catFilter) continue;
  if ($regionFilter !== 'all' && $src['region'] !== $regionFilter) continue;
  $items = fetchRSS($src['url']);
  foreach ($items as $item) {
    if ($q && strpos(strtolower($item['title'].' '.$item['body']), $q) === false) continue;
    $item['cat']    = $src['cat'];
    $item['region'] = $src['region'];
    $item['time']   = timeAgo($item['ts']);
    $item['priority'] = classifyPriority($item['title'], $src['cat']);
    $all[] = $item;
  }
}

usort($all, fn($a,$b) => $b['ts'] - $a['ts']);
$all = array_slice($all, 0, $limit);
$stats = ['total'=>count($all),'high'=>count(array_filter($all,fn($i)=>$i['priority']==='high')),'sources_active'=>count($SOURCES),'cached_at'=>date('c')];
echo json_encode(['success'=>true,'items'=>$all,'stats'=>$stats]);
