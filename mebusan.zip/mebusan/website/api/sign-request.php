<?php
/**
 * MEBUSAN · Sign request
 * ─────────────────────────────────────────────────────────────────
 * Called server-side by the signup flow after payment succeeds.
 *
 * POST /api/sign-request.php  (auth: MEBUSAN_INTERNAL_KEY)
 *   { email, name, name_slug, tier, confirmation_id }
 *
 * Creates a signing session file at cache/signatures/<session_id>.json,
 * returns { url, token, document_id, expires_at }.
 *
 * The returned URL is then used in the engagement-sign-required email.
 */

declare(strict_types=1);
header('Content-Type: application/json');
require_once __DIR__ . '/_security.php';
MebusanSecurity::applyApiHeaders();

// Internal auth
$expected = getenv('MEBUSAN_INTERNAL_KEY') ?: '';
$provided = $_GET['key'] ?? ($_SERVER['HTTP_X_MEBUSAN_KEY'] ?? '');
if ($expected && !hash_equals($expected, (string)$provided)) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

$body = json_decode(file_get_contents('php://input') ?: '', true) ?: [];
$email = filter_var($body['email'] ?? '', FILTER_VALIDATE_EMAIL);
if (!$email) {
    http_response_code(400);
    echo json_encode(['error' => 'valid email required']);
    exit;
}

$session = [
    'session_id'      => 'SGN-' . strtoupper(bin2hex(random_bytes(8))),
    'document_id'     => 'MBSN-DOC-' . strtoupper(bin2hex(random_bytes(4))),
    'email'           => $email,
    'name'            => substr((string)($body['name']            ?? ''), 0, 200),
    'name_slug'       => substr((string)($body['name_slug']       ?? ''), 0, 80),
    'tier'            => substr((string)($body['tier']            ?? 'Advisory'), 0, 40),
    'confirmation_id' => substr((string)($body['confirmation_id'] ?? ''), 0, 80),
    'issued_at'       => date('c'),
    'expires_at'      => date('c', time() + 90 * 86400), // 90 days
    'signed'          => false,
];
MebusanSecurity::saveSigningSession($session);

$token = MebusanSecurity::issueSigningToken($session['session_id']);
$url   = 'https://mebusan.com/sign.html?t=' . $token;

MebusanSecurity::auditLog('sign-request', [
    'session_id'   => $session['session_id'],
    'email_masked' => MebusanSecurity::maskEmail($email),
    'tier'         => $session['tier'],
]);

echo json_encode([
    'success'     => true,
    'url'         => $url,
    'token'       => $token,
    'document_id' => $session['document_id'],
    'expires_at'  => $session['expires_at'],
]);
