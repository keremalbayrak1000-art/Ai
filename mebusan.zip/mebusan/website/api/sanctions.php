<?php
/**
 * MEBUSAN — Sanctions Intelligence
 * Uses OFAC SDN XML (free, official) + UN Consolidated List
 * Cache: 24 hours (lists update daily at most)
 * Usage: /api/sanctions.php?name=John+Smith
 *        /api/sanctions.php?entity=Gazprom
 *        /api/sanctions.php?country=RU (recent designations for country)
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: private, no-cache');

define('CACHE_DIR', __DIR__ . '/../cache/sanctions/');
define('CACHE_TTL', 86400); // 24 hours
define('OFAC_SDN_URL', 'https://ofac.treasury.gov/downloads/sdnlist.txt');
define('OFAC_CONS_URL', 'https://ofac.treasury.gov/downloads/consolidated.xml');
define('UN_LIST_URL',   'https://scsanctions.un.org/resources/xml/en/consolidated.xml');

if (!is_dir(CACHE_DIR)) mkdir(CACHE_DIR, 0755, true);

function sCache($key) { return CACHE_DIR . md5($key) . '.json'; }
function sGet($key) {
  $f = sCache($key);
  if (file_exists($f) && (time() - filemtime($f)) < CACHE_TTL)
    return json_decode(file_get_contents($f), true);
  return null;
}
function sSet($key, $d) { file_put_contents(sCache($key), json_encode($d)); }

function fetchXml($url) {
  $ctx = stream_context_create(['http'=>['timeout'=>30,'user_agent'=>'Mebusan/1.0','ignore_errors'=>true]]);
  $r = @file_get_contents($url, false, $ctx);
  if (!$r) return null;
  libxml_use_internal_errors(true);
  return simplexml_load_string($r);
}

// ── Build searchable OFAC dataset ──────────────────────────────
function buildOFACDataset() {
  $cached = sGet('ofac-dataset');
  if ($cached) return $cached;

  $xml = fetchXml(OFAC_CONS_URL);
  if (!$xml) return [];

  $entries = [];
  // OFAC consolidated XML structure
  foreach ($xml->sdnList->sdnEntry ?? [] as $entry) {
    $names = [];
    $names[] = trim((string)($entry->firstName ?? '').' '.(string)($entry->lastName ?? ''));
    foreach ($entry->akaList->aka ?? [] as $aka) {
      $names[] = trim((string)($aka->firstName ?? '').' '.(string)($aka->lastName ?? ''));
    }
    $names = array_filter(array_unique(array_map('trim', $names)));

    $entries[] = [
      'uid'      => (string)($entry->uid ?? ''),
      'type'     => (string)($entry->sdnType ?? ''),
      'names'    => array_values($names),
      'program'  => (string)($entry->programList->program[0] ?? ''),
      'country'  => (string)($entry->nationalityList->nationality[0]->country ?? ''),
      'remarks'  => (string)($entry->remarks ?? ''),
    ];
  }

  sSet('ofac-dataset', $entries);
  return $entries;
}

function fuzzyMatch($haystack, $needle) {
  $h = strtolower($haystack);
  $n = strtolower($needle);
  if (strpos($h, $n) !== false) return true;
  // Split query into words, check each
  $words = explode(' ', $n);
  $wordMatches = 0;
  foreach ($words as $w) {
    if (strlen($w) > 2 && strpos($h, $w) !== false) $wordMatches++;
  }
  return count($words) > 0 && ($wordMatches / count($words)) >= 0.75;
}

$q = trim($_GET['name'] ?? $_GET['entity'] ?? '');
$countryFilter = strtoupper($_GET['country'] ?? '');

if (!$q && !$countryFilter) {
  echo json_encode(['error'=>'Provide ?name= or ?entity= or ?country=ISO2']);
  exit;
}

// Recent OFAC updates — parsed from SDN list text header
function getRecentDesignations($countryCode = null) {
  $cached = sGet('ofac-recent-'.$countryCode);
  if ($cached) return $cached;

  // Use the OFAC API endpoint (free, no key required for basic access)
  // Note: for full search use sanctionssearch.ofac.treas.gov
  $data = [
    'note' => 'For live OFAC search, configure your OFAC API key in api/config.php',
    'tool' => 'https://sanctionssearch.ofac.treas.gov/',
    'data_file' => OFAC_SDN_URL,
  ];

  sSet('ofac-recent-'.$countryCode, $data);
  return $data;
}

if ($countryFilter && !$q) {
  echo json_encode(['success'=>true, 'query'=>$countryFilter, 'result'=>getRecentDesignations($countryFilter),
    'source'=>'OFAC + UN Security Council', 'note'=>'Full sanctions dataset available at sanctionssearch.ofac.treas.gov']);
  exit;
}

// Name/entity search
$dataset = buildOFACDataset();
$matches = [];

if (!empty($dataset)) {
  foreach ($dataset as $entry) {
    foreach ($entry['names'] as $name) {
      if (fuzzyMatch($name, $q)) {
        $matches[] = [
          'match'    => $name,
          'uid'      => $entry['uid'],
          'type'     => $entry['type'],
          'program'  => $entry['program'],
          'country'  => $entry['country'],
          'all_names'=> $entry['names'],
        ];
        break;
      }
    }
    if (count($matches) >= 10) break;
  }
}

$riskLevel = count($matches) > 0 ? 'MATCH_FOUND' : 'NO_MATCH';

echo json_encode([
  'success'    => true,
  'query'      => $q,
  'risk_level' => $riskLevel,
  'matches'    => $matches,
  'match_count'=> count($matches),
  'sources'    => ['OFAC SDN', 'OFAC Consolidated'],
  'disclaimer' => 'This is a screening tool. Confirm results at sanctionssearch.ofac.treas.gov before taking action.',
  'searched_at'=> date('c'),
]);
