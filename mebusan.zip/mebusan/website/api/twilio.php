<?php
/**
 * MEBUSAN — Twilio Verify API
 * Handles SMS and email OTP via Twilio Verify v2
 * 
 * POST /api/twilio.php
 * { action: "send"|"verify", to: "+447700900123", code: "123456" }
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . ($_SERVER['HTTP_ORIGIN'] ?? ''));
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/../config.php';

// Rate limiting
session_start();
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateKey = 'twilio_rate_' . md5($ip);
$now = time();
$attempts = $_SESSION[$rateKey] ?? ['count'=>0,'window'=>$now];
if ($now - $attempts['window'] > RATE_LIMIT_WINDOW) {
    $attempts = ['count'=>0,'window'=>$now];
}
if ($attempts['count'] >= RATE_LIMIT_MAX) {
    http_response_code(429);
    echo json_encode(['success'=>false,'error'=>'Too many requests. Please wait before trying again.']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true) ?? [];
$action = trim($body['action'] ?? '');
$to     = trim($body['to'] ?? '');
$code   = trim($body['code'] ?? '');
$channel= trim($body['channel'] ?? 'sms'); // sms | email | whatsapp

if (!$action || !$to) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>'Missing required fields.']);
    exit;
}

// Validate Verify SID configured
if (TWILIO_VERIFY_SID === 'YOUR_VERIFY_SERVICE_SID') {
    // Development mode — simulate verification
    if ($action === 'send') {
        echo json_encode(['success'=>true,'message'=>'Code sent (dev mode).','dev'=>true]);
    } elseif ($action === 'verify') {
        // Accept any 6-digit code in dev mode
        $ok = strlen($code) === 6 && ctype_digit($code);
        echo json_encode(['success'=>$ok,'valid'=>$ok,'dev'=>true]);
    }
    exit;
}

// Twilio Verify v2 API base URL
$baseUrl = 'https://verify.twilio.com/v2/Services/' . TWILIO_VERIFY_SID;
$auth    = base64_encode(TWILIO_SID . ':' . TWILIO_TOKEN);

function twilioRequest(string $url, array $data, string $auth): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query($data),
        CURLOPT_HTTPHEADER     => ['Authorization: Basic ' . $auth, 'Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['body' => json_decode($resp, true) ?? [], 'status' => $code];
}

if ($action === 'send') {
    $attempts['count']++;
    $_SESSION[$rateKey] = $attempts;

    // Format number if needed
    if ($channel === 'whatsapp') {
        $to = 'whatsapp:' . $to;
    }

    $result = twilioRequest(
        $baseUrl . '/Verifications',
        ['To' => $to, 'Channel' => $channel === 'whatsapp' ? 'whatsapp' : 'sms'],
        $auth
    );

    if ($result['status'] === 201 && ($result['body']['status'] ?? '') === 'pending') {
        echo json_encode(['success'=>true,'message'=>'Verification code sent.']);
    } else {
        $errMsg = $result['body']['message'] ?? 'Failed to send code. Please check the number and try again.';
        http_response_code(422);
        echo json_encode(['success'=>false,'error'=>$errMsg]);
    }

} elseif ($action === 'verify') {
    $result = twilioRequest(
        $baseUrl . '/VerificationCheck',
        ['To' => $to, 'Code' => $code],
        $auth
    );

    $valid = ($result['body']['status'] ?? '') === 'approved';
    if ($valid) {
        $_SESSION['phone_verified'] = $to;
        $_SESSION['phone_verified_at'] = time();
    }
    echo json_encode(['success'=>true,'valid'=>$valid,'status'=>$result['body']['status'] ?? 'unknown']);

} else {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>'Invalid action.']);
}
