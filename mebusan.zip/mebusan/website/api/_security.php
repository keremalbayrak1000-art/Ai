<?php
/**
 * MEBUSAN · Security helpers
 * ─────────────────────────────────────────────────────────────────
 * Require this from any endpoint that needs:
 *   - Rate limiting (file-based, no Redis needed)
 *   - CSRF tokens (double-submit cookie + session)
 *   - HMAC signing tokens for stateless flows (e-sign, unsubscribe, password reset)
 *   - Input sanitisation
 *   - Audit logging (append-only)
 *   - IP masking / email masking
 *   - Secure session initialisation
 *   - Uniform API response headers (CSP, X-Frame-Options, etc.)
 *   - Constant-time comparisons
 *
 * Zero third-party dependencies. Runs on any PHP 8.0+ host.
 *
 * Environment variables used:
 *   MEBUSAN_SECRET             master secret — MUST be 32+ bytes hex
 *   MEBUSAN_INTERNAL_KEY       for internal service-to-service calls
 *   UNSUB_SECRET               separate secret for unsub tokens
 *   MEBUSAN_ADMIN_IPS          optional, comma-separated CIDR allowlist
 */

declare(strict_types=1);

final class MebusanSecurity
{
    private const AUDIT_LOG_DIR = '/cache/audit_log';
    private const RATE_LIMIT_DIR = '/cache/rate_limits';
    private const SIGNATURES_DIR = '/cache/signatures';
    private const CSRF_DIR       = '/cache/csrf_tokens';

    // ─── Uniform API security headers ───────────────────────────
    public static function applyApiHeaders(): void
    {
        // API endpoints: no third-party, no embedding
        header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: no-referrer');
        header('Permissions-Policy: geolocation=(), camera=(), microphone=(), payment=()');
        header('Cache-Control: private, no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');
        // No server fingerprinting
        header_remove('X-Powered-By');
    }

    // ─── Rate limiting (per-IP + per-endpoint) ──────────────────
    /**
     * Call at top of an endpoint: MebusanSecurity::rateLimit('verify-otp', 10, 600);
     * Throws a 429 and exits if the limit is exceeded.
     */
    public static function rateLimit(string $bucket, int $maxRequests = 30, int $windowSeconds = 600): void
    {
        $ip = self::clientIp();
        $dir = self::rootPath() . self::RATE_LIMIT_DIR;
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $key = $dir . '/' . preg_replace('/[^a-z0-9_-]/i', '', $bucket) . '-' . md5($ip) . '.json';

        $now = time();
        $windowStart = $now - $windowSeconds;
        $events = [];
        if (is_readable($key)) {
            $raw = json_decode((string)file_get_contents($key), true);
            if (is_array($raw)) $events = $raw;
        }
        // Drop expired
        $events = array_filter($events, fn($t) => $t > $windowStart);

        if (count($events) >= $maxRequests) {
            header('Retry-After: ' . $windowSeconds);
            http_response_code(429);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'rate limit exceeded', 'retry_after' => $windowSeconds]);
            self::auditLog('rate-limited', ['bucket' => $bucket, 'ip' => self::maskIp($ip)]);
            exit;
        }

        $events[] = $now;
        @file_put_contents($key, json_encode(array_values($events)), LOCK_EX);
    }

    // ─── CSRF ───────────────────────────────────────────────────
    /** Issue a CSRF token bound to the current session. */
    public static function csrfToken(): string
    {
        self::startSecureSession();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
        }
        return $_SESSION['csrf_token'];
    }
    /** Verify a submitted token. Call before state-changing operations. */
    public static function requireCsrf(string $submitted): void
    {
        self::startSecureSession();
        $expected = (string)($_SESSION['csrf_token'] ?? '');
        if (!$expected || !hash_equals($expected, $submitted)) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'csrf failed']);
            self::auditLog('csrf-failed', ['ip' => self::maskIp(self::clientIp())]);
            exit;
        }
    }

    // ─── Signing tokens (HMAC-stateless) ────────────────────────
    /** Issue an HMAC-bound token for a sign session. */
    public static function issueSigningToken(string $sessionId): string
    {
        $secret = self::secret('signing');
        $hmac = substr(hash_hmac('sha256', $sessionId, $secret), 0, 32);
        return $sessionId . '.' . $hmac;
    }
    /** Verify a signing token. Returns session array or null. */
    public static function verifySigningToken(string $token): ?array
    {
        if (!$token || !str_contains($token, '.')) return null;
        [$sessionId, $hmac] = array_pad(explode('.', $token, 2), 2, '');
        if (!preg_match('/^SGN-[A-F0-9]{16}$/', (string)$sessionId)) return null;
        $expected = substr(hash_hmac('sha256', $sessionId, self::secret('signing')), 0, 32);
        if (!hash_equals($expected, (string)$hmac)) return null;
        $file = self::rootPath() . self::SIGNATURES_DIR . '/' . $sessionId . '.json';
        if (!is_readable($file)) return null;
        $data = json_decode((string)file_get_contents($file), true);
        return is_array($data) ? $data : null;
    }
    public static function saveSigningSession(array $session): void
    {
        $dir = self::rootPath() . self::SIGNATURES_DIR;
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $file = $dir . '/' . preg_replace('/[^A-Z0-9_-]/', '', $session['session_id']) . '.json';
        file_put_contents($file, json_encode($session, JSON_PRETTY_PRINT), LOCK_EX);
    }

    // ─── Secrets (derived keys for different contexts) ──────────
    /** Derive a purpose-specific secret from the master. */
    public static function secret(string $purpose): string
    {
        $master = getenv('MEBUSAN_SECRET') ?: '';
        if (!$master) {
            // Fallback — loudly warn via log but do not crash in dev
            error_log('MEBUSAN_SECRET not set, using fallback — production insecure');
            $master = 'mebusan-fallback-insecure-rotate-immediately';
        }
        // HKDF-like derivation, simple variant
        return hash_hmac('sha256', 'mebusan/' . $purpose, $master, true);
    }

    // ─── Secure session initialisation ──────────────────────────
    public static function startSecureSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) return;
        $secure = !empty($_SERVER['HTTPS']) || ($_SERVER['SERVER_PORT'] ?? '') == 443;
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_name('mebusan_sess');
        session_start();
        // Regenerate periodically to prevent fixation
        if (empty($_SESSION['_created'])) {
            $_SESSION['_created'] = time();
            session_regenerate_id(true);
        } elseif (time() - $_SESSION['_created'] > 1800) {
            $_SESSION['_created'] = time();
            session_regenerate_id(true);
        }
    }

    // ─── Input sanitisation ─────────────────────────────────────
    public static function str(string $s, int $max = 500): string
    {
        return substr(trim($s), 0, $max);
    }
    public static function email(string $s): ?string
    {
        $s = filter_var(trim($s), FILTER_VALIDATE_EMAIL);
        return $s ? strtolower($s) : null;
    }
    public static function phoneE164(string $s): ?string
    {
        $s = preg_replace('/[^\d+]/', '', trim($s)) ?: '';
        return preg_match('/^\+\d{7,15}$/', $s) ? $s : null;
    }
    public static function int(string|int $s, int $min = 0, int $max = PHP_INT_MAX): int
    {
        $n = is_int($s) ? $s : (int)$s;
        return max($min, min($max, $n));
    }

    // ─── Audit log (append-only) ────────────────────────────────
    public static function auditLog(string $event, array $context = []): void
    {
        $dir = self::rootPath() . self::AUDIT_LOG_DIR;
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $entry = [
            'ts'      => date('c'),
            'event'   => $event,
            'ip'      => self::maskIp(self::clientIp()),
            'ua'      => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 200),
            'path'    => substr((string)($_SERVER['REQUEST_URI'] ?? ''), 0, 200),
            'context' => $context,
        ];
        @file_put_contents(
            $dir . '/' . date('Y-m') . '.log',
            json_encode($entry, JSON_UNESCAPED_SLASHES) . "\n",
            FILE_APPEND | LOCK_EX
        );
    }

    // ─── IP helpers ────────────────────────────────────────────
    public static function clientIp(): string
    {
        // Trust X-Forwarded-For only if behind a known proxy (Cloudflare, etc.)
        $trustProxy = getenv('MEBUSAN_TRUST_PROXY') === '1';
        if ($trustProxy && !empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return $_SERVER['HTTP_CF_CONNECTING_IP'];
        }
        if ($trustProxy && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            return trim($parts[0]);
        }
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    public static function maskIp(string $ip): string
    {
        if (strpos($ip, '.') !== false) {
            $p = explode('.', $ip);
            return sprintf('%s.%s.•.••', $p[0] ?? '0', $p[1] ?? '0');
        }
        // IPv6: keep first 3 hextets
        $p = explode(':', $ip);
        return implode(':', array_slice($p, 0, 3)) . '::•';
    }
    public static function maskEmail(string $e): string
    {
        if (!$e || !str_contains($e, '@')) return '—';
        [$u, $d] = explode('@', $e, 2);
        $mu = strlen($u) <= 2 ? $u : substr($u, 0, 2) . str_repeat('•', max(1, strlen($u) - 2));
        return $mu . '@' . $d;
    }

    // ─── Admin IP allowlist ────────────────────────────────────
    public static function requireAdminIp(): void
    {
        $allow = getenv('MEBUSAN_ADMIN_IPS') ?: '';
        if (!$allow) return; // no allowlist → gate open (password-only auth)
        $allowed = array_map('trim', explode(',', $allow));
        $ip = self::clientIp();
        foreach ($allowed as $entry) {
            if ($entry === $ip) return;
            // CIDR support
            if (str_contains($entry, '/')) {
                [$net, $bits] = explode('/', $entry, 2);
                $bits = (int)$bits;
                $ipL  = ip2long($ip);
                $netL = ip2long($net);
                if ($ipL !== false && $netL !== false) {
                    $mask = $bits === 0 ? 0 : (-1 << (32 - $bits)) & 0xFFFFFFFF;
                    if (($ipL & $mask) === ($netL & $mask)) return;
                }
            }
        }
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'forbidden']);
        self::auditLog('admin-ip-denied', ['ip' => self::maskIp($ip)]);
        exit;
    }

    // ─── Honeypot check ─────────────────────────────────────────
    public static function honeypotCheck(array $form, string $hpField = 'website_hp'): void
    {
        // Field should be hidden via CSS; if filled, it's a bot
        if (!empty($form[$hpField])) {
            self::auditLog('honeypot-tripped', ['field' => $hpField]);
            http_response_code(204); // deceptive silent success
            exit;
        }
    }
    public static function timingCheck(int $minElapsedMs, int $actualMs): void
    {
        if ($actualMs < $minElapsedMs) {
            self::auditLog('timing-rejected', ['elapsed_ms' => $actualMs, 'min_ms' => $minElapsedMs]);
            http_response_code(204);
            exit;
        }
    }

    // ─── Path helpers ──────────────────────────────────────────
    public static function rootPath(): string
    {
        // /api or /admin → step up
        return dirname(__DIR__);
    }
}
