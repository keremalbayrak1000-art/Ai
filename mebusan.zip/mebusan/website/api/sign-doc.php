<?php
/**
 * MEBUSAN · Sign-flow PDF delivery
 * ─────────────────────────────────────────────────────────────────
 * GET ?t=<token>               → streams the (currently unsigned or signed) PDF inline
 * GET ?t=<token>&download=1    → streams with attachment headers for download
 *
 * Authorisation comes entirely from the HMAC token. Rate-limited per-IP.
 */

declare(strict_types=1);
require_once __DIR__ . '/_security.php';

MebusanSecurity::rateLimit('sign-doc', 30, 600); // 30 fetches per 10 min

$token = $_GET['t'] ?? '';
$download = !empty($_GET['download']);

try {
    $session = MebusanSecurity::verifySigningToken($token);
} catch (Throwable $e) {
    http_response_code(400);
    echo 'Invalid link.';
    exit;
}

if (!$session) {
    http_response_code(404);
    echo 'Document not available.';
    exit;
}

if (!empty($session['expires_at']) && strtotime((string)$session['expires_at']) < time()) {
    http_response_code(410);
    echo 'Document link has expired.';
    exit;
}

// Load the right PDF: signed if available, else on-demand unsigned from generator
$root = dirname(__DIR__);
$signedPath = $root . '/cache/signed_documents/' . preg_replace('/[^A-Za-z0-9_-]/', '', $session['session_id']) . '.pdf';

if (($session['signed'] ?? false) && is_readable($signedPath)) {
    $bytes = file_get_contents($signedPath);
    $filename = 'mebusan-engagement-' . ($session['name_slug'] ?? 'signed') . '-signed.pdf';
} else {
    // Generate unsigned preview
    $generator = require $root . '/emails/pdf/engagement-letter.php';
    $out = $generator([
        'name'            => $session['name'] ?? '',
        'name_slug'       => $session['name_slug'] ?? '',
        'tier'            => $session['tier'] ?? '',
        'confirmation_id' => $session['confirmation_id'] ?? '',
        'signature'       => null,
    ]);
    $bytes    = $out['content'];
    $filename = $out['filename'];
}

header('Content-Type: application/pdf');
header('Content-Length: ' . strlen($bytes));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('Content-Disposition: ' . ($download ? 'attachment' : 'inline') . '; filename="' . $filename . '"');
// For embedding inside our own iframe only
header('Content-Security-Policy: default-src \'none\'; frame-ancestors \'self\'');

echo $bytes;
