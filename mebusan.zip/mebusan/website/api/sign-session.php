<?php
/**
 * MEBUSAN · Sign session lookup
 * ─────────────────────────────────────────────────────────────────
 * GET ?t=<hmac-token>           → returns session info to render the UI
 * GET ?t=<hmac-token>&verify=1  → returns signed-state metadata (post-sign)
 *
 * Token shape:
 *   <sessionId>.<hmac>
 * where hmac = HMAC-SHA256(sessionId, UNSUB_SECRET), truncated to 32 chars
 *
 * Session file: cache/signatures/<sessionId>.json  (created at signup time
 * by /api/sign-request.php). Has shape:
 *   {
 *     "session_id": "...",
 *     "issued_at":  "ISO",
 *     "expires_at": "ISO" (90 days),
 *     "email":      "client@...",
 *     "name":       "M. Ahmadi",
 *     "name_slug":  "ahmadi",
 *     "tier":       "Advisory",
 *     "confirmation_id": "MBSN-...",
 *     "document_id":     "MBSN-DOC-...",
 *     "signed":     false,
 *     // once signed, adds:
 *     "signed_at":      "ISO",
 *     "method":         "drawn"|"typed",
 *     "document_hash":  "sha256...",
 *     "ip_masked":      "..."
 *   }
 */

declare(strict_types=1);
header('Content-Type: application/json');
require_once __DIR__ . '/_security.php';
MebusanSecurity::applyApiHeaders();

$token = $_GET['t'] ?? '';
$verify = !empty($_GET['verify']);

try {
    $session = MebusanSecurity::verifySigningToken($token);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'invalid token']);
    exit;
}

if (!$session) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'session not found']);
    exit;
}

// Check expiry
if (!empty($session['expires_at']) && strtotime((string)$session['expires_at']) < time()) {
    http_response_code(410);
    echo json_encode(['success' => false, 'error' => 'session expired']);
    exit;
}

// Return a safe subset (never expose email, raw hmac bits, or internals)
$pub = [
    'session_id'      => $session['session_id'],
    'document_id'     => $session['document_id'],
    'name'            => $session['name'] ?? '',
    'tier'            => $session['tier'] ?? '',
    'signed'          => (bool)($session['signed'] ?? false),
];

if ($verify && ($session['signed'] ?? false)) {
    $pub['signed_at']     = $session['signed_at'] ?? null;
    $pub['method']        = $session['method'] ?? null;
    $pub['document_hash'] = $session['document_hash'] ?? null;
}

// If already signed, don't offer the signing UI — redirect to complete.
if (!$verify && ($session['signed'] ?? false)) {
    http_response_code(409);
    echo json_encode(['success' => false, 'error' => 'already signed', 'session' => $pub]);
    exit;
}

echo json_encode(['success' => true, 'session' => $pub]);
