<?php
/**
 * MEBUSAN · Signal Ingestion Orchestrator
 * ──────────────────────────────────────────────────────────────────────
 * Pulls from 50+ free RSS feeds and public APIs covering central banks,
 * treasuries, gazettes, and regulators across every jurisdiction Mebusan
 * monitors. Classifies each new item via Claude API. Writes structured
 * signals to signals.json for the Wall page and the client portal.
 *
 * No third-party services required beyond:
 *   · The public RSS feeds (all free)
 *   · ANTHROPIC_API_KEY (already configured)
 *
 * Runs hourly via cron. Rate-limited. Deduplicates against seen-index.
 * Cost estimate: ~$0.80/month in API calls at this cadence.
 * ──────────────────────────────────────────────────────────────────────
 */

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

// ─── Config ────────────────────────────────────────────────────────────
const INGEST_CACHE_DIR = __DIR__ . '/../cache/ingest';
const SIGNALS_FILE = __DIR__ . '/../cache/signals.json';
const SEEN_INDEX = __DIR__ . '/../cache/seen-index.json';
const MAX_ITEMS_PER_FEED = 6;        // Cap per source per run
const MAX_ITEMS_PER_RUN = 40;        // Cap across all sources per run
const MAX_SIGNAL_AGE_DAYS = 14;      // Drop signals older than this
const MAX_STORED_SIGNALS = 300;      // Rolling window

if (!is_dir(INGEST_CACHE_DIR)) @mkdir(INGEST_CACHE_DIR, 0700, true);

// ─── Feed catalog ──────────────────────────────────────────────────────
// 50+ free sources covering every jurisdiction Mebusan monitors.
// These are all public, officially published, zero-cost.
$FEEDS = [

    // ─── Central banks ────────────────────────────────────────────────
    ['id' => 'ecb-press',       'jur' => 'EU',         'cat' => 'Banking',    'url' => 'https://www.ecb.europa.eu/rss/press.xml'],
    ['id' => 'ecb-economic',    'jur' => 'EU',         'cat' => 'Banking',    'url' => 'https://www.ecb.europa.eu/rss/economic.xml'],
    ['id' => 'boe-news',        'jur' => 'UK',         'cat' => 'Banking',    'url' => 'https://www.bankofengland.co.uk/rss/news'],
    ['id' => 'boe-statistical', 'jur' => 'UK',         'cat' => 'Banking',    'url' => 'https://www.bankofengland.co.uk/rss/statistical-releases'],
    ['id' => 'fed-press',       'jur' => 'US',         'cat' => 'Banking',    'url' => 'https://www.federalreserve.gov/feeds/press_all.xml'],
    ['id' => 'snb-press',       'jur' => 'Switzerland','cat' => 'Banking',    'url' => 'https://www.snb.ch/en/rss/pre'],
    ['id' => 'mas-news',        'jur' => 'Singapore',  'cat' => 'Regulatory', 'url' => 'https://www.mas.gov.sg/news/rss'],
    ['id' => 'rba-media',       'jur' => 'Australia',  'cat' => 'Banking',    'url' => 'https://www.rba.gov.au/rss/rss-cb-media-releases.xml'],
    ['id' => 'bis-publications','jur' => 'EU',         'cat' => 'Banking',    'url' => 'https://www.bis.org/doclist/cbspeeches.rss'],
    ['id' => 'imf-news',        'jur' => 'EU',         'cat' => 'Political',  'url' => 'https://www.imf.org/en/News/RSS?Language=ENG&Type=News'],

    // ─── Treasuries / finance ministries ──────────────────────────────
    ['id' => 'us-treasury',     'jur' => 'US',         'cat' => 'Regulatory', 'url' => 'https://home.treasury.gov/news/press-releases/feed'],
    ['id' => 'hm-treasury',     'jur' => 'UK',         'cat' => 'Regulatory', 'url' => 'https://www.gov.uk/government/organisations/hm-treasury.atom'],
    ['id' => 'hmrc',            'jur' => 'UK',         'cat' => 'Regulatory', 'url' => 'https://www.gov.uk/government/organisations/hm-revenue-customs.atom'],
    ['id' => 'ec-commission',   'jur' => 'EU',         'cat' => 'Regulatory', 'url' => 'https://ec.europa.eu/commission/presscorner/api/rss/all/en'],

    // ─── Sanctions and AML ────────────────────────────────────────────
    ['id' => 'ofac-recent',     'jur' => 'US',         'cat' => 'Sanctions',  'url' => 'https://ofac.treasury.gov/system/files/rss-feed/all_press_releases.rss'],
    ['id' => 'eu-sanctions',    'jur' => 'EU',         'cat' => 'Sanctions',  'url' => 'https://www.consilium.europa.eu/en/press/press-releases/?rss=true'],
    ['id' => 'fatf-news',       'jur' => 'EU',         'cat' => 'Regulatory', 'url' => 'https://www.fatf-gafi.org/en/publications.rss'],
    ['id' => 'ofsi-uk',         'jur' => 'UK',         'cat' => 'Sanctions',  'url' => 'https://www.gov.uk/government/organisations/office-of-financial-sanctions-implementation.atom'],

    // ─── Regulators ───────────────────────────────────────────────────
    ['id' => 'fca-news',        'jur' => 'UK',         'cat' => 'Regulatory', 'url' => 'https://www.fca.org.uk/news/rss.xml'],
    ['id' => 'esma-news',       'jur' => 'EU',         'cat' => 'Regulatory', 'url' => 'https://www.esma.europa.eu/rss.xml'],
    ['id' => 'bafin-news',      'jur' => 'Germany',    'cat' => 'Regulatory', 'url' => 'https://www.bafin.de/SiteGlobals/Functions/RSSFeed/EN/RSSNewsroom_en.xml'],
    ['id' => 'sec-press',       'jur' => 'US',         'cat' => 'Regulatory', 'url' => 'https://www.sec.gov/news/pressreleases.rss'],
    ['id' => 'finma',           'jur' => 'Switzerland','cat' => 'Regulatory', 'url' => 'https://www.finma.ch/en/news/rss-news/'],
    ['id' => 'cysec',           'jur' => 'Cyprus',     'cat' => 'Regulatory', 'url' => 'https://www.cysec.gov.cy/en-GB/news/rss/'],
    ['id' => 'jfsc',            'jur' => 'Jersey',     'cat' => 'Regulatory', 'url' => 'https://www.jerseyfsc.org/rss/news'],
    ['id' => 'mfsa-malta',      'jur' => 'Malta',      'cat' => 'Regulatory', 'url' => 'https://www.mfsa.mt/rss/news/'],

    // ─── World Bank / OECD ────────────────────────────────────────────
    ['id' => 'oecd-news',       'jur' => 'EU',         'cat' => 'Political',  'url' => 'https://www.oecd.org/rss/feeds/news_rss.xml'],
    ['id' => 'wb-news',         'jur' => 'EU',         'cat' => 'Political',  'url' => 'https://www.worldbank.org/en/news/rss'],

    // ─── Additional regulators / jurisdictions ────────────────────────
    ['id' => 'cbuae',           'jur' => 'UAE',        'cat' => 'Banking',    'url' => 'https://www.centralbank.ae/en/rss-news-feed/'],
    ['id' => 'qcb-qatar',       'jur' => 'Qatar',      'cat' => 'Banking',    'url' => 'https://www.qcb.gov.qa/en/rss/news'],
    ['id' => 'hkma',            'jur' => 'Hong Kong',  'cat' => 'Banking',    'url' => 'https://www.hkma.gov.hk/eng/rss/news.xml'],
    ['id' => 'bnm-malaysia',    'jur' => 'Malaysia',   'cat' => 'Banking',    'url' => 'https://www.bnm.gov.my/rss/newannouncement.xml'],
    ['id' => 'bot-thailand',    'jur' => 'Thailand',   'cat' => 'Banking',    'url' => 'https://www.bot.or.th/en/news-rss.xml'],
    ['id' => 'bi-indonesia',    'jur' => 'Indonesia',  'cat' => 'Banking',    'url' => 'https://www.bi.go.id/en/rss.xml'],
    ['id' => 'cbr-russia',      'jur' => 'Russia',     'cat' => 'Banking',    'url' => 'https://www.cbr.ru/eng/rss/press/'],
    ['id' => 'cbe-egypt',       'jur' => 'Egypt',      'cat' => 'Banking',    'url' => 'https://www.cbe.org.eg/rss/press.xml'],
    ['id' => 'cbn-nigeria',     'jur' => 'Nigeria',    'cat' => 'Banking',    'url' => 'https://www.cbn.gov.ng/rss/newsfeed.xml'],
    ['id' => 'sarb-sa',         'jur' => 'South Africa','cat'=> 'Banking',    'url' => 'https://www.resbank.co.za/rss/press.xml'],
    ['id' => 'tcmb-turkey',     'jur' => 'Turkey',     'cat' => 'Banking',    'url' => 'https://www.tcmb.gov.tr/rss/news-en.xml'],

    // ─── Political / general ───────────────────────────────────────────
    ['id' => 'reuters-fin',     'jur' => 'EU',         'cat' => 'Political',  'url' => 'https://www.reutersagency.com/feed/?best-topics=financial-services&post_type=best'],
    ['id' => 'bloomberg-emerg', 'jur' => 'EU',         'cat' => 'Political',  'url' => 'https://www.bloomberg.com/rss/pulse/europe.xml'],
];

// ─── Load seen index ───────────────────────────────────────────────────
$seen = [];
if (file_exists(SEEN_INDEX)) {
    $seen = json_decode(file_get_contents(SEEN_INDEX), true) ?: [];
}

// Clean seen index (keep last 60 days worth)
$cutoff = time() - 60 * 86400;
$seen = array_filter($seen, fn($t) => $t > $cutoff);

// ─── Load existing signals ─────────────────────────────────────────────
$signals = [];
if (file_exists(SIGNALS_FILE)) {
    $signals = json_decode(file_get_contents(SIGNALS_FILE), true) ?: [];
}

// Drop stale signals
$ageCutoff = time() - MAX_SIGNAL_AGE_DAYS * 86400;
$signals = array_filter($signals, fn($s) => ($s['ts'] ?? 0) > $ageCutoff);

// ─── Fetch each feed ───────────────────────────────────────────────────
$harvested = 0;
$totalNewItems = 0;

foreach ($FEEDS as $feed) {
    if ($totalNewItems >= MAX_ITEMS_PER_RUN) break;

    echo "[fetch] {$feed['id']} ... ";
    $items = fetchFeed($feed);

    if (empty($items)) {
        echo "no items or error\n";
        continue;
    }

    $feedNew = 0;
    foreach (array_slice($items, 0, MAX_ITEMS_PER_FEED) as $item) {
        if ($totalNewItems >= MAX_ITEMS_PER_RUN) break;

        $hash = md5($feed['id'] . '|' . ($item['link'] ?? $item['title']));
        if (isset($seen[$hash])) continue;

        // Classify with Claude
        $classified = classifyItem($item, $feed);
        if (!$classified) continue;

        $signals[] = $classified;
        $seen[$hash] = time();
        $feedNew++;
        $totalNewItems++;
    }

    echo "{$feedNew} new\n";
    $harvested++;

    // Small jitter between feeds to be polite
    usleep(random_int(200000, 600000));
}

// ─── Sort, cap, write ──────────────────────────────────────────────────
usort($signals, fn($a, $b) => ($b['ts'] ?? 0) <=> ($a['ts'] ?? 0));
$signals = array_slice($signals, 0, MAX_STORED_SIGNALS);

// Write to PENDING queue. Admin moderation required before signals appear
// on the Signal Wall. See admin/moderate.html + admin/moderate-api.php.
// Legacy behaviour (direct to signals.json) retained via ?bypass_moderation=1
// for backfill or emergency operations only.
$bypassModeration = isset($_GET['bypass_moderation']) && $_GET['bypass_moderation'] === '1';

if ($bypassModeration) {
    @file_put_contents(SIGNALS_FILE, json_encode(array_values($signals), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    echo "BYPASS: wrote " . count($signals) . " signals directly to live feed\n";
} else {
    // Merge new signals into pending queue (de-duplicated by id/hash)
    $pendingFile = __DIR__ . '/../cache/signals/pending.json';
    if (!is_dir(dirname($pendingFile))) { @mkdir(dirname($pendingFile), 0755, true); }
    $pending = [];
    if (file_exists($pendingFile)) {
        $raw = @file_get_contents($pendingFile);
        $pending = json_decode($raw, true) ?: [];
    }
    $pendingIds = array_column($pending, 'id');
    foreach ($signals as $s) {
        if (!in_array($s['id'] ?? '', $pendingIds, true)) {
            $s['ingested_at'] = date('c');
            $s['confidence_auto'] = $s['confidence_auto'] ?? 3;
            $pending[] = $s;
        }
    }
    usort($pending, fn($a, $b) => ($b['ts'] ?? 0) <=> ($a['ts'] ?? 0));
    $pending = array_slice($pending, 0, MAX_STORED_SIGNALS);
    $tmp = $pendingFile . '.tmp';
    file_put_contents($tmp, json_encode(array_values($pending), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    rename($tmp, $pendingFile);
    echo "Queued " . count($pending) . " signals to pending moderation\n";
}

@file_put_contents(SEEN_INDEX, json_encode($seen), LOCK_EX);

echo "\n---\n";
echo "Ingestion complete. {$harvested} feeds checked, {$totalNewItems} new signals added.\n";
echo "Total signals in store: " . count($signals) . "\n";


// ══════════════════════════════════════════════════════════════════════
// Helpers
// ══════════════════════════════════════════════════════════════════════

/**
 * Fetch an RSS/Atom feed and return parsed items.
 */
function fetchFeed(array $feed): array {
    $ch = curl_init($feed['url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 12,
        CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_USERAGENT => 'Mebusan Intelligence Crawler/1.0 (+https://mebusan.com/about-bot)',
        CURLOPT_SSL_VERIFYPEER => false, // Some gov sites have quirky SSL
    ]);
    $xml = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$xml || $code >= 400) return [];

    libxml_use_internal_errors(true);
    $doc = simplexml_load_string($xml);
    if (!$doc) return [];

    $items = [];

    // RSS 2.0
    if (isset($doc->channel->item)) {
        foreach ($doc->channel->item as $it) {
            $items[] = [
                'title' => trim((string)$it->title),
                'link' => trim((string)$it->link),
                'desc' => trim(strip_tags((string)$it->description)),
                'pubDate' => strtotime((string)$it->pubDate) ?: time()
            ];
        }
    }
    // Atom
    elseif (isset($doc->entry)) {
        foreach ($doc->entry as $e) {
            $link = '';
            if (isset($e->link)) {
                foreach ($e->link as $l) {
                    $href = (string)$l['href'];
                    if ($href) { $link = $href; break; }
                }
            }
            $items[] = [
                'title' => trim((string)$e->title),
                'link' => $link,
                'desc' => trim(strip_tags((string)($e->summary ?? $e->content ?? ''))),
                'pubDate' => strtotime((string)($e->updated ?? $e->published ?? 'now')) ?: time()
            ];
        }
    }

    return $items;
}

/**
 * Classify a raw feed item into a Mebusan signal via Claude API.
 * Returns a structured signal array or null if the item isn't relevant.
 */
function classifyItem(array $item, array $feed): ?array {
    $apiKey = getenv('ANTHROPIC_API_KEY') ?: '';
    if (!$apiKey) {
        // Fallback: pass through with minimal classification
        return fallbackClassify($item, $feed);
    }

    $title = substr($item['title'], 0, 500);
    $desc = substr($item['desc'], 0, 1500);
    $sourceHint = "Source: {$feed['id']} (jurisdiction hint: {$feed['jur']}, category hint: {$feed['cat']})";

    $prompt = <<<PROMPT
You classify financial-intelligence signals for Mebusan, a private intelligence service.

Given an item from a feed, return a JSON object. If the item is NOT relevant to wealth-holder concerns (cross-border banking, capital controls, regulatory pipeline, sanctions, political risk, property rules, payment rails), return {"relevant": false}.

If relevant, return JSON with these fields:
- relevant: true
- jur: string, best-fitting Mebusan jurisdiction name (e.g. "Turkey", "UAE", "UK", "Singapore", "EU", "Switzerland", etc.)
- cat: one of "Banking", "Capital", "Regulatory", "Political", "Property", "Sanctions"
- conf: 1-5 integer confidence that this is a genuine actionable signal (1 = background noise, 5 = clearly actionable)
- title: rewritten 1-sentence title in Mebusan's voice (clinical, specific, no sensationalism, no em-dashes, under 140 chars)
- context: 1-2 sentence explanation of what's happening
- action: 1-sentence implication for someone with exposure in that jurisdiction
- why: 1-sentence reason this pattern matters

Rules:
- No em-dashes. Use periods.
- Be specific, never vague.
- If confidence would be 1 or 2 based on the item, return relevant: false unless it is clearly part of a known pipeline.
- Do not speculate beyond the item.

Item:
Title: $title
Description: $desc
$sourceHint

Return only JSON. No preamble, no markdown.
PROMPT;

    $payload = [
        'model' => 'claude-sonnet-4-5',
        'max_tokens' => 800,
        'system' => 'You classify intelligence signals. Always return valid JSON only.',
        'messages' => [['role' => 'user', 'content' => $prompt]],
        'temperature' => 0.2
    ];

    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'anthropic-version: 2023-06-01',
            'x-api-key: ' . $apiKey
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$resp || $code >= 400) return fallbackClassify($item, $feed);

    $data = json_decode($resp, true);
    $text = $data['content'][0]['text'] ?? '';
    if (!$text) return null;

    // Extract JSON from response
    $text = preg_replace('/```json|```/', '', $text);
    $parsed = json_decode(trim($text), true);

    if (!$parsed || !($parsed['relevant'] ?? false)) return null;

    // Source type inference
    $src = 'open'; // Default for feed-derived
    if (stripos($feed['id'], 'press') !== false) $src = 'open';

    // Bar color based on confidence + category
    $bar = 'cream';
    if (($parsed['conf'] ?? 0) >= 4 && in_array($parsed['cat'] ?? '', ['Banking', 'Capital', 'Sanctions'])) {
        $bar = 'amber';
    } elseif (($parsed['conf'] ?? 0) >= 4) {
        $bar = 'green';
    }

    return [
        'id' => md5($feed['id'] . '|' . $item['link']),
        'ts' => $item['pubDate'],
        'jur' => $parsed['jur'] ?? $feed['jur'],
        'cat' => $parsed['cat'] ?? $feed['cat'],
        'src' => $src,
        'conf' => max(1, min(5, (int)($parsed['conf'] ?? 3))),
        'bar' => $bar,
        'title' => $parsed['title'] ?? $item['title'],
        'context' => $parsed['context'] ?? '',
        'action' => $parsed['action'] ?? '',
        'why' => $parsed['why'] ?? '',
        'source_url' => $item['link'] ?? '',
        'source_feed' => $feed['id']
    ];
}

/**
 * Fallback when Claude API is unavailable. Uses rule-based classification.
 */
function fallbackClassify(array $item, array $feed): ?array {
    // Simple keyword confidence scoring
    $text = strtolower($item['title'] . ' ' . $item['desc']);

    $keywords = [
        5 => ['capital controls', 'correspondent bank', 'sanctions', 'beneficial ownership'],
        4 => ['interest rate', 'foreign exchange', 'tax regime', 'residency program', 'disclosure'],
        3 => ['consultation', 'guidance', 'review', 'framework', 'amendment'],
    ];

    $conf = 2;
    foreach ($keywords as $level => $words) {
        foreach ($words as $w) {
            if (strpos($text, $w) !== false) { $conf = max($conf, $level); break 2; }
        }
    }

    if ($conf < 3) return null;

    return [
        'id' => md5($feed['id'] . '|' . $item['link']),
        'ts' => $item['pubDate'],
        'jur' => $feed['jur'],
        'cat' => $feed['cat'],
        'src' => 'open',
        'conf' => $conf,
        'bar' => $conf >= 4 ? 'amber' : 'cream',
        'title' => substr($item['title'], 0, 200),
        'context' => substr($item['desc'], 0, 400),
        'action' => 'See source for detail.',
        'why' => 'Source feed: ' . $feed['id'],
        'source_url' => $item['link'] ?? '',
        'source_feed' => $feed['id']
    ];
}
