<?php
/**
 * MEBUSAN — Universal Search API
 * Searches: jurisdictions, signals, briefings, services
 * GET /api/search.php?q=lebanon&type=all|jurisdiction|signal|service
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$q = strtolower(trim($_GET['q'] ?? ''));
$type = strtolower($_GET['type'] ?? 'all');

if (strlen($q) < 2) {
 echo json_encode(['results'=>[], 'count'=>0]);
 exit;
}

// Jurisdiction data (static)
$JURISDICTIONS = [
 ['name'=>'Lebanon','iso2'=>'LB','flag'=>'','risk'=>'high','region'=>'middle-east','tags'=>['banking','capital controls','BdL','dollar peg','SWIFT']],
 ['name'=>'Turkey','iso2'=>'TR','flag'=>'','risk'=>'high','region'=>'europe','tags'=>['lira','TRY','devaluation','TCMB','inflation']],
 ['name'=>'UAE','iso2'=>'AE','flag'=>'','risk'=>'elevated','region'=>'middle-east','tags'=>['ADGM','DFSA','freezone','AML','MBR']],
 ['name'=>'Switzerland','iso2'=>'CH','flag'=>'','risk'=>'low','region'=>'europe','tags'=>['FINMA','PEP','banking','secrecy','UBS']],
 ['name'=>'Nigeria','iso2'=>'NG','flag'=>'','risk'=>'high','region'=>'africa','tags'=>['naira','NGN','CBN','FX','devaluation']],
 ['name'=>'Singapore','iso2'=>'SG','flag'=>'','risk'=>'monitor','region'=>'asia','tags'=>['MAS','VCC','family office','wealth hub']],
 ['name'=>'Cayman Islands','iso2'=>'KY','flag'=>'','risk'=>'elevated','region'=>'offshore','tags'=>['CIMA','economic substance','offshore','funds']],
 ['name'=>'BVI','iso2'=>'VG','flag'=>'','risk'=>'elevated','region'=>'offshore','tags'=>['FSC','beneficial ownership','offshore','company']],
 ['name'=>'Russia','iso2'=>'RU','flag'=>'','risk'=>'high','region'=>'europe','tags'=>['sanctions','OFAC','rouble','RUB','SDN']],
 ['name'=>'Argentina','iso2'=>'AR','flag'=>'','risk'=>'high','region'=>'americas','tags'=>['peso','ARS','capital controls','cepo','inflation']],
 ['name'=>'Egypt','iso2'=>'EG','flag'=>'','risk'=>'high','region'=>'africa','tags'=>['pound','EGP','CBE','devaluation','IMF']],
 ['name'=>'Jersey','iso2'=>'JE','flag'=>'','risk'=>'monitor','region'=>'offshore','tags'=>['JFSC','private fund','offshore','trust']],
 ['name'=>'Guernsey','iso2'=>'GG','flag'=>'','risk'=>'monitor','region'=>'offshore','tags'=>['GFSC','offshore','trust','fund']],
 ['name'=>'Malta','iso2'=>'MT','flag'=>'','risk'=>'elevated','region'=>'europe','tags'=>['MFSA','gaming','crypto','FATF','EU']],
 ['name'=>'Cyprus','iso2'=>'CY','flag'=>'','risk'=>'elevated','region'=>'europe','tags'=>['CBC','banking','EU','offshore']],
];

$SERVICES = [
 ['id'=>'jurisdiction','title'=>'Jurisdiction & Law Tracking','desc'=>'Monitor laws, capital controls, beneficial ownership registers across 132 jurisdictions','url'=>'services.html#jurisdiction'],
 ['id'=>'banking','title'=>'Offshore Banking Intelligence','desc'=>'Bank stability, sanction risk, SWIFT network, liquidity signals','url'=>'services.html#banking'],
 ['id'=>'investment','title'=>'Asset Monitoring','desc'=>'Property rights, entity structures, currency risk, expropriation signals','url'=>'services.html#investment'],
 ['id'=>'regulatory','title'=>'Regulatory Early Warning','desc'=>'FATF, CRS, AML, OECD Pillar Two, EU regulatory exports','url'=>'services.html#regulatory'],
 ['id'=>'protection','title'=>'Staff Protection','desc'=>'Pre-travel risk, hostile intelligence monitoring, disinformation alerts','url'=>'services.html#protection'],
 ['id'=>'duediligence','title'=>'Due Diligence & Vetting','desc'=>'Individual and entity background intelligence, sanctions screening','url'=>'services.html#duediligence'],
];

$results = [];

// Search jurisdictions
if ($type === 'all' || $type === 'jurisdiction') {
 foreach ($JURISDICTIONS as $j) {
 $searchable = strtolower($j['name'].' '.$j['region'].' '.implode(' ',$j['tags']));
 if (strpos($searchable, $q) !== false) {
 $results[] = ['type'=>'jurisdiction','title'=>$j['flag'].' '.$j['name'],'subtitle'=>$j['risk'].' risk · '.$j['region'],'url'=>'jurisdictions.html','data'=>$j];
 }
 }
}

// Search services
if ($type === 'all' || $type === 'service') {
 foreach ($SERVICES as $s) {
 if (strpos(strtolower($s['title'].' '.$s['desc']), $q) !== false) {
 $results[] = ['type'=>'service','title'=>$s['title'],'subtitle'=>$s['desc'],'url'=>$s['url']];
 }
 }
}

// Search cached feed items
if ($type === 'all' || $type === 'signal') {
 $cacheDir = __DIR__ . '/../cache/';
 if (is_dir($cacheDir)) {
 foreach (glob($cacheDir . '*.json') as $f) {
 $items = json_decode(file_get_contents($f), true);
 if (!is_array($items)) continue;
 foreach ($items as $item) {
 if (!isset($item['title'])) continue;
 if (strpos(strtolower($item['title'].' '.($item['body']??'')), $q) !== false) {
 $results[] = ['type'=>'signal','title'=>$item['title'],'subtitle'=>($item['source']??'Signal').' · '.($item['time']??''),'url'=>'intelligence.html'];
 if (count(array_filter($results,fn($r)=>$r['type']==='signal')) >= 5) break 2;
 }
 }
 }
 }
}

echo json_encode([
 'success' => true,
 'query' => $q,
 'count' => count($results),
 'results' => array_slice($results, 0, 20),
]);
