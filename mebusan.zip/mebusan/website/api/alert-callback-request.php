<?php
/**
 * MEBUSAN · Callback-request endpoint
 * Client asked analyst to call back. Records intent and pings the desk.
 * In production this also fires an SMS to the on-call analyst.
 */
declare(strict_types=1);
header('Content-Type: application/json');

$body = json_decode(file_get_contents('php://input') ?: '', true) ?: [];
$alertId = $body['alert_id'] ?? '';
if (!$alertId) { http_response_code(400); echo json_encode(['error' => 'alert_id required']); exit; }

$root = dirname(__DIR__);
$file = $root . '/cache/critical_alerts/' . preg_replace('/[^A-Za-z0-9_-]/', '', $alertId) . '.json';
if (!is_readable($file)) { http_response_code(404); echo json_encode(['error' => 'not found']); exit; }

$alert = json_decode((string)file_get_contents($file), true) ?: [];
$alert['callback_requested']    = true;
$alert['callback_requested_at'] = date('c');
$alert['callback_sla']          = '15 minutes';
file_put_contents($file, json_encode($alert, JSON_PRETTY_PRINT));

// Optional: fire SMS to analyst via Twilio (best-effort; ignore failures)
$sid   = getenv('TWILIO_ACCOUNT_SID') ?: '';
$token = getenv('TWILIO_AUTH_TOKEN')  ?: '';
$from  = getenv('TWILIO_FROM_NUMBER') ?: '';
$analystPhone = $alert['analyst_phone'] ?? '';
if ($sid && $token && $from && $analystPhone) {
    $name = $alert['client_name'] ?? 'client';
    $jur  = $alert['jurisdiction'] ?? 'coverage';
    $msg  = "Mebusan callback: {$name} requested callback on {$jur} alert {$alertId}. SLA 15min.";
    $ch = curl_init("https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json");
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query(['To' => $analystPhone, 'From' => $from, 'Body' => $msg]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD => "{$sid}:{$token}",
        CURLOPT_TIMEOUT => 6,
    ]);
    curl_exec($ch); curl_close($ch);
}

echo json_encode(['success' => true, 'alert_id' => $alertId, 'sla_minutes' => 15]);
