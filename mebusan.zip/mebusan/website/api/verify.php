<?php
/**
 * MEBUSAN · Verification System
 * ──────────────────────────────────────────────────────────────────────
 * Handles email and phone verification for applicants.
 * Email: via SMTP (uses existing Hostinger mail).
 * Phone: via Twilio (account already provisioned in v2).
 * 
 * Flow:
 *  1. Applicant submits contact info during application
 *  2. System generates 6-digit code, sends via chosen channel
 *  3. Code stored hashed with 15-minute TTL
 *  4. Applicant enters code on next page
 *  5. If valid, application is marked verified
 * 
 * Avoids third parties for email. Twilio is the lightest for SMS.
 * ──────────────────────────────────────────────────────────────────────
 */

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// Origin check
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = ['https://mebusan.com', 'https://www.mebusan.com'];
if (in_array($origin, $allowed, true)) {
    header("Access-Control-Allow-Origin: $origin");
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Content-Type');
}
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$action = $_GET['action'] ?? '';
$body = json_decode(file_get_contents('php://input'), true) ?: [];

// ─── Rate limit ────────────────────────────────────────────────────────
$ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '0';
if (!rateLimit($ip)) {
    http_response_code(429);
    echo json_encode(['ok' => false, 'error' => 'Too many verification attempts. Wait a few minutes.']);
    exit;
}

switch ($action) {
    case 'send-email':
        handleSendEmail($body);
        break;
    case 'send-phone':
        handleSendPhone($body);
        break;
    case 'verify':
        handleVerify($body);
        break;
    default:
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Unknown action']);
}

// ══════════════════════════════════════════════════════════════════════
// Handlers
// ══════════════════════════════════════════════════════════════════════

function handleSendEmail(array $body): void {
    $email = trim($body['email'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Valid email required']);
        return;
    }

    $code = sprintf('%06d', random_int(0, 999999));
    $token = bin2hex(random_bytes(16));
    storeCode($token, $email, 'email', $code);

    $subject = 'Mebusan verification code';
    $message = "Your Mebusan verification code is:\n\n$code\n\nValid for 15 minutes. You requested this; if you did not, ignore this message.\n\n— Mebusan";

    $headers = [
        'From: Mebusan <noreply@mebusan.com>',
        'Reply-To: noreply@mebusan.com',
        'X-Mailer: Mebusan/1.0',
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'Content-Transfer-Encoding: 8bit'
    ];

    $sent = @mail($email, $subject, $message, implode("\r\n", $headers), '-f noreply@mebusan.com');

    if (!$sent) {
        // Fallback: log failure but don't leak detail to client
        @error_log("Mebusan verification email failed for " . substr($email, 0, 3) . "...");
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Could not send. Try the phone option.']);
        return;
    }

    echo json_encode([
        'ok' => true,
        'token' => $token,
        'method' => 'email',
        'masked' => maskEmail($email),
        'expires_in' => 900
    ]);
}

function handleSendPhone(array $body): void {
    $phone = trim($body['phone'] ?? '');
    // E.164 validation
    if (!preg_match('/^\+[1-9]\d{7,14}$/', $phone)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Phone must be in international format, e.g. +4471234567890']);
        return;
    }

    $code = sprintf('%06d', random_int(0, 999999));
    $token = bin2hex(random_bytes(16));
    storeCode($token, $phone, 'phone', $code);

    $message = "Mebusan verification code: $code. Valid 15 minutes.";

    $sent = sendTwilioSms($phone, $message);

    if (!$sent) {
        http_response_code(503);
        echo json_encode(['ok' => false, 'error' => 'SMS temporarily unavailable. Use email verification instead.']);
        return;
    }

    echo json_encode([
        'ok' => true,
        'token' => $token,
        'method' => 'phone',
        'masked' => maskPhone($phone),
        'expires_in' => 900
    ]);
}

function handleVerify(array $body): void {
    $token = trim($body['token'] ?? '');
    $code = trim($body['code'] ?? '');

    if (!preg_match('/^[a-f0-9]{32}$/', $token) || !preg_match('/^\d{6}$/', $code)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid format']);
        return;
    }

    $record = loadCode($token);
    if (!$record) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'Code expired or not found. Request a new one.']);
        return;
    }

    // Prevent brute force
    $attempts = $record['attempts'] ?? 0;
    if ($attempts >= 5) {
        deleteCode($token);
        http_response_code(429);
        echo json_encode(['ok' => false, 'error' => 'Too many attempts. Request a new code.']);
        return;
    }

    if (!hash_equals($record['code_hash'], hash('sha256', $code))) {
        // Increment attempts
        $record['attempts'] = $attempts + 1;
        saveCode($token, $record);
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Incorrect code. Try again.']);
        return;
    }

    // Success
    deleteCode($token);
    $verifiedToken = bin2hex(random_bytes(24));
    saveVerification($verifiedToken, $record['contact'], $record['method']);

    echo json_encode([
        'ok' => true,
        'verified_token' => $verifiedToken,
        'method' => $record['method'],
        'masked' => $record['method'] === 'email' ? maskEmail($record['contact']) : maskPhone($record['contact'])
    ]);
}

// ══════════════════════════════════════════════════════════════════════
// Helpers
// ══════════════════════════════════════════════════════════════════════

function storeCode(string $token, string $contact, string $method, string $code): void {
    saveCode($token, [
        'contact' => $contact,
        'method' => $method,
        'code_hash' => hash('sha256', $code),
        'created' => time(),
        'expires' => time() + 900,
        'attempts' => 0
    ]);
}

function codeDir(): string {
    $dir = __DIR__ . '/../cache/verify';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    return $dir;
}

function saveCode(string $token, array $data): void {
    @file_put_contents(codeDir() . '/' . $token . '.json', json_encode($data), LOCK_EX);
}

function loadCode(string $token): ?array {
    $path = codeDir() . '/' . $token . '.json';
    if (!file_exists($path)) return null;
    $data = json_decode(file_get_contents($path), true);
    if (!$data || ($data['expires'] ?? 0) < time()) {
        @unlink($path);
        return null;
    }
    return $data;
}

function deleteCode(string $token): void {
    @unlink(codeDir() . '/' . $token . '.json');
}

function saveVerification(string $token, string $contact, string $method): void {
    $dir = __DIR__ . '/../cache/verified';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    @file_put_contents($dir . '/' . $token . '.json', json_encode([
        'contact' => $contact,
        'method' => $method,
        'verified_at' => time(),
        'expires' => time() + 86400 // Valid 24 hours for application submission
    ]), LOCK_EX);
}

function sendTwilioSms(string $to, string $body): bool {
    $sid = getenv('TWILIO_ACCOUNT_SID') ?: '';
    $token = getenv('TWILIO_AUTH_TOKEN') ?: '';
    $from = getenv('TWILIO_PHONE_FROM') ?: '';

    if (!$sid || !$token || !$from) {
        @error_log('Mebusan verify: Twilio creds missing');
        return false;
    }

    $url = "https://api.twilio.com/2010-04-01/Accounts/$sid/Messages.json";
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_USERPWD => "$sid:$token",
        CURLOPT_POSTFIELDS => http_build_query([
            'To' => $to,
            'From' => $from,
            'Body' => $body
        ]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $code >= 200 && $code < 300;
}

function rateLimit(string $ip): bool {
    $dir = __DIR__ . '/../cache/rate-verify';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    $file = $dir . '/' . md5($ip);
    $log = file_exists($file) ? explode(',', trim(file_get_contents($file))) : [];
    $now = time();
    $log = array_filter($log, fn($t) => ((int)$t) > $now - 3600);
    if (count($log) >= 10) return false; // 10/hour
    $log[] = (string)$now;
    @file_put_contents($file, implode(',', $log), LOCK_EX);
    return true;
}

function maskEmail(string $email): string {
    $parts = explode('@', $email);
    if (count($parts) !== 2) return '***';
    $local = $parts[0];
    $masked = substr($local, 0, 1) . str_repeat('·', max(1, strlen($local) - 2)) . substr($local, -1);
    return $masked . '@' . $parts[1];
}

function maskPhone(string $phone): string {
    if (strlen($phone) < 6) return $phone;
    return substr($phone, 0, 4) . str_repeat('·', strlen($phone) - 8) . substr($phone, -4);
}
