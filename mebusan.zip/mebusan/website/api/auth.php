<?php
/**
 * MEBUSAN — Session Authentication
 * Simple secure session management for client portal
 * In production: replace hardcoded tokens with DB + bcrypt
 *
 * POST /api/auth.php action=login  { alias, password }
 * POST /api/auth.php action=logout
 * GET  /api/auth.php action=check
 * GET  /api/auth.php action=session
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: '.$_SERVER['HTTP_ORIGIN']);
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

// Secure session config
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1); // Enable in production with HTTPS
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.use_strict_mode', 1);
ini_set('session.gc_maxlifetime', defined('SESSION_LIFETIME') ? SESSION_LIFETIME : 7200);
session_start();

/**
 * CLIENT ACCOUNTS
 * Format: 'alias|hashed_password' => client config
 * In production: store in encrypted database
 * To add a client: generate password_hash('clientpass', PASSWORD_BCRYPT)
 */
$CLIENTS = [
  // Demo client — password: "demo2025" — CHANGE IN PRODUCTION
  'demo'    => ['password_hash' => '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
                'tier'=>'Private', 'name'=>'Demo Client', 'jurisdictions'=>['LB','TR','AE','CH','KY'],
                'plan_expires'=>'2026-01-01', 'advisor'=>'Senior Advisor A'],
  // Private client — password: "private2025"
  'private' => ['password_hash' => '$2y$12$pE5JbYnPHBuWaYt2j5JkMeI9OFrHbZJvZ8oQzaVF.WbSjHQo7zK3S',
                'tier'=>'Private', 'name'=>'Private Client', 'jurisdictions'=>['LB','NG','RU','AE'],
                'plan_expires'=>'2026-01-01', 'advisor'=>'Senior Advisor B'],
];

$action = $_GET['action'] ?? $_POST['action'] ?? 'check';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $body = json_decode(file_get_contents('php://input'), true) ?? [];
  $action = $body['action'] ?? $action;
}

switch ($action) {
  case 'login':
    $body = json_decode(file_get_contents('php://input'), true) ?? [];
    $alias    = strtolower(trim($body['alias'] ?? $_POST['alias'] ?? ''));
    $password = $body['password'] ?? $_POST['password'] ?? '';

    if (!$alias || !$password) {
      http_response_code(400);
      echo json_encode(['success'=>false, 'error'=>'Credentials required']);
      exit;
    }

    // Rate limiting (simple: 5 attempts per 10 min)
    $attempts_key = 'login_attempts_'.md5($_SERVER['REMOTE_ADDR']);
    $attempts = $_SESSION[$attempts_key] ?? 0;
    $last_attempt = $_SESSION[$attempts_key.'_time'] ?? 0;
    if ($attempts >= 5 && (time() - $last_attempt) < 600) {
      http_response_code(429);
      echo json_encode(['success'=>false, 'error'=>'Too many attempts. Try again in 10 minutes.']);
      exit;
    }

    $client = $CLIENTS[$alias] ?? null;

    if ($client && password_verify($password, $client['password_hash'])) {
      // Regenerate session ID on login
      session_regenerate_id(true);
      $_SESSION['authenticated'] = true;
      $_SESSION['alias']         = $alias;
      $_SESSION['client_data']   = $client;
      $_SESSION['login_time']    = time();
      unset($_SESSION[$attempts_key], $_SESSION[$attempts_key.'_time']);

      echo json_encode([
        'success'  => true,
        'alias'    => $alias,
        'name'     => $client['name'],
        'tier'     => $client['tier'],
        'jurisdictions' => $client['jurisdictions'],
        'advisor'  => $client['advisor'],
      ]);
    } else {
      $_SESSION[$attempts_key] = ($attempts ?? 0) + 1;
      $_SESSION[$attempts_key.'_time'] = time();
      http_response_code(401);
      echo json_encode(['success'=>false, 'error'=>'Invalid credentials']);
    }
    break;

  case 'logout':
    session_destroy();
    echo json_encode(['success'=>true]);
    break;

  case 'check':
    echo json_encode([
      'authenticated' => !empty($_SESSION['authenticated']),
      'alias' => $_SESSION['alias'] ?? null,
    ]);
    break;

  case 'session':
    if (empty($_SESSION['authenticated'])) {
      http_response_code(401);
      echo json_encode(['success'=>false, 'error'=>'Not authenticated']);
      exit;
    }
    $client = $_SESSION['client_data'] ?? [];
    echo json_encode([
      'success' => true,
      'alias'   => $_SESSION['alias'],
      'name'    => $client['name'] ?? 'Client',
      'tier'    => $client['tier'] ?? 'Standard',
      'jurisdictions' => $client['jurisdictions'] ?? [],
      'advisor' => $client['advisor'] ?? 'Mebusan Advisor',
      'login_time' => $_SESSION['login_time'] ?? null,
    ]);
    break;

  default:
    http_response_code(400);
    echo json_encode(['error'=>'Unknown action']);
}
