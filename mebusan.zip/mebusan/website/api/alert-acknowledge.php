<?php
/**
 * MEBUSAN · Critical alert acknowledgement endpoint
 * Called by the in-app overlay when a client acknowledges.
 */
declare(strict_types=1);
header('Content-Type: application/json');

$body = json_decode(file_get_contents('php://input') ?: '', true) ?: [];
$alertId = $body['alert_id'] ?? '';
$method  = $body['method']   ?? 'in-app';

if (!$alertId) { http_response_code(400); echo json_encode(['error' => 'alert_id required']); exit; }

$root = dirname(__DIR__);
$file = $root . '/cache/critical_alerts/' . preg_replace('/[^A-Za-z0-9_-]/', '', $alertId) . '.json';
if (!is_readable($file)) { http_response_code(404); echo json_encode(['error' => 'not found']); exit; }

$alert = json_decode((string)file_get_contents($file), true) ?: [];
$alert['acknowledged']    = true;
$alert['acknowledged_at'] = date('c');
$alert['ack_method']      = $method;
file_put_contents($file, json_encode($alert, JSON_PRETTY_PRINT));

echo json_encode(['success' => true, 'alert_id' => $alertId]);
