<?php
/**
 * keremalbayrak.com/api/articles.php
 * Auto-generates fresh articles in Kerem Albayrak's voice every 3 days.
 * Uses Anthropic API. Caches to JSON. Served to keremalbayrak.html via fetch.
 *
 * Cron: 0 8 */3 * *  curl -s "https://keremalbayrak.com/api/articles.php?action=generate"
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=43200');

define('CACHE_DIR',  __DIR__ . '/../cache/ka/');
define('CACHE_FILE', CACHE_DIR . 'articles.json');
define('CACHE_TTL',  259200); // 3 days
define('MAX_ARTICLES', 30);

// ── API key from mebusan config ────────────────────────────────
$cfg = __DIR__ . '/config.php';
if (file_exists($cfg)) require_once $cfg;
$API_KEY = defined('ANTHROPIC_KEY') ? ANTHROPIC_KEY : (getenv('ANTHROPIC_KEY') ?: '');

// ── Topics pool — rotate through these ────────────────────────
$TOPICS = [
    ['topic' => 'GENIUS Act stablecoin framework', 'tags' => ['stablecoins','regulation','US']],
    ['topic' => 'MiCA EU crypto regulation', 'tags' => ['MiCA','EU','crypto']],
    ['topic' => 'Crypto-Asset Reporting Framework CARF', 'tags' => ['CARF','OECD','reporting']],
    ['topic' => 'Capital controls early warning signals', 'tags' => ['capital controls','currency risk']],
    ['topic' => 'UAE golden visa renewal changes', 'tags' => ['UAE','residency','golden visa']],
    ['topic' => 'Dubai digital asset regulation VARA', 'tags' => ['Dubai','VARA','crypto']],
    ['topic' => 'Beneficial ownership registers 2026', 'tags' => ['beneficial ownership','regulation']],
    ['topic' => 'FATF grey listing consequences for assets', 'tags' => ['FATF','compliance','offshore']],
    ['topic' => 'Exchange on-chain risk signals', 'tags' => ['crypto','exchange risk','on-chain']],
    ['topic' => 'Secondary sanctions third country exposure', 'tags' => ['sanctions','OFAC','compliance']],
    ['topic' => 'CRS common reporting standard accounts', 'tags' => ['CRS','OECD','offshore']],
    ['topic' => 'Basel III crypto capital review 2026', 'tags' => ['Basel III','banks','crypto']],
    ['topic' => 'Self-custody wallet legal position', 'tags' => ['self-custody','regulation','crypto']],
    ['topic' => 'Singapore FATF mutual evaluation findings', 'tags' => ['Singapore','FATF','regulation']],
    ['topic' => 'UK non-domicile abolition 2025', 'tags' => ['UK','non-dom','tax']],
    ['topic' => 'Hong Kong stablecoin framework 2025', 'tags' => ['Hong Kong','stablecoins','Asia']],
    ['topic' => 'Wealth migration patterns 2025', 'tags' => ['wealth migration','UAE','Singapore']],
    ['topic' => 'Correspondent banking de-risking', 'tags' => ['banking','SWIFT','compliance']],
    ['topic' => 'AI transaction monitoring financial surveillance', 'tags' => ['AI','banking','surveillance']],
    ['topic' => 'DeFi identity requirements Travel Rule', 'tags' => ['DeFi','FATF','identity']],
    ['topic' => 'Real estate tokenization legal risks', 'tags' => ['tokenization','property','blockchain']],
    ['topic' => 'Political risk private wealth protection', 'tags' => ['political risk','wealth','geopolitics']],
    ['topic' => 'Currency risk reserve drawdown signals', 'tags' => ['currency','central bank','risk']],
    ['topic' => 'Offshore structure beneficial ownership compliance', 'tags' => ['offshore','structures','compliance']],
    ['topic' => 'Property through structures new rules 2026', 'tags' => ['property','structures','tax']],
];

$action = $_GET['action'] ?? 'get';

// ── GET: return cached articles ────────────────────────────────
if ($action === 'get') {
    if (!file_exists(CACHE_FILE)) {
        echo json_encode(['articles' => [], 'generated' => null]);
        exit;
    }
    $data = json_decode(file_get_contents(CACHE_FILE), true);
    echo json_encode($data ?? ['articles' => [], 'generated' => null]);
    exit;
}

// ── GENERATE: create fresh articles ───────────────────────────
if ($action === 'generate') {
    if (!$API_KEY) {
        http_response_code(500);
        echo json_encode(['error' => 'No API key']);
        exit;
    }

    // Only regenerate if cache is stale
    if (file_exists(CACHE_FILE) && (time() - filemtime(CACHE_FILE)) < CACHE_TTL) {
        $data = json_decode(file_get_contents(CACHE_FILE), true);
        echo json_encode(['status' => 'cached', 'count' => count($data['articles'] ?? [])]);
        exit;
    }

    if (!is_dir(CACHE_DIR)) mkdir(CACHE_DIR, 0755, true);

    // Pick 5 random topics for this batch
    shuffle($TOPICS);
    $batch = array_slice($TOPICS, 0, 5);
    $new_articles = [];

    foreach ($batch as $t) {
        $article = generateArticle($t['topic'], $t['tags'], $API_KEY);
        if ($article) $new_articles[] = $article;
        usleep(500000); // 0.5s between calls
    }

    // Merge with existing, keep MAX_ARTICLES total, newest first
    $existing = [];
    if (file_exists(CACHE_FILE)) {
        $old = json_decode(file_get_contents(CACHE_FILE), true);
        $existing = $old['articles'] ?? [];
    }

    // Deduplicate by title
    $all = array_merge($new_articles, $existing);
    $seen = [];
    $deduped = [];
    foreach ($all as $a) {
        $key = strtolower(substr($a['title'] ?? '', 0, 40));
        if (!isset($seen[$key])) {
            $seen[$key] = true;
            $deduped[] = $a;
        }
    }

    $final = array_slice($deduped, 0, MAX_ARTICLES);

    $cache = [
        'articles'  => $final,
        'generated' => date('c'),
        'count'     => count($final),
    ];
    file_put_contents(CACHE_FILE, json_encode($cache));

    echo json_encode(['status' => 'generated', 'new' => count($new_articles), 'total' => count($final)]);
    exit;
}

// ── Generate one article via Anthropic API ────────────────────
function generateArticle($topic, $tags, $apiKey) {
    $today = date('j F Y');
    $prompt = "Write a short analytical article about: {$topic}

Today is {$today}.

Voice: Kerem Albayrak. First person, observational. I run Mebusan, a private monitoring service for people with assets across borders. My writing is direct, specific, no jargon, no sources named, no corporate language.

Format — return ONLY valid JSON, no markdown, no explanation:
{
  \"title\": \"article title as a clear statement or question, max 12 words\",
  \"deck\": \"one sentence summary, max 25 words\",
  \"body\": [\"paragraph 1\", \"paragraph 2\", \"paragraph 3\"],
  \"tags\": [\"tag1\", \"tag2\", \"tag3\"]
}

Rules:
- 3 paragraphs, each 50-80 words
- Do not name sources or publications
- Do not reveal monitoring methodology
- Do not mention Mebusan directly in the body
- Write as if I observed this myself
- Current, specific, dated perspective from {$today}
- End final paragraph with a single insight about what this means for people with assets abroad";

    $payload = json_encode([
        'model'      => 'claude-sonnet-4-20250514',
        'max_tokens' => 800,
        'messages'   => [['role' => 'user', 'content' => $prompt]],
    ]);

    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'x-api-key: ' . $apiKey,
            'anthropic-version: 2023-06-01',
        ],
        CURLOPT_TIMEOUT => 30,
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($err || !$resp) return null;

    $data = json_decode($resp, true);
    $text = $data['content'][0]['text'] ?? '';

    // Clean and parse JSON
    $text = trim($text);
    $text = preg_replace('/^```json?\s*/i', '', $text);
    $text = preg_replace('/\s*```$/', '', $text);

    $article = json_decode($text, true);
    if (!$article || !isset($article['title'])) return null;

    $id   = 'ka' . substr(md5($article['title']), 0, 8);
    $cats = ['financial','regulatory','geopolitical','banking','technology','markets'];
    $cat  = 'financial';
    foreach ($cats as $c) {
        foreach ($tags as $tag) {
            if (stripos($tag, $c) !== false) { $cat = $c; break 2; }
        }
    }

    return [
        'id'     => $id,
        'title'  => $article['title'],
        'deck'   => $article['deck'] ?? '',
        'body'   => $article['body'] ?? [],
        'tags'   => array_merge($article['tags'] ?? [], $tags),
        'cat'    => $cat,
        'author' => 'Kerem Albayrak',
        'date'   => date('j M Y'),
        'time'   => date('H:i'),
        'ts'     => time(),
    ];
}
