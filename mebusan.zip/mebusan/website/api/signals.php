<?php
/**
 * MEBUSAN · Signals API
 * Serves signals.json from cache to the public Wall and client portal.
 * Filters query params: ?jur=Turkey&cat=Banking&src=signal&conf=4
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=120'); // 2-minute cache
header('Access-Control-Allow-Origin: *');
header('X-Robots-Tag: noindex');

// Read source: prefer moderated public.json (written by admin/moderate-api.php),
// fall back to legacy signals.json for backfill or pre-moderation deployments.
$publicFile = __DIR__ . '/../cache/signals/public.json';
$legacyFile = __DIR__ . '/../cache/signals.json';
$signalsFile = file_exists($publicFile) ? $publicFile : $legacyFile;

if (!file_exists($signalsFile)) {
    echo json_encode(['signals' => [], 'total' => 0, 'status' => 'initialising']);
    exit;
}

$data = json_decode(file_get_contents($signalsFile), true) ?: [];

// ─── Filters ───────────────────────────────────────────────────────────
$jur = $_GET['jur'] ?? 'all';
$cat = $_GET['cat'] ?? 'all';
$src = $_GET['src'] ?? 'all';
$minConf = (int)($_GET['min_conf'] ?? 0);
$limit = min((int)($_GET['limit'] ?? 50), 100);

$filtered = array_filter($data, function($s) use ($jur, $cat, $src, $minConf) {
    if ($jur !== 'all' && ($s['jur'] ?? '') !== $jur) return false;
    if ($cat !== 'all' && ($s['cat'] ?? '') !== $cat) return false;
    if ($src !== 'all' && ($s['src'] ?? '') !== $src) return false;
    if (($s['conf'] ?? 0) < $minConf) return false;
    return true;
});

// Add human-readable age
$now = time();
$results = array_map(function($s) use ($now) {
    $s['age'] = humanAge($now - ($s['ts'] ?? $now));
    return $s;
}, array_slice($filtered, 0, $limit));

echo json_encode([
    'signals' => array_values($results),
    'total_matching' => count($filtered),
    'total_all' => count($data),
    'jurisdictions' => array_values(array_unique(array_column($data, 'jur'))),
    'categories' => array_values(array_unique(array_column($data, 'cat'))),
    'last_update' => $data ? max(array_column($data, 'ts')) : null,
    'last_update_age' => $data ? humanAge($now - max(array_column($data, 'ts'))) : null,
], JSON_UNESCAPED_UNICODE);

function humanAge(int $secs): string {
    if ($secs < 60) return 'just now';
    if ($secs < 3600) return floor($secs / 60) . 'm';
    if ($secs < 86400) return floor($secs / 3600) . 'h';
    return floor($secs / 86400) . 'd';
}
