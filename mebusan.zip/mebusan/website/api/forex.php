<?php
/**
 * MEBUSAN — Forex & Currency Monitor
 * Sources: Frankfurter (ECB, no API key), fawazahmed0 (GitHub CDN, no key)
 * Cache: 1 hour
 * Usage: /api/forex.php?base=USD&currencies=TRY,NGN,LBP,EGP,ARS
 * /api/forex.php?pair=USDTRY (single pair)
 * /api/forex.php?historical=USDTRY&days=30
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=3600');

define('CACHE_DIR', __DIR__ . '/../cache/forex/');
define('CACHE_TTL', 3600);

if (!is_dir(CACHE_DIR)) mkdir(CACHE_DIR, 0755, true);

function fxCache($key) { return CACHE_DIR . preg_replace('/[^a-z0-9]/','-',strtolower($key)) . '.json'; }
function fxGet($key) {
 $f = fxCache($key);
 if (file_exists($f) && (time() - filemtime($f)) < CACHE_TTL) {
 return json_decode(file_get_contents($f), true);
 }
 return null;
}
function fxSet($key, $data) { file_put_contents(fxCache($key), json_encode($data)); }

function fetchUrl($url) {
 $ctx = stream_context_create(['http'=>['timeout'=>8,'user_agent'=>'Mebusan/1.0','ignore_errors'=>true]]);
 $r = @file_get_contents($url, false, $ctx);
 return $r ? json_decode($r, true) : null;
}

// ── Frankfurter API (ECB data, no key) ──────────────────────────
function getRatesFromFrankfurter($base = 'USD', $currencies = []) {
 $ckey = 'frankfurter-'.$base.'-'.implode(',',$currencies);
 $cached = fxGet($ckey);
 if ($cached) return $cached;

 $qs = $currencies ? '?quotes='.implode(',',$currencies) : '';
 $url = "https://api.frankfurter.dev/v2/rates?base={$base}{$qs}";
 $data = fetchUrl($url);

 if (!$data || empty($data['rates'])) {
 // Fallback: fawazahmed0 GitHub CDN
 $date = date('Y-m-d');
 $base_lower = strtolower($base);
 $url2 = "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@{$date}/v1/currencies/{$base_lower}.json";
 $data2 = fetchUrl($url2);
 if ($data2 && isset($data2[$base_lower])) {
 $rates = [];
 foreach ($currencies as $c) {
 $cl = strtolower($c);
 if (isset($data2[$base_lower][$cl])) $rates[$c] = $data2[$base_lower][$cl];
 }
 $result = ['base'=>$base, 'rates'=>$rates, 'date'=>$date, 'source'=>'fawazahmed0'];
 fxSet($ckey, $result);
 return $result;
 }
 return null;
 }

 $result = ['base'=>$base, 'rates'=>$data['rates'], 'date'=>$data['date']??date('Y-m-d'), 'source'=>'frankfurter'];
 fxSet($ckey, $result);
 return $result;
}

// ── High-risk currency pairs we track ──────────────────────────
$MONITORED_CURRENCIES = [
 // Risk currencies (we track parallel market vs official)
 'TRY' => ['country'=>'Turkey', 'flag'=>'', 'risk_threshold'=>0.15],
 'NGN' => ['country'=>'Nigeria', 'flag'=>'', 'risk_threshold'=>0.10],
 'EGP' => ['country'=>'Egypt', 'flag'=>'', 'risk_threshold'=>0.10],
 'PKR' => ['country'=>'Pakistan', 'flag'=>'', 'risk_threshold'=>0.08],
 'ARS' => ['country'=>'Argentina', 'flag'=>'', 'risk_threshold'=>0.10],
 'VES' => ['country'=>'Venezuela', 'flag'=>'', 'risk_threshold'=>0.30],
 'KZT' => ['country'=>'Kazakhstan', 'flag'=>'', 'risk_threshold'=>0.07],
 'MAD' => ['country'=>'Morocco', 'flag'=>'', 'risk_threshold'=>0.05],
 'ZAR' => ['country'=>'South Africa', 'flag'=>'', 'risk_threshold'=>0.08],
 'UAH' => ['country'=>'Ukraine', 'flag'=>'', 'risk_threshold'=>0.20],
 // Offshore/wealth currencies
 'CHF' => ['country'=>'Switzerland', 'flag'=>'', 'risk_threshold'=>0.03],
 'SGD' => ['country'=>'Singapore', 'flag'=>'', 'risk_threshold'=>0.03],
 'AED' => ['country'=>'UAE', 'flag'=>'', 'risk_threshold'=>0.02],
 'QAR' => ['country'=>'Qatar', 'flag'=>'', 'risk_threshold'=>0.02],
];

$mode = $_GET['mode'] ?? 'all';

if ($mode === 'monitored') {
 $ckeys = array_keys($MONITORED_CURRENCIES);
 $rates = getRatesFromFrankfurter('USD', $ckeys);

 if (!$rates) {
 http_response_code(503);
 echo json_encode(['error' => 'Unable to fetch forex data']);
 exit;
 }

 $result = [];
 foreach ($MONITORED_CURRENCIES as $code => $info) {
 $rate = $rates['rates'][$code] ?? null;
 if ($rate === null) continue;

 // 30-day historical for volatility (cached separately)
 $hist = getHistorical('USD', $code, 7);
 $change7d = null;
 if ($hist && count($hist['rates']) >= 2) {
 $vals = array_values($hist['rates']);
 $old = reset($vals);
 $new = end($vals);
 $change7d = $old ? round((($new - $old) / $old) * 100, 2) : null;
 }

 $result[] = [
 'code' => $code,
 'country' => $info['country'],
 'flag' => $info['flag'],
 'rate' => round($rate, 4),
 'pair' => "USD/{$code}",
 'change7d' => $change7d,
 'alert' => $change7d !== null && abs($change7d) > ($info['risk_threshold'] * 100),
 'threshold' => $info['risk_threshold'] * 100,
 ];
 }

 echo json_encode([
 'success' => true,
 'date' => $rates['date'],
 'source' => $rates['source'],
 'currencies' => $result,
 ]);
 exit;
}

// Single pair
if (!empty($_GET['pair'])) {
 $pair = strtoupper($_GET['pair']);
 $base = substr($pair, 0, 3);
 $quote = substr($pair, 3);
 $data = getRatesFromFrankfurter($base, [$quote]);
 echo json_encode(['success'=>true,'pair'=>$pair,'rate'=>$data['rates'][$quote]??null,'date'=>$data['date']??null]);
 exit;
}

// Historical
if (!empty($_GET['historical'])) {
 $pair = strtoupper($_GET['historical']);
 $base = substr($pair, 0, 3);
 $quote = substr($pair, 3);
 $days = min((int)($_GET['days'] ?? 30), 365);
 $data = getHistorical($base, $quote, $days);
 echo json_encode(['success'=>true,'pair'=>$pair,'history'=>$data]);
 exit;
}

function getHistorical($base, $quote, $days) {
 $ckey = "hist-{$base}-{$quote}-{$days}";
 $cached = fxGet($ckey);
 if ($cached) return $cached;
 $from = date('Y-m-d', strtotime("-{$days} days"));
 $to = date('Y-m-d');
 $url = "https://api.frankfurter.dev/v2/rates?from={$from}&base={$base}&quotes={$quote}";
 $data = fetchUrl($url);
 if (!$data) return null;
 $result = ['from'=>$from,'to'=>$to,'base'=>$base,'quote'=>$quote,'rates'=>[]];
 if (isset($data['rates'])) {
 foreach ($data['rates'] as $date => $dayRates) {
 $result['rates'][$date] = $dayRates[$quote] ?? null;
 }
 }
 fxSet($ckey, $result);
 return $result;
}

// Default: all monitored currencies
$_GET['mode'] = 'monitored';
include __FILE__;
