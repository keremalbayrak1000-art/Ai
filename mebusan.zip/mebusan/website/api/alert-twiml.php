<?php
/**
 * MEBUSAN · Critical alert TwiML
 * ─────────────────────────────────────────────────────────────────
 * Returns the TwiML XML that Twilio uses to drive the call flow.
 *
 * Flow:
 *   1. Say: "This is Mebusan. A critical alert has been issued..."
 *   2. Gather: press 1 to acknowledge, 2 for analyst callback
 *   3. On 1: confirm acknowledgement, hang up
 *   4. On 2: dial the assigned analyst directly (conference)
 *   5. On timeout / no response: escalate to analyst
 */

declare(strict_types=1);

header('Content-Type: text/xml; charset=UTF-8');

$alertId = $_GET['alert'] ?? $_POST['alert'] ?? '';
$digit   = $_POST['Digits'] ?? '';

$root = dirname(__DIR__);
$file = $root . '/cache/critical_alerts/' . preg_replace('/[^A-Za-z0-9_-]/', '', $alertId) . '.json';
$alert = is_readable($file) ? (json_decode((string)file_get_contents($file), true) ?: []) : [];

$jurisdiction = $alert['jurisdiction'] ?? 'your coverage';
$headline     = $alert['headline']     ?? 'A situation requires your attention';
$analystPhone = $alert['analyst_phone'] ?? '';
$clientName   = $alert['client_name']   ?? '';

// Handle keypress response
if ($digit !== '') {
    if ($digit === '1') {
        // Acknowledge
        $alert['acknowledged']     = true;
        $alert['acknowledged_at']  = date('c');
        $alert['ack_method']       = 'phone-keypad';
        file_put_contents($file, json_encode($alert, JSON_PRETTY_PRINT));
        echo <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Pause length="1"/>
  <Say voice="Polly.Amy-Neural" language="en-GB">Acknowledged. Your analyst has been notified. Opening the app now will show the full context. Mebusan out.</Say>
  <Pause length="1"/>
  <Hangup/>
</Response>
XML;
        exit;
    }
    elseif ($digit === '2' && $analystPhone) {
        // Callback request — dial the analyst
        $alert['callback_requested']    = true;
        $alert['callback_requested_at'] = date('c');
        file_put_contents($file, json_encode($alert, JSON_PRETTY_PRINT));
        $analystPhoneEsc = htmlspecialchars($analystPhone, ENT_XML1);
        echo <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Amy-Neural" language="en-GB">Connecting you to your analyst. Please hold.</Say>
  <Dial timeout="30" callerId="Mebusan">
    <Number>$analystPhoneEsc</Number>
  </Dial>
</Response>
XML;
        exit;
    }
}

// Initial script
$sayHeadline = htmlspecialchars($headline, ENT_XML1);
$sayJur      = htmlspecialchars($jurisdiction, ENT_XML1);
$nameLine    = $clientName ? htmlspecialchars($clientName, ENT_XML1) . ',' : '';
$actionUrl   = 'alert-twiml.php?alert=' . urlencode($alertId);

echo <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Pause length="1"/>
  <Say voice="Polly.Amy-Neural" language="en-GB">
    $nameLine this is Mebusan.
    A critical alert has been issued on your $sayJur coverage.
    $sayHeadline.
    To acknowledge, press 1. To request an analyst callback within fifteen minutes, press 2.
    Your full briefing is available in the Mebusan app.
  </Say>
  <Gather numDigits="1" action="$actionUrl" method="POST" timeout="15">
    <Pause length="2"/>
    <Say voice="Polly.Amy-Neural" language="en-GB">
      To acknowledge, press 1. For an analyst callback, press 2.
    </Say>
  </Gather>
  <Say voice="Polly.Amy-Neural" language="en-GB">
    No response registered. This alert is being escalated to your analyst.
    You will receive a secure-channel message within fifteen minutes.
    Mebusan out.
  </Say>
  <Hangup/>
</Response>
XML;
