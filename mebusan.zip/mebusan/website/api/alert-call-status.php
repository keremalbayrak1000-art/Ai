<?php
/**
 * MEBUSAN · Twilio call status webhook
 * ─────────────────────────────────────────────────────────────────
 * Updates the alert record as the call progresses.
 * Twilio calls this on state transitions: initiated, ringing, answered, completed.
 */

declare(strict_types=1);

$alertId = $_GET['alert'] ?? $_POST['alert'] ?? '';
$callStatus = $_POST['CallStatus'] ?? '';
$callSid    = $_POST['CallSid']    ?? '';
$callDur    = $_POST['CallDuration'] ?? '';
$answeredBy = $_POST['AnsweredBy'] ?? '';

$root = dirname(__DIR__);
$file = $root . '/cache/critical_alerts/' . preg_replace('/[^A-Za-z0-9_-]/', '', $alertId) . '.json';
if (!is_readable($file)) { http_response_code(404); exit; }

$alert = json_decode((string)file_get_contents($file), true) ?: [];
$alert['call_status']   = $callStatus;
$alert['call_sid']      = $callSid ?: ($alert['call_sid'] ?? null);
$alert['call_duration'] = $callDur;
$alert['answered_by']   = $answeredBy;
$alert['last_updated']  = date('c');

// If call completed without acknowledgement, escalate
if ($callStatus === 'completed' && empty($alert['acknowledged'])) {
    $alert['escalated'] = true;
    $alert['escalated_at'] = date('c');
    $alert['escalation_reason'] = 'call completed without ack';
}

file_put_contents($file, json_encode($alert, JSON_PRETTY_PRINT));

header('Content-Type: text/plain');
echo 'ok';
