<?php
/**
 * MEBUSAN — API Health Status
 * Public endpoint showing system status
 * GET /api/status.php
 */
header('Content-Type: application/json');

function checkEndpoint($path) {
  $f = __DIR__ . '/' . basename($path);
  return file_exists($f);
}

function checkCache($dir) {
  $d = __DIR__ . '/../cache/' . $dir;
  if (!is_dir($d)) return ['exists'=>false,'writable'=>false,'files'=>0];
  return ['exists'=>true,'writable'=>is_writable($d),'files'=>count(glob($d.'/*.json'))];
}

function checkExternal($url, $timeout = 3) {
  $ctx = stream_context_create(['http'=>['timeout'=>$timeout,'user_agent'=>'Mebusan/1.0','ignore_errors'=>true]]);
  $start = microtime(true);
  $r = @file_get_contents($url, false, $ctx);
  $ms = round((microtime(true) - $start) * 1000);
  return ['reachable'=>($r !== false),'response_ms'=>$ms];
}

$status = [
  'service'   => 'MEBUSAN Intelligence Platform',
  'status'    => 'operational',
  'version'   => '4.0',
  'company'   => 'MEBUSAN AI PTE LTD · Singapore',
  'timestamp' => date('c'),
  'components' => [
    'api_feed'       => ['status'=> checkEndpoint('feed.php') ? 'available':'missing'],
    'api_forex'      => ['status'=> checkEndpoint('forex.php') ? 'available':'missing'],
    'api_risk'       => ['status'=> checkEndpoint('risk.php') ? 'available':'missing'],
    'api_sanctions'  => ['status'=> checkEndpoint('sanctions.php') ? 'available':'missing'],
    'api_intel'      => ['status'=> checkEndpoint('intel.php') ? 'available':'missing'],
    'api_auth'       => ['status'=> checkEndpoint('auth.php') ? 'available':'missing'],
    'api_alerts'     => ['status'=> checkEndpoint('alerts.php') ? 'available':'missing'],
    'api_search'     => ['status'=> checkEndpoint('search.php') ? 'available':'missing'],
    'cache_forex'    => checkCache('forex'),
    'cache_risk'     => checkCache('risk'),
    'cache_intel'    => checkCache('intel'),
  ],
  'data_sources' => [
    'frankfurter_ecb' => checkExternal('https://api.frankfurter.dev/v2/rates?base=USD&quotes=EUR'),
    'gdacs_rss'       => checkExternal('https://www.gdacs.org/xml/rss.xml'),
    'reuters_rss'     => checkExternal('https://feeds.reuters.com/reuters/worldNews'),
    'bbc_rss'         => checkExternal('https://feeds.bbci.co.uk/news/world/rss.xml'),
    'world_bank'      => checkExternal('https://api.worldbank.org/v2/country/LB?format=json'),
  ],
  'php_version' => PHP_VERSION,
  'curl_enabled' => function_exists('curl_init'),
  'cache_dir'    => is_writable(__DIR__.'/../cache/'),
];

// Set overall status based on components
$allOk = $status['cache_dir'] && $status['curl_enabled'];
if (!$allOk) $status['status'] = 'degraded';

http_response_code(200);
echo json_encode($status, JSON_PRETTY_PRINT);
