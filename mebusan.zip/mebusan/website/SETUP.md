# MEBUSAN — Deployment Setup Guide
## Last updated: April 2026

---

## Credentials already configured ✅
These are set in config.php:
- **Twilio Account SID**: AC7467d80915c3a2af53797087a83273b2
- **Twilio Auth Token**: d94b23dae265a0143f699e90eacee216
- **hCaptcha Sitekey**: fd92ad30-9ea4-4186-8398-a37efd0a1d30
- **Formspree Form ID**: mvzdrvzy

---

## Still needed before launch ⚠️

### 1. Twilio Verify Service SID (5 minutes)
1. Go to https://console.twilio.com/us1/develop/verify/services
2. Click "Create new"
3. Name it "Mebusan" 
4. Copy the Service SID (starts with VA...)
5. Open `config.php` → replace `YOUR_VERIFY_SERVICE_SID` with it

### 2. hCaptcha Secret Key (2 minutes)
1. Go to https://dashboard.hcaptcha.com
2. Settings → Secret Key → copy it
3. Open `config.php` → replace `YOUR_HCAPTCHA_SECRET_KEY` with it

### 3. Anthropic API Key (2 minutes)
1. Go to https://console.anthropic.com/keys
2. Create key → copy it
3. Open `config.php` → set `ANTHROPIC_API_KEY`
4. Also open `proxy.php` → set if not already using config

### 4. Stripe (when ready to charge)
1. Go to https://dashboard.stripe.com/apikeys
2. Copy Secret key + Publishable key
3. Open `config.php` → set `STRIPE_SECRET_KEY` and `STRIPE_PK`
4. Create products + prices in Stripe dashboard
5. Add payment links to apply.html plan cards

---

## Hostinger Deployment

### Upload files
- Upload entire `mebusan_new/` contents to `/public_html/`
- Upload `mebusan_app/index.html` to `/public_html/app/index.html`
- Set `.htaccess` to be included

### Create cache directories
```
mkdir -p /public_html/cache/feed
mkdir -p /public_html/cache/forex  
mkdir -p /public_html/cache/risk
mkdir -p /public_html/cache/intel
mkdir -p /public_html/cache/alerts
chmod 755 /public_html/cache -R
```

### PHP requirements
- PHP 8.0+ ✅ (Hostinger default)
- curl extension ✅
- json extension ✅
- session support ✅

### Cron jobs (Hostinger → Advanced → Cron Jobs)
```
*/15 * * * *  curl -s "https://mebusan.com/api/cron.php?key=CRON_KEY&action=feed"
0 * * * *     curl -s "https://mebusan.com/api/cron.php?key=CRON_KEY&action=forex"
0 */6 * * *   curl -s "https://mebusan.com/api/cron.php?key=CRON_KEY&action=risk"
0 8 * * *     curl -s "https://mebusan.com/api/cron.php?key=CRON_KEY&action=alerts"
0 7 * * 1     curl -s "https://mebusan.com/api/cron.php?key=CRON_KEY&action=briefing"
```
Replace CRON_KEY with the value in config.php.

### DNS / SSL
- Point domain to Hostinger nameservers
- Enable free SSL in Hostinger → SSL/TLS → Force HTTPS

---

## How verification flows

### Website apply.html
1. User enters phone → clicks "Send verification code"
2. `POST /api/twilio.php {action:"send", to:"+441234567890"}`
3. Twilio sends SMS → user enters 6-digit code
4. `POST /api/twilio.php {action:"verify", to:"+441234567890", code:"123456"}`
5. Returns `{valid:true}` → step marked verified
6. On final submit → hCaptcha token verified server-side via `/api/hcaptcha.php`
7. Application sent to Formspree

### Mobile app
1. Same Twilio flow via `/api/twilio.php`
2. No hCaptcha on app (native app environment)

### Dev mode (before Verify SID is set)
- Any 6-digit code is accepted
- hCaptcha is bypassed
- Everything else works normally

---

## File structure
```
public_html/
├── index.html          Homepage
├── services.html       Services  
├── intelligence.html   Live feed
├── jurisdictions.html  132 countries
├── apply.html          Application (7 steps)
├── apply-profile.html  Deep onboarding (post-payment)
├── contact.html        AI advisor
├── discreet.html      Anonymous form
├── portal.html         Client dashboard
├── docs.html           Documentation
├── 404.html            Error page
├── config.php          ← All API keys
├── proxy.php           Anthropic proxy
├── robots.txt
├── sitemap.xml
├── .htaccess
├── css/style.css
├── js/main.js
├── api/
│   ├── twilio.php      ← SMS verification
│   ├── hcaptcha.php    ← Captcha verification
│   ├── feed.php        54 RSS sources
│   ├── forex.php       14 currency pairs
│   ├── intel.php       AI intelligence
│   ├── auth.php        Session auth
│   ├── alerts.php      Alert dispatch
│   ├── risk.php        Risk scoring
│   ├── sanctions.php   OFAC screening
│   ├── search.php      Search API
│   ├── status.php      Health check
│   └── cron.php        Automation
├── legal/
│   ├── privacy.html
│   ├── terms.html
│   ├── security.html
│   ├── gdpr.html
│   ├── dpa.html
│   └── transparency.html
├── cache/              (create on server, gitignore)
└── app/
    └── index.html      Mobile app
```

## Before launch
- Add real Singapore UEN to footer: replace "Singapore" in footer with "UEN XXXXXXXXX"

## Automated Blog (add to Hostinger cron)
```
0 */4 * * *  curl -s "https://mebusan.com/api/blog.php?action=generate" > /dev/null
```
This generates one intelligence blog post every 4 hours, automatically.
The Anthropic API rewrites content from your monitored sources in Mebusan's voice.
No manual input needed.
