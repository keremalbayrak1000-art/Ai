<?php
/**
 * keremalbayrak.com/sitemap.xml
 * Dynamically generates sitemap with all pages + cached articles
 * Serve as: /sitemap.xml via .htaccess RewriteRule or name sitemap.php
 */
header('Content-Type: application/xml; charset=utf-8');
header('X-Robots-Tag: noindex');

$base  = 'https://keremalbayrak.com';
$today = date('Y-m-d');

$pages = [
    ['url' => $base,             'priority' => '1.0', 'freq' => 'weekly',  'mod' => $today],
    ['url' => $base.'/about',    'priority' => '0.9', 'freq' => 'monthly', 'mod' => $today],
    ['url' => $base.'/writing',  'priority' => '0.8', 'freq' => 'weekly',  'mod' => $today],
    ['url' => $base.'/mebusan',  'priority' => '0.7', 'freq' => 'monthly', 'mod' => $today],
];

// Load cached articles if available
$articles = [];
$cache = __DIR__ . '/cache/ka/articles.json';
if (file_exists($cache)) {
    $data = json_decode(file_get_contents($cache), true);
    foreach ($data['articles'] ?? [] as $a) {
        if (empty($a['title'])) continue;
        $slug = strtolower(preg_replace('/[^a-z0-9]+/', '-', $a['title']));
        $slug = trim($slug, '-');
        $slug = substr($slug, 0, 60);
        $date = !empty($a['date']) ? date('Y-m-d', strtotime($a['date'])) : $today;
        $articles[] = [
            'url'      => $base . '/reading/' . $slug,
            'priority' => '0.6',
            'freq'     => 'never',
            'mod'      => $date,
        ];
    }
}

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";

foreach (array_merge($pages, $articles) as $p) {
    echo "  <url>\n";
    echo "    <loc>" . htmlspecialchars($p['url']) . "</loc>\n";
    echo "    <lastmod>" . $p['mod'] . "</lastmod>\n";
    echo "    <changefreq>" . $p['freq'] . "</changefreq>\n";
    echo "    <priority>" . $p['priority'] . "</priority>\n";
    echo "  </url>\n";
}

echo '</urlset>';
