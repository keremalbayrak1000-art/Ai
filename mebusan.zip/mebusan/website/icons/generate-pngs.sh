#!/usr/bin/env bash
# =============================================================================
# MEBUSAN · App icon PNG generator
# =============================================================================
# Converts the SVG master icons into every PNG size iOS, Android, and web need.
# Run locally on your machine (macOS/Linux). No commits to the server needed.
#
# Dependencies (install one):
#   macOS:   brew install librsvg
#   Ubuntu:  sudo apt-get install librsvg2-bin imagemagick
#   Alt:     npm i -g sharp-cli  (slower, less precise at small sizes)
#
# From the website/icons directory:
#   chmod +x generate-pngs.sh && ./generate-pngs.sh
# =============================================================================

set -e
cd "$(dirname "$0")"

echo "MEBUSAN · generating PNG icons from SVG masters"
echo ""

# Pick the best SVG renderer available
if command -v rsvg-convert >/dev/null 2>&1; then
    CONVERTER="rsvg-convert"
    echo "Using rsvg-convert"
elif command -v magick >/dev/null 2>&1; then
    CONVERTER="magick"
    echo "Using ImageMagick (magick)"
elif command -v convert >/dev/null 2>&1; then
    CONVERTER="convert"
    echo "Using ImageMagick (convert)"
else
    echo "Error: neither rsvg-convert nor ImageMagick found."
    echo "Install librsvg: 'brew install librsvg' or 'sudo apt-get install librsvg2-bin'"
    exit 1
fi

render() {
    local svg="$1"
    local size="$2"
    local out="$3"

    case "$CONVERTER" in
        rsvg-convert)
            rsvg-convert -w "$size" -h "$size" "$svg" -o "$out"
            ;;
        magick)
            magick -density 600 -background none "$svg" -resize "${size}x${size}" "$out"
            ;;
        convert)
            convert -density 600 -background none "$svg" -resize "${size}x${size}" "$out"
            ;;
    esac
    echo "  ·  $out"
}

echo ""
echo "Primary icon variants (iOS 26 Liquid Glass master + 2 mode variants)"
render icon-1024.svg        1024  icon-1024.png
render icon-dark.svg        1024  icon-dark-1024.png
render icon-tinted.svg      1024  icon-tinted-1024.png

echo ""
echo "iOS App Store + iPhone + iPad sizes"
for size in 180 167 152 120 87 80 76 60 58 40 29 20; do
    render icon-1024.svg $size icon-${size}.png
done

echo ""
echo "Apple touch icon (web)"
render apple-touch-icon.svg 180  apple-touch-icon.png

echo ""
echo "Favicon PNGs"
render favicon.svg          32   favicon-32.png
render favicon.svg          16   favicon-16.png

echo ""
echo "Web manifest (PWA) icons"
render icon-1024.svg        512  icon-512.png
render icon-1024.svg        384  icon-384.png
render icon-1024.svg        192  icon-192.png
render icon-1024.svg        144  icon-144.png
render icon-1024.svg         96  icon-96.png
render icon-1024.svg         72  icon-72.png
render icon-1024.svg         48  icon-48.png

echo ""
echo "OG image placeholder (use for og:image meta tag)"
render icon-1024.svg        1200 og-image.png

echo ""
echo "Done. $(ls -1 *.png | wc -l | tr -d ' ') PNG files generated."
echo ""
echo "Next steps:"
echo "  1. For App Store submission, drop icon-1024.png into Xcode Icon Composer"
echo "  2. For web, all favicons and apple-touch icons are in place"
echo "  3. For PWA, the manifest.webmanifest at the website root points to these"
