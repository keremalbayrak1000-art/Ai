/* ════════════════════════════════════════════════════════════════
   MEBUSAN · Service Worker
   ─────────────────────────────────────────────────────────────────
   Full PWA offline support. Caches the shell + static assets on
   install, serves cached copies when offline, falls back to a
   branded offline page for pages that haven't been visited.
   ════════════════════════════════════════════════════════════════ */

const CACHE_VERSION = 'mebusan-v8-2026-04-22';
const SHELL_CACHE = 'mebusan-shell-' + CACHE_VERSION;
const RUNTIME_CACHE = 'mebusan-runtime-' + CACHE_VERSION;

// Core shell — pages a visitor is likely to hit.
// Keep this list intentionally focused; runtime cache picks up the rest.
const SHELL_URLS = [
  '/',
  '/index.html',
  '/offline.html',
  '/scanner.html',
  '/ask.html',
  '/wall.html',
  '/about.html',
  '/apply.html',
  '/pricing.html',
  '/jurisdictions.html',
  '/journal/index.html',
  '/methodology.html',
  '/glossary.html',
  '/trust.html',
  '/governance.html',
  '/letter.html',
  '/careers.html',
  '/editorial-standards.html',
  '/case-studies.html',
  '/warrant-canary.html',
  '/css/style.css',
  '/css/elite.css',
  '/css/jur-page.css',
  '/css/post.css',
  '/js/interactions.js',
  '/js/notifications.js',
  '/js/sw-register.js',
  '/icons/favicon.svg',
  '/icons/icon-1024.svg',
  '/icons/apple-touch-icon.svg',
  '/manifest.webmanifest'
];

// Install — precache shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE)
      .then(cache => cache.addAll(SHELL_URLS.map(u => new Request(u, { cache: 'reload' }))))
      .then(() => self.skipWaiting())
      .catch(err => console.error('[SW] install error:', err))
  );
});

// Activate — clean old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== SHELL_CACHE && k !== RUNTIME_CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch — smart routing
self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Only handle same-origin GET
  if (req.method !== 'GET') return;
  if (url.origin !== self.location.origin) return;

  // API and live data: network-first, short timeout, cache fallback
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(networkFirst(req, 4000));
    return;
  }

  // HTML: network-first with offline fallback
  if (req.headers.get('accept')?.includes('text/html')) {
    event.respondWith(networkFirstHtml(req));
    return;
  }

  // Static assets: cache-first
  event.respondWith(cacheFirst(req));
});

async function networkFirst(req, timeoutMs) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    const resp = await fetch(req, { signal: controller.signal });
    clearTimeout(timeout);
    if (resp.ok) {
      const cache = await caches.open(RUNTIME_CACHE);
      cache.put(req, resp.clone());
    }
    return resp;
  } catch (e) {
    const cached = await caches.match(req);
    if (cached) return cached;
    return new Response(JSON.stringify({ error: 'offline', signals: [] }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function networkFirstHtml(req) {
  try {
    const resp = await fetch(req);
    if (resp.ok) {
      const cache = await caches.open(RUNTIME_CACHE);
      cache.put(req, resp.clone());
    }
    return resp;
  } catch (e) {
    const cached = await caches.match(req);
    if (cached) return cached;
    const offline = await caches.match('/offline.html');
    return offline || new Response('Offline', { status: 503 });
  }
}

async function cacheFirst(req) {
  const cached = await caches.match(req);
  if (cached) return cached;
  try {
    const resp = await fetch(req);
    if (resp.ok && resp.status === 200) {
      const cache = await caches.open(RUNTIME_CACHE);
      cache.put(req, resp.clone());
    }
    return resp;
  } catch (e) {
    return new Response('', { status: 504 });
  }
}

// Push notification support (for when APNS/FCM certs are set up)
self.addEventListener('push', (event) => {
  if (!event.data) return;
  let data = {};
  try { data = event.data.json(); } catch (e) { data = { title: 'Mebusan', body: event.data.text() }; }

  const options = {
    body: data.body || 'New signal available',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-96.png',
    tag: data.tag || 'mebusan-signal',
    data: { url: data.url || '/wall.html' },
    requireInteraction: data.requireInteraction || false,
    silent: false
  };

  event.waitUntil(
    self.registration.showNotification(data.title || 'Mebusan', options)
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification.data?.url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then(windowClients => {
      for (const client of windowClients) {
        if (client.url === url && 'focus' in client) return client.focus();
      }
      return clients.openWindow(url);
    })
  );
});
