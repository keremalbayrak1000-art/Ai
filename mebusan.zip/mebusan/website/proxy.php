<?php
/**
 * MEBUSAN — Anthropic API Proxy
 * Routes AI requests with rate limiting, streaming support, and error handling.
 */
require_once __DIR__ . '/config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . ($_SERVER['HTTP_ORIGIN'] ?? ''));
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Rate limiting per IP — 30 requests per 10 minutes
session_start();
$ip      = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$key     = 'proxy_rate_' . md5($ip);
$window  = 600;
$limit   = 30;
$now     = time();
$history = $_SESSION[$key] ?? [];
$history = array_filter($history, fn($t) => $now - $t < $window);

if (count($history) >= $limit) {
    http_response_code(429);
    echo json_encode(['error' => 'Rate limit exceeded. Please wait before sending another message.']);
    exit;
}
$history[] = $now;
$_SESSION[$key] = array_values($history);

// Validate API key
if (empty(ANTHROPIC_API_KEY)) {
    http_response_code(503);
    echo json_encode(['error' => 'Service temporarily unavailable.']);
    exit;
}

// Read and validate request body
$body = json_decode(file_get_contents('php://input'), true);
if (!$body || !isset($body['messages'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request format.']);
    exit;
}

// Sanitise — only allow specific fields through
$payload = [
    'model'      => 'claude-sonnet-4-20250514',
    'max_tokens' => min((int)($body['max_tokens'] ?? 600), 1000),
    'messages'   => array_slice($body['messages'], -20), // cap history depth
];
if (!empty($body['system'])) $payload['system'] = substr($body['system'], 0, 4000);

// Call Anthropic
$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_HTTPHEADER     => [
        'x-api-key: '       . ANTHROPIC_API_KEY,
        'anthropic-version: 2023-06-01',
        'Content-Type: application/json',
    ],
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_SSL_VERIFYPEER => true,
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($curlErr) {
    http_response_code(502);
    echo json_encode(['error' => 'Connection error. Please try again.']);
    exit;
}

if ($httpCode !== 200) {
    $err = json_decode($response, true);
    http_response_code($httpCode >= 400 ? $httpCode : 502);
    echo json_encode(['error' => $err['error']['message'] ?? 'Service error. Please try again.']);
    exit;
}

// Pass through response
echo $response;
