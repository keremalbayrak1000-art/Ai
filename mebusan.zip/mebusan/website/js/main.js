/* ═══════════════════════════════════════════════════════
   MEBUSAN — main.js v7
   Custom select · Mobile nav · Accordions · Tabs
   Reveal · Cursor · Search · Toasts · Dropdown
   ═══════════════════════════════════════════════════════ */

/* ── Custom cursor (desktop only) ─────────────────────── */
const cursorEl = document.getElementById('cursor');
if (cursorEl && window.matchMedia('(pointer:fine)').matches) {
  document.addEventListener('mousemove', e => {
    cursorEl.style.left = e.clientX + 'px';
    cursorEl.style.top  = e.clientY + 'px';
  });
  document.addEventListener('mousedown', () => cursorEl.classList.add('big'));
  document.addEventListener('mouseup',   () => cursorEl.classList.remove('big'));
  document.querySelectorAll('a,button,[onclick]').forEach(el => {
    el.addEventListener('mouseenter', () => cursorEl.classList.add('big'));
    el.addEventListener('mouseleave', () => cursorEl.classList.remove('big'));
  });
}

/* ── Custom selects — never iOS native ────────────────── */
function toggleSelect(id) {
  const cs = document.getElementById(id);
  if (!cs) return;
  const isOpen = cs.classList.contains('open');
  // Close all others
  document.querySelectorAll('.custom-select.open').forEach(s => {
    if (s !== cs) s.classList.remove('open');
  });
  cs.classList.toggle('open', !isOpen);
}

function selectOpt(el, id) {
  const cs = document.getElementById(id);
  if (!cs) return;
  const display = cs.querySelector('.custom-select-display');
  if (display) display.textContent = el.textContent.trim();
  cs.querySelectorAll('.custom-select-opt').forEach(o => o.classList.remove('selected'));
  el.classList.add('selected');
  cs.classList.remove('open');
  // Update hidden input if present
  const hidden = cs.querySelector('input[type=hidden]');
  if (hidden) hidden.value = el.dataset.value || el.textContent.trim();
  // Fire change event
  cs.dispatchEvent(new Event('change', {bubbles:true}));
}

// Close selects on outside click
document.addEventListener('click', e => {
  if (!e.target.closest('.custom-select')) {
    document.querySelectorAll('.custom-select.open').forEach(s => s.classList.remove('open'));
  }
});

// Keyboard navigation for custom selects
document.addEventListener('keydown', e => {
  const open = document.querySelector('.custom-select.open');
  if (!open) return;
  const opts = open.querySelectorAll('.custom-select-opt');
  const selected = open.querySelector('.custom-select-opt.selected');
  let idx = Array.from(opts).indexOf(selected);
  if (e.key === 'Escape') { open.classList.remove('open'); return; }
  if (e.key === 'ArrowDown') { idx = Math.min(idx+1, opts.length-1); opts[idx]?.classList.add('focus'); opts[idx]?.scrollIntoView({block:'nearest'}); e.preventDefault(); }
  if (e.key === 'ArrowUp')   { idx = Math.max(idx-1, 0); opts[idx]?.classList.add('focus'); opts[idx]?.scrollIntoView({block:'nearest'}); e.preventDefault(); }
  if (e.key === 'Enter' && opts[idx]) { selectOpt(opts[idx], open.id); e.preventDefault(); }
});

/* ── Navigation dropdowns ─────────────────────────────── */
document.querySelectorAll('.nav-item').forEach(item => {
  const btn = item.querySelector('.nav-btn');
  const dropdown = item.querySelector('.nav-dropdown');
  if (!btn || !dropdown) return;

  btn.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = item.classList.contains('open');
    // Close all
    document.querySelectorAll('.nav-item.open').forEach(i => i.classList.remove('open'));
    if (!isOpen) item.classList.add('open');
  });
});

document.addEventListener('click', () => {
  document.querySelectorAll('.nav-item.open').forEach(i => i.classList.remove('open'));
});

/* ── Mobile nav toggle ────────────────────────────────── */
const mobileToggle = document.getElementById('nav-mobile-toggle');
const mobileMenu   = document.getElementById('nav-mobile-menu');

if (mobileToggle && mobileMenu) {
  mobileToggle.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = mobileMenu.classList.contains('open');
    mobileMenu.classList.toggle('open', !isOpen);
    mobileToggle.classList.toggle('open', !isOpen);
    document.body.style.overflow = !isOpen ? 'hidden' : '';
  });

  // Close on link click
  mobileMenu.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      mobileToggle.classList.remove('open');
      document.body.style.overflow = '';
    });
  });

  // Close on outside tap
  document.addEventListener('click', e => {
    if (!e.target.closest('#nav-mobile-menu') && !e.target.closest('#nav-mobile-toggle')) {
      mobileMenu.classList.remove('open');
      mobileToggle.classList.remove('open');
      document.body.style.overflow = '';
    }
  });
}

/* ── Accordions ───────────────────────────────────────── */
document.querySelectorAll('.accordion-trigger').forEach(trigger => {
  trigger.addEventListener('click', () => {
    const item = trigger.closest('.accordion-item');
    if (!item) return;
    const body = item.querySelector('.accordion-body');
    if (!body) return;

    const isOpen = item.classList.contains('open');

    if (isOpen) {
      body.style.maxHeight = body.scrollHeight + 'px';
      requestAnimationFrame(() => body.style.maxHeight = '0');
      item.classList.remove('open');
    } else {
      item.classList.add('open');
      body.style.maxHeight = body.scrollHeight + 'px';
      body.addEventListener('transitionend', function handler() {
        if (item.classList.contains('open')) body.style.maxHeight = 'none';
        body.removeEventListener('transitionend', handler);
      });
    }
  });
});

/* ── Tabs ─────────────────────────────────────────────── */
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const bar   = btn.closest('.tab-bar');
    const target = btn.dataset.tab;
    if (!bar || !target) return;

    bar.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const container = bar.closest('[data-tabs]') || bar.parentElement;
    container?.querySelectorAll('.tab-panel').forEach(panel => {
      panel.classList.toggle('active', panel.dataset.panel === target);
    });
  });
});

/* ── Reveal on scroll ─────────────────────────────────── */
const revealObs = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('in');
      revealObs.unobserve(entry.target);
    }
  });
}, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

document.querySelectorAll('.rv').forEach(el => revealObs.observe(el));

/* ── Global search overlay ────────────────────────────── */
const searchOverlay = document.getElementById('search-overlay');

function openSearch() {
  if (!searchOverlay) return;
  searchOverlay.style.display = 'flex';
  requestAnimationFrame(() => {
    searchOverlay.style.opacity = '1';
    document.getElementById('global-search-input')?.focus();
  });
  document.body.style.overflow = 'hidden';
}

function closeSearch() {
  if (!searchOverlay) return;
  searchOverlay.style.opacity = '0';
  setTimeout(() => { searchOverlay.style.display = 'none'; }, 180);
  document.body.style.overflow = '';
}

document.addEventListener('keydown', e => {
  if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); openSearch(); }
  if (e.key === 'Escape') { closeSearch(); document.querySelectorAll('.nav-item.open').forEach(i=>i.classList.remove('open')); }
});

const searchInput = document.getElementById('global-search-input');
if (searchInput) {
  const SEARCH_PAGES = [
    { title:'Live Intelligence Feed',     url:'intelligence.html', desc:'Real-time signals from sources monitored' },
    { title:'Jurisdiction Monitor',        url:'jurisdictions.html',desc:'Risk scores for 132 countries' },
    { title:'Services',                    url:'services.html',     desc:'All six intelligence disciplines' },
    { title:'Apply for Access',            url:'apply.html',        desc:'Start your application' },
    { title:'Contact & AI Advisor',        url:'contact.html',      desc:'Speak with our advisor' },
    { title:'Anonymous Access',            url:'discreet.html',    desc:'Apply without disclosing identity' },
    { title:'Documentation',               url:'docs.html',         desc:'Methodology and strategy guides' },
    { title:'Client Portal',               url:'portal.html',       desc:'Login to your dashboard' },
    { title:'Capital Control Strategy',    url:'docs.html',         desc:'How we detect capital controls early' },
    { title:'Banking Intelligence',        url:'services.html#banking', desc:'Banking stress monitoring' },
    { title:'Sanctions Monitoring',        url:'services.html#regulatory', desc:'OFAC, EU, UK designations' },
    { title:'Privacy Policy',              url:'legal/privacy.html',desc:'How we handle your data' },
    { title:'Terms of Service',            url:'legal/terms.html',  desc:'Service terms and conditions' },
    { title:'Security',                    url:'legal/security.html',desc:'Our security architecture' },
  ];

  const resultsEl = document.getElementById('search-results');

  searchInput.addEventListener('input', () => {
    const q = searchInput.value.toLowerCase().trim();
    if (!resultsEl) return;
    if (!q) { resultsEl.innerHTML = ''; return; }
    const matches = SEARCH_PAGES.filter(p =>
      p.title.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q)
    ).slice(0,6);
    resultsEl.innerHTML = matches.map(p =>
      `<a href="${p.url}" style="display:block;padding:12px 20px;border-bottom:.5px solid rgba(232,226,212,.05);cursor:none;transition:background .1s" onmouseenter="this.style.background='rgba(232,226,212,.03)'" onmouseleave="this.style.background=''">
        <div style="font-size:13px;color:var(--cream);font-weight:300;margin-bottom:2px">${p.title}</div>
        <div style="font-size:11px;color:var(--faint);font-weight:300">${p.desc}</div>
      </a>`
    ).join('') || `<div style="padding:16px 20px;font-size:13px;color:var(--faint);font-weight:300">No results for "${searchInput.value}"</div>`;
  });
}

/* ── Toast notifications ──────────────────────────────── */
function showToast(title, body, type) {
  const existing = document.querySelectorAll('.toast');
  existing.forEach(t => t.remove());

  const toast = document.createElement('div');
  toast.className = 'toast';
  const borderColor = type === 'success' ? 'rgba(58,122,88,.4)' : type === 'error' ? 'rgba(138,42,34,.4)' : 'rgba(232,226,212,.1)';
  toast.style.borderColor = borderColor;
  toast.innerHTML = `
    <button class="toast-close" onclick="this.closest('.toast').remove()">×</button>
    <div class="toast-title">${title}</div>
    ${body ? `<div class="toast-body">${body}</div>` : ''}`;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 4500);
}

/* ── Counter animations ───────────────────────────────── */
function animateCounter(el, target, duration) {
  const start = performance.now();
  const from = 0;
  const update = now => {
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(from + (target - from) * eased).toLocaleString();
    if (progress < 1) requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
}

const countObs = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const el = entry.target;
    const val = parseInt(el.dataset.count);
    if (!isNaN(val)) animateCounter(el, val, 1200);
    countObs.unobserve(el);
  });
}, { threshold: 0.5 });
document.querySelectorAll('[data-count]').forEach(el => countObs.observe(el));

/* ── Notification bar dismiss ─────────────────────────── */
const notifBar = document.getElementById('notif-bar');
if (notifBar) {
  setTimeout(() => {
    notifBar.style.transform = 'translateY(0)';
  }, 1500);
  const notifClose = notifBar.querySelector('.notif-close');
  if (notifClose) {
    notifClose.addEventListener('click', () => {
      notifBar.style.transform = 'translateY(100%)';
    });
  }
}

/* ── Copy-to-clipboard helper ─────────────────────────── */
function copyToClipboard(text, label) {
  navigator.clipboard?.writeText(text).then(() => {
    showToast(label || 'Copied', null, 'success');
  }).catch(() => {
    showToast('Copy failed', 'Please copy manually.', 'error');
  });
}

/* ── Inject search button into nav ───────────────────────── */
(function injectSearchBtn() {
  const navLinks = document.querySelector('.nav-links');
  if (!navLinks || document.getElementById('nav-search-btn')) return;
  const btn = document.createElement('button');
  btn.id = 'nav-search-btn';
  btn.onclick = openSearch;
  btn.innerHTML = `<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="8.5" cy="8.5" r="5.5"/><line x1="13.5" y1="13.5" x2="18" y2="18"/></svg><span>Search ⌘K</span>`;
  navLinks.appendChild(btn);
})();

/* ── Active nav link highlighting ─────────────────────── */
(function setActiveNav() {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link, .nav-mobile-link').forEach(link => {
    if (link.getAttribute('href') === path) link.classList.add('active');
  });
})();

/* ── Prevent double-tap zoom on mobile ─────────────────── */
let lastTap = 0;
document.addEventListener('touchend', e => {
  const now = Date.now();
  if (now - lastTap < 300) e.preventDefault();
  lastTap = now;
}, {passive: false});

/* ── Accessibility ────────────────────────────────────── */
// Ensure all interactive elements without visible text have aria-labels
document.querySelectorAll('button:not([aria-label])').forEach(btn => {
  if (!btn.textContent.trim()) {
    const icon = btn.querySelector('svg');
    if (icon && btn.closest('.nav-mobile-toggle')) btn.setAttribute('aria-label', 'Toggle navigation');
  }
});

// Keyboard support for custom selects
document.querySelectorAll('.custom-select').forEach(sel => {
  const display = sel.querySelector('.custom-select-display');
  if (display) {
    display.setAttribute('tabindex', '0');
    display.setAttribute('role', 'combobox');
    display.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); display.click(); }
      if (e.key === 'Escape') sel.classList.remove('open');
    });
  }
});

// Announce live feed updates to screen readers
const liveRegion = document.createElement('div');
liveRegion.setAttribute('aria-live', 'polite');
liveRegion.setAttribute('aria-atomic', 'true');
liveRegion.className = 'sr-only';
liveRegion.style.cssText = 'position:absolute;width:1px;height:1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);border:0';
document.body?.appendChild(liveRegion);

// Focus trap for mobile nav
const mobileMenuTrap = document.getElementById('nav-mobile-menu');
if (mobileMenuTrap) {
  mobileMenuTrap.addEventListener('keydown', e => {
    if (e.key !== 'Tab') return;
    const focusable = mobileMenu.querySelectorAll('a, button');
    const first = focusable[0], last = focusable[focusable.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
}
