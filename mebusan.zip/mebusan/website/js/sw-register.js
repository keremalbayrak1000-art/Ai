// Mebusan service worker registration + instant navigation.
//
// Layered performance:
//   1. Service worker (offline + shell cache) — via sw.js
//   2. Speculation Rules API (Chrome/Edge): prerender-on-hover
//   3. <link rel="prefetch"> hover fallback for Safari/Firefox
//   4. Subtle cross-fade to avoid harsh white flash between pages
//
// The net effect: internal navigation feels near-instant.

(function(){
  'use strict';

  // 1. Register service worker
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function(){
      navigator.serviceWorker.register('/sw.js').catch(function(){});
    });
  }

  try { localStorage.setItem('mebusan_last_visit', new Date().toISOString()); } catch(e){}

  // 2. Speculation Rules API (Chrome 109+, Edge)
  if (HTMLScriptElement.supports && HTMLScriptElement.supports('speculationrules')) {
    var rules = {
      prerender: [{
        where: { and: [
          { href_matches: '/*' },
          { not: { href_matches: '/admin/*' } },
          { not: { href_matches: '/api/*' } },
          { not: { href_matches: '/portal*' } },
          { not: { selector_matches: '[data-no-prefetch]' } }
        ]},
        eagerness: 'moderate'
      }],
      prefetch: [{
        where: { href_matches: '/*' },
        eagerness: 'conservative'
      }]
    };
    try {
      var s = document.createElement('script');
      s.type = 'speculationrules';
      s.textContent = JSON.stringify(rules);
      document.head.appendChild(s);
    } catch(e){}
  }

  // 3. Hover/touchstart/focus prefetch fallback
  var prefetched = new Set();
  function prefetchHref(href){
    if (!href || prefetched.has(href)) return;
    if (/^(https?:)?\/\//i.test(href) && href.indexOf(location.origin) !== 0) return;
    if (href.charAt(0) === '#') return;
    if (/\/(admin|api|portal)/.test(href)) return;
    if (href.indexOf('mailto:') === 0 || href.indexOf('tel:') === 0) return;
    prefetched.add(href);
    var l = document.createElement('link');
    l.rel = 'prefetch';
    l.href = href;
    l.as = 'document';
    document.head.appendChild(l);
  }

  function handleIntent(e){
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    if (a.hasAttribute('data-no-prefetch')) return;
    if (a.target === '_blank') return;
    prefetchHref(a.getAttribute('href'));
  }

  function bindIntentListeners(){
    document.addEventListener('mouseover', handleIntent, { capture: true, passive: true });
    document.addEventListener('touchstart', handleIntent, { capture: true, passive: true });
    document.addEventListener('focusin', handleIntent, { capture: true, passive: true });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindIntentListeners);
  } else {
    bindIntentListeners();
  }

  // 4. Subtle cross-fade on internal navigation (respects prefers-reduced-motion)
  var prm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!prm) {
    document.addEventListener('click', function(e){
      var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
      if (!a) return;
      if (a.hasAttribute('data-no-prefetch')) return;
      if (a.target === '_blank' || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var href = a.getAttribute('href');
      if (!href || href.charAt(0) === '#') return;
      if (/^(https?:)?\/\//i.test(href) && href.indexOf(location.origin) !== 0) return;
      if (href.indexOf('mailto:') === 0 || href.indexOf('tel:') === 0) return;
      if (/\.(pdf|zip|png|jpg|jpeg|svg|xml|rss)(\?|$)/i.test(href)) return;
      document.documentElement.style.transition = 'opacity .16s ease';
      document.documentElement.style.opacity = '0.65';
    }, { passive: true });

    window.addEventListener('pageshow', function(){
      document.documentElement.style.opacity = '';
    });
  }
})();
