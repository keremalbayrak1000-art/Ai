/* ════════════════════════════════════════════════════════════════
   MEBUSAN · Notification & Signal System
   ─────────────────────────────────────────────────────────────────
   Spawns live-feeling signal notifications. Runs on every page.
   Content is curated — these look like real intelligence signals
   because they describe real-feeling phenomena across the 40+
   jurisdictions we cover.
   ════════════════════════════════════════════════════════════════ */

(function() {
  'use strict';

  // ─── Signal library ──────────────────────────────────────────
  // These are the notifications that surface on the homepage.
  // Structured to feel specific. Dated where relevant.
  const SIGNALS = [
    {
      title: 'Banking · Turkey',
      text: 'Correspondent bank tightening on two USD corridors. Central bank holding rate despite inflation print.',
      meta: 'Signal data · confidence 4/5 · 12m ago',
      bar: 'amber'
    },
    {
      title: 'Regulatory · UAE',
      text: 'Beneficial ownership disclosure window closes 30 days. Non-registered structures face deregistration.',
      meta: 'Open source · confidence 5/5 · 26m ago',
      bar: 'amber'
    },
    {
      title: 'Capital · Nigeria',
      text: 'Parallel rate premium widened to 11% against official. Central bank reserve drawdown accelerating.',
      meta: 'Signal data · confidence 4/5 · 41m ago',
      bar: 'amber'
    },
    {
      title: 'Sanctions · EU',
      text: 'New designation package expected Friday. Four companies in offshore shipping flagged for review.',
      meta: 'Human source · confidence 3/5 · 1h 8m ago',
      bar: 'cream'
    },
    {
      title: 'Political · Lebanon',
      text: 'Cabinet formation stalled on banking reform. IMF position unchanged. Depositor protections deferred.',
      meta: 'Open source · confidence 4/5 · 1h 24m ago',
      bar: 'cream'
    },
    {
      title: 'Property · Switzerland',
      text: 'Lex Koller exemption review opened. Cantons submitting positions by end of quarter.',
      meta: 'Open source · confidence 5/5 · 2h ago',
      bar: 'green'
    },
    {
      title: 'Payment rails · Russia',
      text: 'Third-country correspondent bank exits Moscow coverage. CIPS routing observed increase.',
      meta: 'Signal data · confidence 4/5 · 2h 36m ago',
      bar: 'amber'
    },
    {
      title: 'Regulatory · Singapore',
      text: 'MAS consultation on family office scheme Section 13O. Public comment closes in 9 days.',
      meta: 'Open source · confidence 5/5 · 3h ago',
      bar: 'green'
    },
    {
      title: 'Banking · Egypt',
      text: 'CBE discount rate hold despite currency pressure. Inflation pipeline suggests intervention Q2.',
      meta: 'Signal data · confidence 3/5 · 3h 48m ago',
      bar: 'amber'
    },
    {
      title: 'Political · Qatar',
      text: 'QIA reallocating weight toward European property. Domestic market absorption signals tight.',
      meta: 'Human source · confidence 3/5 · 4h ago',
      bar: 'cream'
    }
  ];

  // ─── State ──────────────────────────────────────────────────
  let notifRoot = null;
  let activeCount = 0;
  let signalIdx = 0;
  const MAX_STACK = 3;
  const AUTO_DISMISS_MS = 9500;
  const FIRST_APPEARANCE_MS = 8000;
  const INTERVAL_MIN_MS = 22000;
  const INTERVAL_MAX_MS = 48000;

  // ─── Setup ──────────────────────────────────────────────────
  function init() {
    if (notifRoot) return;
    notifRoot = document.createElement('div');
    notifRoot.className = 'notif-stack';
    notifRoot.id = 'mb-notif-stack';
    document.body.appendChild(notifRoot);

    // Respect reduced motion and user-disabled notifications
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const hasSeen = sessionStorage.getItem('mb_notif_seen') === '1';
    const disabled = localStorage.getItem('mb_notif_off') === '1';

    if (disabled || prefersReduced) return;

    // Delay first appearance, then cycle
    setTimeout(() => {
      spawn();
      scheduleNext();
    }, hasSeen ? 30000 : FIRST_APPEARANCE_MS);
  }

  function scheduleNext() {
    const delay = INTERVAL_MIN_MS + Math.random() * (INTERVAL_MAX_MS - INTERVAL_MIN_MS);
    setTimeout(() => {
      spawn();
      scheduleNext();
    }, delay);
  }

  // ─── Spawn a notification ───────────────────────────────────
  function spawn(customSignal) {
    // Don't flood the stack
    if (activeCount >= MAX_STACK) return;
    // Don't spawn if tab is hidden
    if (document.hidden) return;

    const sig = customSignal || SIGNALS[signalIdx % SIGNALS.length];
    if (!customSignal) signalIdx++;

    const el = document.createElement('div');
    el.className = 'notif';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    el.innerHTML = `
      <div class="notif-icon">M</div>
      <div class="notif-body">
        <div class="notif-title">${sig.title}</div>
        <div class="notif-text">${sig.text}</div>
        <div class="notif-meta">${sig.meta}</div>
      </div>
      <button class="notif-close" aria-label="Dismiss">×</button>
    `;

    notifRoot.appendChild(el);
    activeCount++;
    sessionStorage.setItem('mb_notif_seen', '1');

    // Animate in next frame
    requestAnimationFrame(() => {
      requestAnimationFrame(() => el.classList.add('in'));
    });

    // Dismiss handlers
    const dismiss = () => {
      el.classList.remove('in');
      el.classList.add('out');
      setTimeout(() => {
        if (el.parentNode) el.parentNode.removeChild(el);
        activeCount = Math.max(0, activeCount - 1);
      }, 340);
    };

    const timer = setTimeout(dismiss, AUTO_DISMISS_MS);
    el.querySelector('.notif-close').addEventListener('click', () => {
      clearTimeout(timer);
      dismiss();
    });
  }

  // ─── Public API ─────────────────────────────────────────────
  window.MebusanNotif = {
    init,
    spawn,
    disable: () => localStorage.setItem('mb_notif_off', '1'),
    enable: () => localStorage.removeItem('mb_notif_off')
  };

  // Auto-init on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
