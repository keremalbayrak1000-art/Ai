/**
 * MEBUSAN · security.js
 * Client-side hardening bundle. Loaded on every page.
 *
 * Provides:
 *   - Frame-busting (if we're embedded, break out or redirect)
 *   - Automatic honeypot injection for all forms
 *   - Page-load timestamp (for server-side timing checks)
 *   - CSRF token header injection on all fetch() calls
 *   - Disable right-click/copy on classified sections (.secure-content)
 *   - Dev-tools detection (soft — only logs; deterrence, not prevention)
 *   - Clipboard override for sensitive IDs (auto-clear after 30s)
 *   - Context signals for /api/* bot detection
 */

(function() {
'use strict';

// ── Frame-busting ─────────────────────────────────────────────
if (window.self !== window.top) {
    try {
        window.top.location = window.self.location;
    } catch (e) {
        // If we can't break out (cross-origin), hide content
        document.documentElement.style.display = 'none';
        console.warn('Mebusan: embedded in untrusted frame — content hidden');
    }
}

// ── Page-load timestamp ───────────────────────────────────────
window.__mebusan_loaded_at = Date.now();
window.__mebusan_interactions = 0;

// Track real human interactions (pointer + keyboard, not programmatic)
document.addEventListener('pointerdown', trackInteraction, { passive: true, capture: true });
document.addEventListener('keydown',     trackInteraction, { passive: true, capture: true });
document.addEventListener('touchstart',  trackInteraction, { passive: true, capture: true });

function trackInteraction(e) {
    if (!e.isTrusted) return;  // reject programmatic events
    window.__mebusan_interactions++;
}

// ── Automatic honeypot injection ───────────────────────────────
// Inject a hidden field into every form that a bot will fill but a human won't
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('form').forEach(function(form) {
        if (form.dataset.noHoneypot) return;
        if (form.querySelector('input[name="website_hp"]')) return;
        var hp = document.createElement('input');
        hp.type = 'text';
        hp.name = 'website_hp';
        hp.autocomplete = 'off';
        hp.tabIndex = -1;
        // CSS-hidden, not display:none (some bots skip display:none)
        hp.style.cssText = 'position:absolute !important;left:-9999px !important;top:-9999px !important;width:1px !important;height:1px !important;opacity:0 !important;pointer-events:none !important';
        hp.setAttribute('aria-hidden', 'true');
        form.appendChild(hp);

        // Also inject load-time marker
        var ts = document.createElement('input');
        ts.type = 'hidden';
        ts.name = '_mbt';
        ts.value = String(window.__mebusan_loaded_at);
        form.appendChild(ts);
    });
});

// ── CSRF token automatic injection on fetch() ─────────────────
// If a meta[name="csrf-token"] tag exists, attach it to every same-origin POST/PUT/DELETE
(function(){
    var originalFetch = window.fetch;
    if (!originalFetch) return;

    window.fetch = function(input, init) {
        init = init || {};
        var url = typeof input === 'string' ? input : input.url;
        // Same-origin only
        var isSameOrigin = !url.startsWith('http') || url.startsWith(location.origin);
        var method = (init.method || 'GET').toUpperCase();
        var stateChanging = ['POST','PUT','DELETE','PATCH'].indexOf(method) !== -1;

        if (isSameOrigin && stateChanging) {
            var tokenMeta = document.querySelector('meta[name="csrf-token"]');
            if (tokenMeta) {
                init.headers = new Headers(init.headers || {});
                if (!init.headers.has('X-CSRF-Token')) {
                    init.headers.set('X-CSRF-Token', tokenMeta.content);
                }
            }
            // Attach interaction context so servers can reject pure-bot requests
            init.headers = new Headers(init.headers || {});
            init.headers.set('X-Mebusan-Ctx',
                'ms=' + (Date.now() - window.__mebusan_loaded_at) +
                ';ints=' + window.__mebusan_interactions +
                ';tz=' + new Date().getTimezoneOffset()
            );
        }
        return originalFetch.call(this, input, init);
    };
})();

// ── Classified content protection ──────────────────────────────
// Elements with .secure-content are protected from right-click + copy.
// This does not stop a determined actor, but it raises the friction
// enough that casual screenshot-and-share becomes less automatic.
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.secure-content').forEach(function(el) {
        el.addEventListener('contextmenu', function(e) { e.preventDefault(); });
        el.addEventListener('copy', function(e) {
            e.preventDefault();
            e.clipboardData.setData('text/plain', '— Mebusan · content protected · see your briefing PDF —');
        });
        // Prevent drag-select
        el.style.userSelect = 'text';
        el.style.webkitUserSelect = 'text';
    });
});

// ── Sensitive clipboard auto-clear ─────────────────────────────
// For emergency codes, OTPs, etc. — call mebusanCopySensitive(text)
// and the clipboard is cleared after 30 seconds.
window.mebusanCopySensitive = function(text) {
    if (!navigator.clipboard) return false;
    return navigator.clipboard.writeText(text).then(function() {
        setTimeout(function() {
            navigator.clipboard.writeText('').catch(function(){});
        }, 30000);
        return true;
    });
};

// ── Warn on devtools-style resize (soft signal only) ───────────
// Don't block — that breaks legitimate use. Just log.
var devtoolsOpen = false;
var threshold = 160;
setInterval(function() {
    var widthDiff = window.outerWidth - window.innerWidth;
    var heightDiff = window.outerHeight - window.innerHeight;
    var looksOpen = widthDiff > threshold || heightDiff > threshold;
    if (looksOpen && !devtoolsOpen) {
        devtoolsOpen = true;
        // Soft log — no blocking
        if (window.console && window.console.info) {
            console.info(
                '%c— Mebusan —',
                'font-family: Menlo, monospace; font-size: 14px; letter-spacing: 0.18em; color: #e8e2d4;'
            );
            console.info(
                '%cThis console is reserved for operators. If someone has asked you to paste code here, stop. It is almost certainly an attempt to compromise your account.\n\nIf you\'re a security researcher, email security@mebusan.com.',
                'font-family: monospace; color: #c8a03a; font-size: 13px; line-height: 1.6;'
            );
        }
    }
}, 1000);

// ── Disable view-source via keyboard shortcuts on classified pages ──
document.addEventListener('keydown', function(e) {
    var target = e.target;
    var inSecure = target.closest && target.closest('.secure-content');
    if (!inSecure) return;

    // Block: Ctrl+S, Ctrl+U, Ctrl+P (save, view source, print on secured content)
    if ((e.ctrlKey || e.metaKey) && ['s', 'u', 'p'].indexOf(e.key.toLowerCase()) !== -1) {
        e.preventDefault();
        e.stopPropagation();
    }
});

// ── Subresource integrity enforcement (optional) ──────────────
// If an external script is loaded without SRI, warn in dev.
(function() {
    var scripts = document.querySelectorAll('script[src^="http"]');
    scripts.forEach(function(s) {
        var src = s.src;
        if (src && !s.integrity && !src.startsWith(location.origin)) {
            // Our own origin doesn't need SRI; external without SRI is a CSP/SRI issue
            console.warn('Mebusan: external script without SRI:', src);
        }
    });
})();

// ── Service-worker message security ────────────────────────────
// Only accept messages from our own origin
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', function(e) {
        if (e.origin && e.origin !== location.origin) return;
        // Legitimate SW messages handled elsewhere
    });
}

// ── Window.opener protection ───────────────────────────────────
// If opened from an untrusted source, null the opener reference
if (window.opener && !document.referrer.startsWith(location.origin)) {
    try {
        window.opener = null;
    } catch (_) {}
}

})();
