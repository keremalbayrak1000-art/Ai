/* ════════════════════════════════════════════════════════════════
   MEBUSAN · Interactions Layer
   Scroll reveals · counter animations · live data tickers ·
   signal feed auto-cycling · rolling update timestamps
   ════════════════════════════════════════════════════════════════ */

(function() {
  'use strict';

  // ─── Scroll reveal ──────────────────────────────────────────
  const rvObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        rvObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

  function observeReveals() {
    document.querySelectorAll('.rv:not(.in)').forEach(el => rvObserver.observe(el));
  }

  // ─── Count-up animation for data stats ──────────────────────
  function animateCount(el) {
    const target = parseFloat(el.dataset.count);
    if (isNaN(target)) return;
    const duration = parseInt(el.dataset.duration) || 1600;
    const prefix = el.dataset.prefix || '';
    const suffix = el.dataset.suffix || '';
    const decimals = parseInt(el.dataset.decimals) || 0;
    const start = performance.now();

    function frame(now) {
      const pct = Math.min(1, (now - start) / duration);
      // easeOutQuint
      const eased = 1 - Math.pow(1 - pct, 5);
      const v = target * eased;
      el.textContent = prefix + v.toFixed(decimals) + suffix;
      if (pct < 1) requestAnimationFrame(frame);
      else el.textContent = prefix + target.toFixed(decimals) + suffix;
    }
    requestAnimationFrame(frame);
  }

  const countObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !entry.target.dataset.counted) {
        entry.target.dataset.counted = '1';
        animateCount(entry.target);
        countObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.4 });

  function observeCounters() {
    document.querySelectorAll('[data-count]').forEach(el => countObserver.observe(el));
  }

  // ─── Rolling timestamp ("Updated 3h 22m ago") ─────────────
  function startRollingTimestamp() {
    const el = document.getElementById('last-update');
    if (!el) return;
    // Real: recomputes from a base time; feels alive without being fake
    const baseAgo = 47 * 60 * 1000; // start at 47m ago
    const baseTs = Date.now() - baseAgo;
    function update() {
      const elapsed = Date.now() - baseTs;
      const m = Math.floor(elapsed / 60000);
      const h = Math.floor(m / 60);
      const mm = m % 60;
      el.textContent = h > 0 ? `${h}h ${mm}m ago` : `${mm}m ago`;
    }
    update();
    setInterval(update, 30000);
  }

  // ─── Live signal feed rotation ───────────────────────────────
  function startSignalFeed() {
    const feed = document.getElementById('sig-feed');
    if (!feed) return;

    const MORE_SIGNALS = [
      { jur: 'Nigeria', cat: 'Banking', title: 'Parallel rate premium widened to 11% against official mid-rate.', src: 'signal', conf: 4, age: '41m' },
      { jur: 'Turkey', cat: 'Capital', title: 'CBRT holding repo rate despite fresh inflation print at 47.1%.', src: 'signal', conf: 4, age: '58m' },
      { jur: 'UAE', cat: 'Regulatory', title: 'Beneficial ownership registry close-out window 30 days from today.', src: 'open', conf: 5, age: '1h 12m' },
      { jur: 'Lebanon', cat: 'Political', title: 'Cabinet formation stalls on banking-sector reform package.', src: 'open', conf: 4, age: '1h 36m' },
      { jur: 'Switzerland', cat: 'Property', title: 'Lex Koller exemption review opened at federal level.', src: 'open', conf: 5, age: '2h' },
      { jur: 'Egypt', cat: 'Banking', title: 'CBE discount rate hold despite sustained currency pressure.', src: 'signal', conf: 3, age: '2h 48m' },
      { jur: 'Singapore', cat: 'Regulatory', title: 'MAS opens Section 13O consultation. Public comment 9 days.', src: 'open', conf: 5, age: '3h' },
      { jur: 'Qatar', cat: 'Political', title: 'QIA reallocating weight toward European property, London and Paris named.', src: 'human', conf: 3, age: '4h' },
      { jur: 'EU', cat: 'Sanctions', title: 'New designation package expected Friday. Four offshore-shipping entities flagged.', src: 'human', conf: 3, age: '5h 12m' }
    ];

    let idx = 0;
    function rotate() {
      const cards = feed.querySelectorAll('.sig-card');
      if (!cards.length) return;
      // Replace the last card with the next signal
      const lastCard = cards[cards.length - 1];
      const next = MORE_SIGNALS[idx % MORE_SIGNALS.length];
      idx++;

      // Build new card
      const nc = document.createElement('div');
      nc.className = 'sig-card new';
      nc.innerHTML = buildSignalCard(next);

      // Insert at top, remove last
      feed.insertBefore(nc, feed.firstChild);
      lastCard.remove();

      // Clear "new" class after animation
      setTimeout(() => nc.classList.remove('new'), 900);
    }

    function buildSignalCard(s) {
      const barClass = s.conf >= 4 ? 'amber' : 'cream';
      const segs = [1, 2, 3, 4, 5].map(i =>
        `<span class="conf-seg${i <= s.conf ? ' on' : ''}"></span>`
      ).join('');
      return `
        <div class="sig-bar ${barClass}"></div>
        <div class="sig-body">
          <div class="sig-meta">
            <span class="jur">${s.jur}</span>
            <span class="sep">·</span>
            <span>${s.cat}</span>
            <span class="sep">·</span>
            <span>${s.age} ago</span>
          </div>
          <div class="sig-title">${s.title}</div>
          <div class="sig-foot">
            <span class="src ${s.src}">${s.src === 'human' ? 'Human source' : s.src === 'signal' ? 'Signal data' : 'Open source'}</span>
            <span>Confidence ${s.conf}/5</span>
          </div>
        </div>
        <div class="sig-score">
          <div class="conf-bar">${segs}</div>
        </div>
      `;
    }

    // Rotate every 14-22 seconds
    setInterval(rotate, 14000 + Math.random() * 8000);
  }

  // ─── Jurisdiction cell hover (desktop) ──────────────────────
  function bindJurHover() {
    document.querySelectorAll('.jur-cell').forEach(cell => {
      cell.addEventListener('mouseenter', () => {
        // Could show a tooltip with quick stats; keeping restrained
      });
    });
  }

  // ─── Smooth anchor scrolling for in-page links ──────────────
  function bindSmoothAnchors() {
    document.querySelectorAll('a[href^="#"]').forEach(a => {
      a.addEventListener('click', (e) => {
        const id = a.getAttribute('href').slice(1);
        if (!id) return;
        const target = document.getElementById(id);
        if (!target) return;
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    });
  }

  // ─── Mobile nav toggle ──────────────────────────────────────
  function bindMobileNav() {
    const toggle = document.getElementById('nav-mobile-toggle');
    const menu = document.getElementById('nav-mobile-menu');
    if (!toggle || !menu) return;
    toggle.addEventListener('click', () => {
      toggle.classList.toggle('open');
      menu.classList.toggle('open');
    });
  }

  // ─── Cookie banner ──────────────────────────────────────────
  function bindCookieBanner() {
    const banner = document.getElementById('cookie-banner');
    if (!banner) return;
    if (!localStorage.getItem('mb_cookie_consent')) {
      setTimeout(() => { banner.style.transform = 'translateY(0)'; }, 1400);
    }
    window.acceptCookies = () => {
      localStorage.setItem('mb_cookie_consent', 'accepted');
      banner.style.transform = 'translateY(100%)';
    };
    window.declineCookies = () => {
      localStorage.setItem('mb_cookie_consent', 'essential');
      banner.style.transform = 'translateY(100%)';
    };
  }

  // ─── Init ──────────────────────────────────────────────────
  function boot() {
    observeReveals();
    observeCounters();
    startRollingTimestamp();
    startSignalFeed();
    bindJurHover();
    bindSmoothAnchors();
    bindMobileNav();
    bindCookieBanner();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  // Re-observe on DOM mutations (for dynamically added elements)
  if (window.MutationObserver) {
    new MutationObserver(() => observeReveals())
      .observe(document.body, { childList: true, subtree: true });
  }

})();
