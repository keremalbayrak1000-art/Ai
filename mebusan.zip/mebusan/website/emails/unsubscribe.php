<?php
/**
 * MEBUSAN · Unsubscribe handler
 * ─────────────────────────────────────────────────────────────────
 * Handles both:
 *   - GET  (human visit)          — shows a brief confirmation UI
 *   - POST (Gmail/Outlook one-click via List-Unsubscribe-Post: List-Unsubscribe=One-Click)
 *
 * Token format: <urlencoded-email>.<24-char-hmac>
 * where hmac = substr(hash_hmac('sha256', email.template, UNSUB_SECRET), 0, 24)
 *
 * Categories:
 *   - marketing    (anything promotional — we currently send none)
 *   - lifecycle    (welcome sequence only)
 *   - briefings    (routine weekly/monthly)
 *   - alerts       (amber + posture change — critical alerts never unsubscribable)
 *   - billing      (never unsubscribable)
 */

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$prefsFile = $root . '/website/cache/email_prefs.json';
if (!is_dir(dirname($prefsFile))) @mkdir(dirname($prefsFile), 0755, true);

function loadPrefs(string $file): array {
    return is_readable($file) ? (json_decode((string)file_get_contents($file), true) ?: []) : [];
}
function savePrefs(string $file, array $prefs): void {
    file_put_contents($file, json_encode($prefs, JSON_PRETTY_PRINT), LOCK_EX);
}

$token = $_GET['t'] ?? $_POST['t'] ?? '';
$secret = getenv('UNSUB_SECRET') ?: 'mebusan-unsub-2026';
[$emailEnc, $hmac] = array_pad(explode('.', $token, 2), 2, '');
$email = urldecode((string)$emailEnc);
$expected = substr(hash_hmac('sha256', $email, $secret), 0, 24);

$valid = $email && hash_equals($expected, (string)$hmac) && filter_var($email, FILTER_VALIDATE_EMAIL);

// One-click POST (RFC 8058)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: text/plain');
    if (!$valid) { http_response_code(400); echo 'invalid'; exit; }
    $prefs = loadPrefs($prefsFile);
    $prefs[$email] = [
        'marketing'  => false,
        'lifecycle'  => false,
        'briefings'  => false,
        'alerts'     => false,
        'billing'    => true,  // billing is never opt-out-able
        'updated'    => date('c'),
        'source'     => 'one-click',
    ];
    savePrefs($prefsFile, $prefs);
    echo 'ok';
    exit;
}

// Handle GET with category toggle
$category = $_GET['cat'] ?? null;
$action   = $_GET['act'] ?? 'view';

if ($valid && $category && $action === 'toggle') {
    $prefs = loadPrefs($prefsFile);
    $p = $prefs[$email] ?? [
        'marketing' => true, 'lifecycle' => true, 'briefings' => true,
        'alerts' => true, 'billing' => true,
    ];
    if ($category !== 'billing') {
        $p[$category] = !($p[$category] ?? true);
    }
    $p['updated'] = date('c');
    $prefs[$email] = $p;
    savePrefs($prefsFile, $prefs);
    header('Location: /emails/unsubscribe.php?t=' . urlencode($token) . '&saved=1');
    exit;
}

$prefs = loadPrefs($prefsFile);
$p = $prefs[$email] ?? [
    'marketing' => true, 'lifecycle' => true, 'briefings' => true,
    'alerts' => true, 'billing' => true,
];

function tok($key) { return htmlspecialchars((string)$key, ENT_QUOTES, 'UTF-8'); }
$maskedEmail = $valid ? preg_replace('/(?<=.{2}).(?=.*@)/', '•', $email) : '';
$saved = isset($_GET['saved']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Email preferences · Mebusan</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#060504;color:#e8e2d4;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:40px 20px}
  .card{max-width:520px;width:100%;border:.5px solid rgba(232,226,212,.12);padding:44px 38px;background:#0a0806}
  .logo{font-family:'Josefin Sans',-apple-system,sans-serif;font-weight:300;font-size:14px;letter-spacing:.38em;color:#e8e2d4;margin-bottom:30px}
  h1{font-weight:200;font-size:28px;letter-spacing:-.02em;line-height:1.15;margin-bottom:10px}
  .sub{color:rgba(232,226,212,.55);font-size:13px;margin-bottom:30px}
  .email{font-family:Menlo,Monaco,monospace;font-size:11px;letter-spacing:.08em;color:rgba(232,226,212,.7);margin-bottom:28px;padding-bottom:18px;border-bottom:.5px solid rgba(232,226,212,.08)}
  .row{display:flex;justify-content:space-between;align-items:flex-start;padding:16px 0;border-bottom:.5px solid rgba(232,226,212,.06)}
  .row:last-of-type{border-bottom:0}
  .row .name{font-size:14px;color:#e8e2d4}
  .row .desc{font-size:11px;color:rgba(232,226,212,.45);margin-top:3px;max-width:300px;line-height:1.5}
  .pill{display:inline-block;padding:7px 14px;font-family:Menlo,Monaco,monospace;font-size:9.5px;letter-spacing:.14em;text-transform:uppercase;border:.5px solid rgba(232,226,212,.4);color:#e8e2d4;text-decoration:none;cursor:pointer;background:transparent}
  .pill.on{background:#e8e2d4;color:#060504;border-color:#e8e2d4}
  .pill.locked{opacity:.4;cursor:not-allowed}
  .notice{margin-top:24px;padding:14px 16px;border:.5px solid rgba(58,122,88,.4);background:rgba(58,122,88,.08);font-size:12px;color:rgba(232,226,212,.8)}
  .err{border-color:rgba(200,122,74,.5);background:rgba(200,122,74,.08)}
  .foot{margin-top:30px;padding-top:20px;border-top:.5px solid rgba(232,226,212,.08);font-family:Menlo,Monaco,monospace;font-size:9.5px;letter-spacing:.1em;color:rgba(232,226,212,.4);line-height:1.7}
  a{color:rgba(232,226,212,.6)}
</style>
</head>
<body>
<div class="card">
  <div class="logo">M&nbsp;E&nbsp;B&nbsp;U&nbsp;S&nbsp;A&nbsp;N</div>

  <?php if (!$valid): ?>
    <h1>Link expired.</h1>
    <div class="sub">This unsubscribe link is invalid or has expired. Contact <a href="mailto:desk@mebusan.com">desk@mebusan.com</a> if you need to update your preferences.</div>
  <?php else: ?>
    <h1>Email preferences.</h1>
    <div class="sub">You control what arrives. Critical alerts and billing cannot be switched off — they are operationally required.</div>
    <div class="email"><?= tok($maskedEmail) ?></div>

    <?php if ($saved): ?>
      <div class="notice" style="margin-bottom:24px">Preferences saved.</div>
    <?php endif; ?>

    <?php
    $cats = [
      ['lifecycle', 'Welcome sequence', 'The first two weeks after signup only. Seven notes, spaced out. Sent once.', false],
      ['briefings', 'Weekly & monthly briefings', 'Your intelligence briefings and summaries. This is the core service.', false],
      ['alerts',    'Amber alerts', 'Threshold-crossings that do not require immediate action. Critical alerts cannot be switched off.', false],
      ['marketing', 'General updates', 'Anything non-operational. Currently we send none of these.', false],
      ['billing',   'Billing & receipts', 'Receipts, payment issues, plan changes. Cannot be switched off.', true],
    ];
    foreach ($cats as [$key, $label, $desc, $locked]):
      $on = $p[$key] ?? true;
    ?>
      <div class="row">
        <div>
          <div class="name"><?= tok($label) ?></div>
          <div class="desc"><?= tok($desc) ?></div>
        </div>
        <?php if ($locked): ?>
          <span class="pill on locked">Always on</span>
        <?php else: ?>
          <a class="pill <?= $on ? 'on' : '' ?>" href="?t=<?= tok($token) ?>&cat=<?= tok($key) ?>&act=toggle">
            <?= $on ? 'On' : 'Off' ?>
          </a>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>

    <div class="foot">
      Mebusan AI PTE LTD · Singapore · <a href="https://mebusan.com">mebusan.com</a><br>
      For a full account deletion, email <a href="mailto:privacy@mebusan.com">privacy@mebusan.com</a>. Data is purged within 30 days.
    </div>
  <?php endif; ?>
</div>
</body>
</html>
