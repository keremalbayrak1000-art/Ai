<?php
/**
 * MEBUSAN · Email lifecycle scheduler
 * ─────────────────────────────────────────────────────────────────
 * Manages the queue that drives the 7-day welcome sequence and any other
 * time-based email sends.
 *
 * Queue format: each job is one JSON file at
 *   cache/email_queue/<unix_timestamp>-<uuid>.json
 *
 * with shape:
 *   {
 *     "fire_at": 1713788400,
 *     "template": "welcome-02-primer",
 *     "to": "client@example.com",
 *     "to_name": "M. Ahmadi",
 *     "vars": {...},
 *     "attach_pdf": "methodology",
 *     "category": "lifecycle",
 *     "attempts": 0,
 *     "max_attempts": 4
 *   }
 *
 * Invocation:
 *   - As a cron every 5 minutes:   php queue.php
 *   - Or on-demand from signup:     Emails::scheduleWelcome($recipient)
 *
 * Environment variables:
 *   MEBUSAN_QUEUE_MAX_PER_RUN    (default 25)
 *   MEBUSAN_QUEUE_RETRY_BACKOFF  (default "300,900,3600,14400" seconds)
 */

declare(strict_types=1);

require_once __DIR__ . '/lib/mailer.php';

class EmailQueue
{
    private string $queueDir;
    private string $sentDir;
    private MebusanMailer $mailer;
    private array $backoff;

    public function __construct()
    {
        $root = dirname(__DIR__, 2);
        $this->queueDir = $root . '/website/cache/email_queue';
        $this->sentDir  = $root . '/website/cache/email_sent';
        foreach ([$this->queueDir, $this->sentDir] as $d) {
            if (!is_dir($d)) @mkdir($d, 0755, true);
        }
        $this->mailer = new MebusanMailer();
        $raw = getenv('MEBUSAN_QUEUE_RETRY_BACKOFF') ?: '300,900,3600,14400';
        $this->backoff = array_map('intval', explode(',', $raw));
    }

    /**
     * Schedule the full welcome sequence for a newly-activated subscriber.
     * Call this at the moment payment succeeds.
     */
    public function scheduleWelcome(array $recipient): void
    {
        // Send welcome-01 immediately (inline, not queued)
        $this->mailer->send([
            'to'         => $recipient['email'],
            'to_name'    => $recipient['name'] ?? '',
            'template'   => 'welcome-01-immediate',
            'vars'       => $recipient,
            'attach_pdf' => 'welcome-pack',
            'attach_pdf_vars' => $recipient,
            'category'   => 'lifecycle',
        ]);

        $now = time();
        $schedule = [
            ['+1 hour',   'welcome-02-primer',         'methodology'],
            ['+4 hours',  'welcome-03-analyst',         null],
            ['+24 hours', 'welcome-04-first-briefing',  null],
            ['+3 days',   'welcome-05-security',        'security-guide'],
            ['+7 days',   'welcome-06-first-week',      null],
            ['+14 days',  'welcome-07-two-weeks',       null],
        ];

        foreach ($schedule as [$when, $template, $pdf]) {
            $fireAt = strtotime($when, $now);
            $this->enqueue([
                'fire_at'         => $fireAt,
                'template'        => $template,
                'to'              => $recipient['email'],
                'to_name'         => $recipient['name'] ?? '',
                'vars'            => $recipient,
                'attach_pdf'      => $pdf,
                'attach_pdf_vars' => $recipient,
                'category'        => 'lifecycle',
                'attempts'        => 0,
                'max_attempts'    => 4,
            ]);
        }
    }

    /**
     * Full onboarding orchestration. Call this at moment payment succeeds:
     *   1. Creates a signing session via sign-request.php
     *   2. Sends engagement-sign-required email immediately (with unsigned PDF attached)
     *   3. Schedules welcome-01 for +5 minutes (assumes signing happens within that window,
     *      but welcome-01 lands regardless so client has full context)
     *   4. Schedules welcome-02 through welcome-07 as before
     *
     * $recipient must contain: email, name, name_slug, tier, confirmation_id,
     *                          first_briefing_date, response_window, coverage_summary.
     */
    public function scheduleOnboarding(array $recipient): array
    {
        // 1. Create signing session
        $sessionPayload = [
            'session_id'      => 'SGN-' . strtoupper(bin2hex(random_bytes(8))),
            'document_id'     => 'MBSN-DOC-' . strtoupper(bin2hex(random_bytes(4))),
            'email'           => $recipient['email'],
            'name'            => $recipient['name'] ?? '',
            'name_slug'       => $recipient['name_slug'] ?? '',
            'tier'            => $recipient['tier'] ?? 'Advisory',
            'confirmation_id' => $recipient['confirmation_id'] ?? '',
            'issued_at'       => date('c'),
            'expires_at'      => date('c', time() + 90 * 86400),
            'signed'          => false,
        ];
        require_once dirname(__DIR__) . '/api/_security.php';
        MebusanSecurity::saveSigningSession($sessionPayload);
        $token = MebusanSecurity::issueSigningToken($sessionPayload['session_id']);
        $signUrl = 'https://mebusan.com/sign.html?t=' . $token;

        // 2. Send sign-required immediately with unsigned PDF attached
        $signVars = array_merge($recipient, [
            'sign_url'         => $signUrl,
            'document_id'      => $sessionPayload['document_id'],
            'expires_at_human' => date('j M Y', strtotime($sessionPayload['expires_at'])),
        ]);
        $this->mailer->send([
            'to'              => $recipient['email'],
            'to_name'         => $recipient['name'] ?? '',
            'template'        => 'engagement-sign-required',
            'vars'            => $signVars,
            'attach_pdf'      => 'engagement-letter',
            'attach_pdf_vars' => $signVars,
            'category'        => 'transactional',
        ]);

        // 3. Welcome-01 goes out 5 minutes later (after the sign email has been seen)
        $this->enqueue([
            'fire_at'         => time() + 300,
            'template'        => 'welcome-01-immediate',
            'to'              => $recipient['email'],
            'to_name'         => $recipient['name'] ?? '',
            'vars'            => $recipient,
            'attach_pdf'      => 'welcome-pack',
            'attach_pdf_vars' => $recipient,
            'category'        => 'lifecycle',
            'attempts'        => 0,
            'max_attempts'    => 4,
        ]);

        // 4. Rest of welcome sequence
        $now = time();
        $schedule = [
            ['+1 hour',   'welcome-02-primer',         'methodology'],
            ['+4 hours',  'welcome-03-analyst',         null],
            ['+24 hours', 'welcome-04-first-briefing',  null],
            ['+3 days',   'welcome-05-security',        'security-guide'],
            ['+7 days',   'welcome-06-first-week',      null],
            ['+14 days',  'welcome-07-two-weeks',       null],
        ];
        foreach ($schedule as [$when, $template, $pdf]) {
            $this->enqueue([
                'fire_at'         => strtotime($when, $now),
                'template'        => $template,
                'to'              => $recipient['email'],
                'to_name'         => $recipient['name'] ?? '',
                'vars'            => $recipient,
                'attach_pdf'      => $pdf,
                'attach_pdf_vars' => $recipient,
                'category'        => 'lifecycle',
                'attempts'        => 0,
                'max_attempts'    => 4,
            ]);
        }

        return [
            'session_id'  => $sessionPayload['session_id'],
            'document_id' => $sessionPayload['document_id'],
            'sign_url'    => $signUrl,
            'expires_at'  => $sessionPayload['expires_at'],
        ];
    }

    /** Enqueue a single job. */
    public function enqueue(array $job): string
    {
        $uuid = bin2hex(random_bytes(6));
        $ts   = str_pad((string)$job['fire_at'], 11, '0', STR_PAD_LEFT);
        $path = $this->queueDir . '/' . $ts . '-' . $uuid . '.json';
        file_put_contents($path, json_encode($job, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        return $path;
    }

    /** Process due jobs. Call from cron every 5 minutes. */
    public function processDue(): array
    {
        $max = (int)(getenv('MEBUSAN_QUEUE_MAX_PER_RUN') ?: 25);
        $now = time();
        $processed = [];

        $files = glob($this->queueDir . '/*.json') ?: [];
        sort($files); // oldest first (ts prefix)

        foreach ($files as $file) {
            if (count($processed) >= $max) break;

            $job = json_decode((string)file_get_contents($file), true);
            if (!$job || empty($job['fire_at'])) {
                @rename($file, $this->sentDir . '/INVALID-' . basename($file));
                continue;
            }
            if ((int)$job['fire_at'] > $now) continue; // not yet due

            // Send
            $res = $this->mailer->send([
                'to'              => $job['to'],
                'to_name'         => $job['to_name'] ?? '',
                'template'        => $job['template'],
                'vars'            => $job['vars'] ?? [],
                'attach_pdf'      => $job['attach_pdf'] ?? null,
                'attach_pdf_vars' => $job['attach_pdf_vars'] ?? ($job['vars'] ?? []),
                'category'        => $job['category'] ?? 'lifecycle',
            ]);

            if ($res['success'] ?? false) {
                @rename($file, $this->sentDir . '/' . basename($file));
            } else {
                // Retry with backoff, or give up
                $attempts = (int)($job['attempts'] ?? 0) + 1;
                $maxAttempts = (int)($job['max_attempts'] ?? 4);
                if ($attempts >= $maxAttempts) {
                    @rename($file, $this->sentDir . '/FAILED-' . basename($file));
                } else {
                    $job['attempts'] = $attempts;
                    $delay = $this->backoff[$attempts - 1] ?? end($this->backoff);
                    $job['fire_at'] = $now + $delay;
                    @unlink($file);
                    $this->enqueue($job);
                }
            }

            $processed[] = [
                'file'     => basename($file),
                'template' => $job['template'] ?? '',
                'to'       => $job['to'] ?? '',
                'ok'       => $res['success'] ?? false,
                'error'    => $res['error'] ?? null,
            ];
        }

        return $processed;
    }
}

// ─── CLI entry ─────────────────────────────────────────────────
if (php_sapi_name() === 'cli' && realpath($_SERVER['argv'][0]) === __FILE__) {
    $q = new EmailQueue();
    $result = $q->processDue();
    echo json_encode(['processed' => count($result), 'results' => $result], JSON_PRETTY_PRINT) . "\n";
}
