# Mebusan · Email & Critical Alert System

Operator setup guide. Read this end-to-end before your first production send.

---

## 1. DNS records (required before any send)

Without these, every email goes to spam. No exceptions. Set these on `mebusan.com` before provisioning anything else.

**SPF** — authorise your chosen provider to send on your behalf. TXT record on `mebusan.com`:
- Resend: `v=spf1 include:_spf.resend.com ~all`
- Postmark: `v=spf1 a mx include:spf.mtasv.net ~all`
- SendGrid: `v=spf1 include:sendgrid.net ~all`

**DKIM** — provider-specific. Each provider gives you 1–3 CNAME records to add when you verify the domain. Do that in their dashboard first, then copy-paste.

**DMARC** — TXT record on `_dmarc.mebusan.com`. Start permissive, tighten later:
```
v=DMARC1; p=quarantine; rua=mailto:dmarc@mebusan.com; aspf=s; adkim=s; pct=100
```
After two weeks of clean reports, move to `p=reject`.

**BIMI** (optional but elite) — TXT record on `default._bimi.mebusan.com` pointing to an SVG of the Mebusan mark. Gmail shows the logo next to the From line on mobile:
```
v=BIMI1; l=https://mebusan.com/brand/mebusan-bimi.svg;
```

Verify with [mail-tester.com](https://mail-tester.com) before any real campaign.

---

## 2. Choose a provider

| Provider | Why | Monthly cost (~10k sends) |
|---|---|---|
| **Resend** *(recommended)* | Modern API, clean dashboard, built by former Vercel people, excellent deliverability out of the box | $20 |
| Postmark | Transactional-only specialist, best reputation in the industry | $15 |
| SendGrid | Enterprise-grade, heavier UI | $20 |
| SMTP | Fallback for any host; works but most work to set up | Host-dependent |

Set `MEBUSAN_MAIL_PROVIDER` to one of `resend` / `postmark` / `sendgrid` / `smtp`.

---

## 3. Environment variables

Add these to Hostinger's environment config (or a `.env` loader):

```bash
# Mail provider
MEBUSAN_MAIL_PROVIDER=resend
RESEND_API_KEY=re_...

# Or if using another
POSTMARK_SERVER_TOKEN=...
SENDGRID_API_KEY=SG...

# SMTP fallback
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=587
SMTP_USER=desk@mebusan.com
SMTP_PASS=...
SMTP_ENCRYPTION=tls

# Security secrets
UNSUB_SECRET=<generate: openssl rand -hex 32>
MEBUSAN_INTERNAL_KEY=<generate: openssl rand -hex 32>

# Twilio (for critical alerts + 2FA SMS)
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_FROM_NUMBER=+1...
TWILIO_VOICE_CALLBACK_BASE=https://mebusan.com

# Queue tuning (optional)
MEBUSAN_QUEUE_MAX_PER_RUN=25
MEBUSAN_QUEUE_RETRY_BACKOFF=300,900,3600,14400
```

---

## 4. Directories

All these must exist and be writable by the PHP process:

```
website/cache/email_queue/       # Pending scheduled sends
website/cache/email_sent/        # Archived delivered jobs
website/cache/email_log/         # JSONL per-month log files
website/cache/pdf_cache/         # Reserved for generated PDF caching
website/cache/critical_alerts/   # Active + historical alert records
```

Create them:
```bash
cd public_html
mkdir -p website/cache/{email_queue,email_sent,email_log,pdf_cache,critical_alerts}
chmod 755 website/cache website/cache/*
```

---

## 5. Cron

Add to Hostinger's cron panel (or `crontab -e`):

```cron
# Every 5 minutes: fire due lifecycle emails
*/5 * * * * cd /home/USERNAME/public_html && php website/emails/queue.php >> website/cache/email_log/cron.log 2>&1

# Hourly: ingest signals (already configured)
0 * * * * cd /home/USERNAME/public_html && php website/api/ingest-signals.php

# Every 5 minutes: main site cron
*/5 * * * * cd /home/USERNAME/public_html && php website/api/cron.php
```

---

## 6. Wiring into the signup flow

When a payment succeeds (in `app/mebusan_app.html` or the server-side payment webhook), POST to the send endpoint:

```javascript
fetch('/emails/send.php?key=' + MEBUSAN_INTERNAL_KEY, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    action: 'schedule_welcome',
    recipient: {
      email: 'client@example.com',
      name: 'M. Ahmadi',
      name_slug: 'ahmadi',
      tier: 'Advisory',
      confirmation_id: 'MBSN-7421',
      first_briefing_date: 'Monday, 28 April',
      response_window: '24 hours',
      coverage_summary: 'Turkey, UAE, Switzerland',
      analyst_name: 'being assigned',
      analyst_first: 'Sara',
      analyst_email: 'desk@mebusan.com',
      backup_analyst: 'desk@mebusan.com'
    }
  })
});
```

This fires `welcome-01-immediate` inline (with welcome-pack PDF attached) and schedules the remaining six emails at +1h, +4h, +24h, +3d, +7d, +14d.

---

## 7. Billing emails

Hook into Stripe webhooks and POST to `emails/send.php` with `action: send_now`:

```javascript
// On invoice.paid
{ action: 'send_now', email: {
    to: customer.email, template: 'billing-invoice-paid',
    attach_pdf: 'invoice',
    vars: { tier, billing_cycle, period_start, period_end, payment_method, invoice_id, amount, next_renewal },
    attach_pdf_vars: { ... }
}}

// On customer.source.expiring
{ action: 'send_now', email: {
    to: customer.email, template: 'billing-card-expiring',
    vars: { card_last4, expiry_month, days_left, next_renewal, amount }
}}

// On invoice.payment_failed
{ action: 'send_now', email: {
    to: customer.email, template: 'billing-payment-failed',
    vars: { attempt_date, failure_reason, retry_date, amount, analyst_email }
}}

// On subscription.updated (plan change)
{ action: 'send_now', email: {
    to: customer.email, template: 'billing-plan-change',
    vars: { old_tier, new_tier, old_billing, new_billing, effective_date, proration, next_amount, next_renewal }
}}

// On subscription.deleted
{ action: 'send_now', email: {
    to: customer.email, template: 'billing-subscription-cancelled',
    vars: { period_end, final_briefing }
}}
```

---

## 8. Critical alerts — phone call + in-app overlay

The critical alert pipeline has three channels that fire simultaneously:

1. **Email** (`alert-threshold-critical` template) with full context
2. **In-app overlay** (full-screen, non-dismissible, already wired in `mebusan_app.html`)
3. **Automated phone call** via Twilio Programmable Voice

Trigger all three from your signal-processing code:

```php
// 1. Email
POST /emails/send.php { action: 'send_now', email: {
    to: client.email, template: 'alert-threshold-critical',
    vars: { jurisdiction, headline, observation, implication, confidence, falsification,
            analyst_name, alert_id, triggered_at, threshold_name, call_status: 'queued' }
}}

// 2. Phone call
POST /api/alert-call.php { 
    phone: client.phone_e164, client_id, alert_id, jurisdiction, headline,
    analyst_phone: '+...', client_name
}

// 3. In-app overlay fires automatically via push notification payload
//    with { type: 'critical', ...payload } — or via polling /api/alerts-for-me
```

The in-app overlay cannot be dismissed without one of three actions:
- **Open full briefing** — navigates to briefing view
- **Request analyst callback** — sends SMS to on-call analyst
- **Acknowledge only** — records ack without further action

Acknowledgement in the app stops escalation. If the phone call is not answered or acknowledged within 30 seconds, and the in-app overlay is not acknowledged within 90 seconds, the alert is automatically escalated to your on-call analyst.

---

## 9. Testing

Before going live, use dry-run mode:

```bash
php -r "require 'website/emails/lib/mailer.php';
\$m = new MebusanMailer();
print_r(\$m->send([
  'to' => 'your@test.com',
  'template' => 'welcome-01-immediate',
  'vars' => ['name' => 'Test', 'tier' => 'Advisory', 'confirmation_id' => 'TEST-001'],
  'attach_pdf' => 'welcome-pack',
  'dry_run' => true,
]));"
```

Then send to a real inbox via [mail-tester.com](https://mail-tester.com):
```bash
php -r "... 'to' => '<the mail-tester.com address>' ..."
```

Target score: **10/10**. Anything below 9 means a DNS record is wrong.

---

## 10. Inbox landing checklist

Before first production campaign, verify:

- [ ] SPF record published and resolves
- [ ] DKIM records published and resolve (check with `dig CNAME`)
- [ ] DMARC record published with `rua` reporting address
- [ ] From domain verified in provider dashboard
- [ ] Test send to Gmail lands in **Primary** tab (not Promotions)
- [ ] Test send to Outlook.com does not go to Junk
- [ ] Test send to Yahoo does not go to Spam
- [ ] mail-tester.com score ≥ 9/10
- [ ] HD logo renders inline in all three clients
- [ ] PDF attachment downloads and opens correctly
- [ ] Unsubscribe link works (both GET UI and one-click POST)
- [ ] Text-only version renders readably

---

## 11. What the system does NOT do (by design)

- No tracking pixels. Opens are not tracked.
- No link-click tracking. Clicks are not tracked.
- No A/B testing infrastructure. Not our business.
- No marketing automation. The welcome sequence is the entire lifecycle.
- No retention pressure. Cancellation confirmations do not try to win anyone back.

These are deliberate. They reflect Mebusan's position on client relations.

---

## 12. Templates inventory

**Lifecycle (7):** welcome-01-immediate, welcome-02-primer, welcome-03-analyst, welcome-04-first-briefing, welcome-05-security, welcome-06-first-week, welcome-07-two-weeks

**Billing (5):** billing-invoice-paid, billing-card-expiring, billing-payment-failed, billing-plan-change, billing-subscription-cancelled

**Alerts (4):** alert-threshold-critical, alert-threshold-amber, alert-posture-change, briefing-weekly

**Transactional (2):** verify-otp, security-login-new-device

**Analyst (3):** analyst-reply, quarterly-review-invitation, canary-renewed

**PDF generators (5):** welcome-pack, methodology, security-guide, briefing-template, invoice

---

*Mebusan AI PTE LTD · Singapore · mebusan.com*
