<?php
/**
 * MEBUSAN · Email send endpoint
 * ─────────────────────────────────────────────────────────────────
 * POST /emails/send.php
 *
 * Called by the site's signup/payment flow to:
 *   - Send a single email immediately, OR
 *   - Schedule the full welcome sequence for a new subscriber
 *
 * Auth: simple shared-secret via ?key= or X-Mebusan-Key header
 *       (matches env MEBUSAN_INTERNAL_KEY)
 *
 * Payload examples:
 *   { "action": "schedule_welcome", "recipient": {...} }
 *   { "action": "send_now", "email": {...} }
 */

declare(strict_types=1);

header('Content-Type: application/json');
require_once __DIR__ . '/lib/mailer.php';
require_once __DIR__ . '/queue.php';

// Auth
$expected = getenv('MEBUSAN_INTERNAL_KEY') ?: '';
$provided = $_GET['key']
    ?? ($_SERVER['HTTP_X_MEBUSAN_KEY'] ?? '');
if ($expected && $provided !== $expected) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

$raw = file_get_contents('php://input') ?: '';
$body = json_decode($raw, true) ?: [];
$action = $body['action'] ?? '';

try {
    if ($action === 'schedule_welcome') {
        $recipient = $body['recipient'] ?? [];
        if (empty($recipient['email'])) {
            http_response_code(400);
            echo json_encode(['error' => 'recipient.email required']);
            exit;
        }
        $queue = new EmailQueue();
        $queue->scheduleWelcome($recipient);
        echo json_encode(['success' => true, 'scheduled' => 7]);
    }
    elseif ($action === 'send_now') {
        $email = $body['email'] ?? [];
        if (empty($email['to']) || empty($email['template'])) {
            http_response_code(400);
            echo json_encode(['error' => 'email.to and email.template required']);
            exit;
        }
        $mailer = new MebusanMailer();
        echo json_encode($mailer->send($email));
    }
    else {
        http_response_code(400);
        echo json_encode(['error' => 'unknown action']);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
