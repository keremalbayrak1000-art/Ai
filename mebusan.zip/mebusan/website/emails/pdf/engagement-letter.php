<?php
/**
 * PDF: Mebusan engagement letter
 *
 * Produces a 5-page engagement letter. If signature data is provided in
 * $vars['signature'], appends a signed attestation page (page 6) with:
 *   - Vector signature (drawn) or typed name
 *   - Timestamp (UTC)
 *   - Masked IP
 *   - Document ID
 *   - SHA-256 of the unsigned document (anchors the signature)
 *
 * Returns ['filename' => str, 'content' => bytes].
 *
 * Signature payload shape:
 *   $vars['signature'] = [
 *     'method'       => 'drawn' | 'typed',
 *     'strokes'      => [[{x,y,p},...],...]   (if drawn)
 *     'canvas_w'     => 520,                  (if drawn)
 *     'canvas_h'     => 180,                  (if drawn)
 *     'typed_name'   => 'M. Ahmadi',          (if typed)
 *     'signed_at'    => '2026-04-22T09:32:14Z',
 *     'ip_masked'    => '185.27.•.••',
 *     'document_id'  => 'MBSN-SIGN-...',
 *     'base_hash'    => 'sha256 of unsigned version',
 *   ]
 */

require_once __DIR__ . '/../lib/pdf-signature.php';

return function(array $vars): array {
    $name           = $vars['name']            ?? 'Principal';
    $nameSlug       = $vars['name_slug']       ?? 'engagement-letter';
    $tier           = $vars['tier']            ?? 'Advisory';
    $confirmationId = $vars['confirmation_id'] ?? 'MBSN-0000';
    $signature      = $vars['signature']       ?? null;
    $documentId     = $signature['document_id'] ?? ('MBSN-DOC-' . strtoupper(bin2hex(random_bytes(4))));

    $pdf = new MebusanSignaturePDF(
        'Mebusan engagement letter · ' . $name,
        'Private intelligence engagement'
    );

    // ═══ Page 1 · Cover ═══
    $pdf->addPage();
    $pdf->setStrokeColor(0.6, 0.58, 0.52);
    $pdf->rule(56, 56, 540, 56, 0.3);

    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, 'Mebusan AI PTE LTD · Singapore · confidential', 6.5, 1.8);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 48);
    $pdf->text(56, 320, 'Engagement');
    $pdf->text(56, 372, 'letter.');

    $pdf->setFillColor(0.54, 0.52, 0.46);
    $pdf->setFont('helvetica', '', 13);
    $pdf->text(56, 420, 'Between Mebusan AI PTE LTD');
    $pdf->text(56, 440, 'and ' . $name);

    $pdf->rule(56, 490, 300, 490, 0.3);
    $pdf->setFont('courier', '', 10);
    $pdf->text(56, 515, 'DOCUMENT ' . $documentId);
    $pdf->text(56, 532, 'CONFIRMATION ' . $confirmationId);
    $pdf->text(56, 549, 'TIER ' . strtoupper($tier));

    $pdf->rule(56, 780, 540, 780, 0.3);
    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'For signature · please review and sign', 6.5, 1.6);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(440, 798, 'mebusan.com');

    // ═══ Page 2 · The engagement ═══
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '01 · The engagement', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 28);
    $pdf->text(56, 145, 'What we agree to do.');

    $pdf->setFont('helvetica', '', 11);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $pdf->paragraph(56, 200, 460,
        "Mebusan AI PTE LTD (\"Mebusan\", \"we\") agrees to provide " . $tier . "-tier " .
        "private intelligence services to " . $name . " (\"you\", \"principal\") on the terms below.\n\n" .
        "Services comprise: weekly intelligence briefings, event-triggered alerts on your configured " .
        "coverage, a named analyst relationship, and access to your in-app portal. Exact coverage limits, " .
        "response commitments, and cadence match those stated in the Mebusan " . $tier . "-tier specification " .
        "at the time of this signature, preserved in your file.\n\n" .
        "This is an information-only service. We do not give legal, tax, investment, or regulatory advice, " .
        "we do not act as a broker, agent, or fiduciary on your behalf, and we do not take commissions on " .
        "any product referenced in a briefing.\n\n" .
        "Your subscription is on a rolling monthly or annual basis, payable in advance. Renewal is automatic " .
        "unless cancelled. Cancellation ends billing; coverage continues to the end of the current period."
    );

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Engagement letter · page 02 of 5', 6, 1.4);

    // ═══ Page 3 · Confidentiality ═══
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '02 · Confidentiality', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 28);
    $pdf->text(56, 145, 'What stays private.');

    $pdf->setFont('helvetica', '', 11);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $pdf->paragraph(56, 200, 460,
        "Both parties undertake to treat all communications under this engagement as confidential.\n\n" .
        "On our side: your identity, your coverage preferences, your watchpoints, your message history, " .
        "and anything you share with an analyst is stored encrypted at rest, accessed only by the analyst " .
        "assigned to your file and named members of the Mebusan desk. We do not share your data with third " .
        "parties. We do not use your data to train AI models. We do not sell aggregate analytics.\n\n" .
        "On your side: you undertake not to republish, forward, or redistribute Mebusan briefings or alerts " .
        "to parties outside your immediate advisory circle without written permission. This is not because " .
        "the material is proprietary by default — it is because our methodology depends on controlled " .
        "distribution to remain predictive.\n\n" .
        "We issue a public warrant canary every quarter. If it fails to renew on schedule, assume compromise " .
        "and act accordingly. The canary is signed with a published PGP key."
    );

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Engagement letter · page 03 of 5', 6, 1.4);

    // ═══ Page 4 · Data & jurisdiction ═══
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '03 · Data and jurisdiction', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 28);
    $pdf->text(56, 145, 'Where your file sits.');

    $pdf->setFont('helvetica', '', 11);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $pdf->paragraph(56, 200, 460,
        "This agreement is governed by Singapore law. Disputes are to be resolved by arbitration in " .
        "Singapore under SIAC rules.\n\n" .
        "Your data is stored on servers located in Singapore and, for redundancy, Frankfurt. We do not " .
        "store any data on servers in jurisdictions where we cannot legally honour confidentiality " .
        "obligations to you. If our assessment of a hosting jurisdiction changes, we will migrate and " .
        "inform you before routing your next briefing through the new location.\n\n" .
        "You may request full export or deletion of your file at any time by emailing privacy@mebusan.com. " .
        "Export is delivered within 14 days. Deletion is completed within 30 days, with one final " .
        "confirmation notice.\n\n" .
        "Mebusan may disclose your information only where compelled by a court order in Singapore. " .
        "Any such order triggers a failure of the warrant canary at the next quarterly publication."
    );

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Engagement letter · page 04 of 5', 6, 1.4);

    // ═══ Page 5 · Commitments, limits, termination ═══
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '04 · Limits and termination', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 28);
    $pdf->text(56, 145, 'What we are liable for.');

    $pdf->setFont('helvetica', '', 11);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $pdf->paragraph(56, 200, 460,
        "Mebusan undertakes to exercise reasonable professional care in preparing every item of " .
        "intelligence we deliver, to disclose the confidence level on every material claim, and to " .
        "publish corrections unprompted when we are wrong.\n\n" .
        "Our liability to you under this engagement is capped at the fees paid by you to Mebusan in " .
        "the twelve months preceding any claim. We are not liable for consequential, indirect, or " .
        "speculative losses arising from decisions you take in reliance on our work. You acknowledge " .
        "that intelligence, by nature, carries uncertainty, and that your decisions remain yours.\n\n" .
        "Either party may terminate this engagement on notice. If you terminate, coverage continues to " .
        "the end of your current billing period and there is no refund for the unused portion. If we " .
        "terminate, we refund the unused portion pro-rata and deliver a transition note.\n\n" .
        "We reserve the right to decline service or terminate immediately if continued engagement " .
        "would cause us to breach applicable law or our own published editorial standards."
    );

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Engagement letter · page 05 of 5', 6, 1.4);

    // ═══ Page 6 · Signature page (always present; shows "UNSIGNED" if not yet signed) ═══
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '05 · Signature', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 28);
    $pdf->text(56, 145, $signature ? 'Signed.' : 'Signature required.');

    // Principal box
    $pdf->rule(56, 220, 280, 220, 0.3);
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 240, 'Principal', 7, 1.6);
    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', '', 13);
    $pdf->text(56, 262, $name);
    $pdf->setFont('courier', '', 9);
    $pdf->setFillColor(0.62, 0.6, 0.54);
    $pdf->text(56, 280, $confirmationId);

    // Mebusan box
    $pdf->rule(320, 220, 540, 220, 0.3);
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(320, 240, 'For Mebusan', 7, 1.6);
    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', '', 13);
    $pdf->text(320, 262, 'Kerem Albayrak');
    $pdf->setFont('courier', '', 9);
    $pdf->setFillColor(0.62, 0.6, 0.54);
    $pdf->text(320, 280, 'FOUNDER · DIRECTOR');

    // Signature panel
    $pdf->rule(56, 340, 540, 340, 0.3);
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 360, 'Principal signature', 7, 1.6);

    if ($signature) {
        if (($signature['method'] ?? '') === 'drawn'
            && !empty($signature['strokes'])
            && is_array($signature['strokes'])) {
            $pdf->drawStrokes(
                $signature['strokes'],
                60, 375, 420, 90,
                (float)($signature['canvas_w'] ?? 520),
                (float)($signature['canvas_h'] ?? 180),
                [0.05, 0.1, 0.3]
            );
        } elseif (($signature['method'] ?? '') === 'typed'
                  && !empty($signature['typed_name'])) {
            $pdf->drawTypedSignature($signature['typed_name'], 60, 420, 32, [0.05, 0.1, 0.3]);
        }

        $pdf->rule(56, 480, 540, 480, 0.3);

        // Attestation
        $pdf->setFillColor(0.6, 0.58, 0.52);
        $pdf->label(56, 500, 'Signed at · ' . ($signature['signed_at'] ?? '—'), 7, 1.4);
        $pdf->label(56, 518, 'Method · ' . strtoupper($signature['method'] ?? '—'), 7, 1.4);
        $pdf->label(56, 536, 'IP · ' . ($signature['ip_masked'] ?? '—'), 7, 1.4);
        $pdf->label(56, 554, 'Document ID · ' . $documentId, 7, 1.4);
        if (!empty($signature['base_hash'])) {
            $pdf->label(56, 572, 'Base hash · ' . substr($signature['base_hash'], 0, 32), 6, 1.2);
            $pdf->label(56, 586, '           · ' . substr($signature['base_hash'], 32), 6, 1.2);
        }

        // Attestation text
        $pdf->setFont('helvetica', '', 10);
        $pdf->setFillColor(0.75, 0.72, 0.64);
        $pdf->paragraph(56, 620, 460,
            "By signing above, " . $name . " confirms having read and agreed to this engagement letter in its " .
            "entirety. This attestation is recorded with timestamp, device metadata, and document hash. " .
            "A full record is retained in the Mebusan audit log."
        );

    } else {
        // Unsigned placeholder
        $pdf->rect(56, 380, 484, 100, false);
        $pdf->setFont('helvetica', 'I', 11);
        $pdf->setFillColor(0.5, 0.48, 0.42);
        $pdf->text(210, 432, 'Signature panel — sign online at mebusan.com/sign');
        $pdf->rule(56, 500, 540, 500, 0.3);
        $pdf->setFont('helvetica', '', 10);
        $pdf->setFillColor(0.62, 0.6, 0.54);
        $pdf->paragraph(56, 520, 460,
            "This copy is provided for your review. Please complete signature at the secure link " .
            "delivered to your email. A countersigned copy will be emailed to you on completion."
        );
    }

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Engagement letter · signature page · ' . ($signature ? 'SIGNED' : 'UNSIGNED'), 6, 1.4);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(440, 798, 'mebusan.com');

    return [
        'filename' => 'mebusan-engagement-' . preg_replace('/[^a-z0-9-]/i', '-', strtolower($nameSlug))
                    . ($signature ? '-signed' : '') . '.pdf',
        'content'  => $pdf->output(),
    ];
};
