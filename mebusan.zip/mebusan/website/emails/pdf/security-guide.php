<?php
/** PDF: Mebusan security setup (4 pages) */
require_once __DIR__ . '/../lib/pdf.php';

return function(array $vars): array {
    $pdf = new MinPDF('Mebusan security setup', 'Secure channels and emergency codes');

    $sections = [
        ['Before anything urgent',
         "You will receive routine briefings by email. For anything urgent, we use a secure channel. This guide explains how to set it up, and how to keep it secure. Ten minutes, one time."],
        ['Signal · preferred for urgent',
         "Install Signal from the official app store. Do not use any fork or unofficial build. Once installed, your analyst will send you a pairing code by encrypted email, valid for 90 minutes. Confirm the safety number verbally on your first call with the analyst — this binds the channel to a specific device and person."],
        ['Two-factor authentication',
         "Required for Private, strongly recommended for Advisory. Use a TOTP app (Aegis on Android, Raivo or 2FAS on iOS). Never SMS-based 2FA; it is vulnerable to SIM-swap attacks. Your recovery key is delivered on first login under Settings → Security. Keep it offline."],
        ['Emergency support code',
         "A unique six-character code tied to you personally. Used to verify identity when contacting analysts by phone. Never share it in any channel — including this one. If anyone asks for it, the request is illegitimate by definition. We will never ask you for the full code; only the last two characters, and only during a call you initiated."],
    ];

    foreach ($sections as $i => [$heading, $body]) {
        $pdf->addPage();
        $pdf->setStrokeColor(0.6, 0.58, 0.52);
        $pdf->setFillColor(0.6, 0.58, 0.52);
        $pdf->label(56, 80, sprintf('%02d · Security', $i + 1), 7, 1.6);
        $pdf->rule(56, 90, 540, 90, 0.3);

        $pdf->setFillColor(0.91, 0.89, 0.83);
        $pdf->setFont('helvetica', 'L', 28);
        $pdf->text(56, 145, $heading);

        $pdf->setFont('helvetica', '', 11);
        $pdf->setFillColor(0.75, 0.72, 0.64);
        $pdf->paragraph(56, 205, 460, $body);

        $pdf->setFont('helvetica', '', 8);
        $pdf->label(56, 798, sprintf('Mebusan security · %d of %d', $i + 1, count($sections)), 6, 1.4);
        $pdf->setFillColor(0.42, 0.40, 0.36);
        $pdf->text(480, 798, 'keep offline');
    }

    return ['filename' => 'mebusan-security-setup.pdf', 'content' => $pdf->output()];
};
