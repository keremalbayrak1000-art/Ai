<?php
/**
 * PDF generator: welcome-pack
 * Produces a 6-page Mebusan welcome pack for new clients.
 * Returns ['filename' => str, 'content' => bytes].
 */

require_once __DIR__ . '/../lib/pdf.php';

return function(array $vars): array {
    $name           = $vars['name']           ?? 'Principal';
    $nameSlug       = $vars['name_slug']      ?? 'welcome-pack';
    $tier           = $vars['tier']           ?? 'Advisory';
    $confirmationId = $vars['confirmation_id'] ?? 'MBSN-0000';
    $firstBriefing  = $vars['first_briefing_date'] ?? 'Monday, 28 April';
    $responseWin    = $vars['response_window']     ?? '24 hours';
    $coverage       = $vars['coverage_summary']    ?? 'Your configured jurisdictions';
    $analyst        = $vars['analyst_name']        ?? 'being assigned';

    $pdf = new MinPDF('Mebusan welcome pack for ' . $name, 'Private intelligence · Mebusan AI PTE LTD');

    // ═══ Page 1 · Cover ═══
    $pdf->addPage();
    $pdf->setStrokeColor(0.6, 0.58, 0.52);
    $pdf->rule(56, 56, 540, 56, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 7);
    $pdf->label(56, 80, 'Mebusan AI PTE LTD', 6.5, 1.8);

    $pdf->setFont('helvetica', 'L', 54);
    $pdf->text(56, 420, 'MEBUSAN');

    $pdf->setFillColor(0.54, 0.52, 0.46);
    $pdf->setFont('helvetica', '', 14);
    $pdf->text(56, 460, 'Private intelligence for wealth');
    $pdf->text(56, 482, 'that crosses borders.');

    $pdf->rule(56, 560, 250, 560, 0.3);
    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', '', 10);
    $pdf->text(56, 585, 'Welcome pack');
    $pdf->setFillColor(0.54, 0.52, 0.46);
    $pdf->setFont('helvetica', '', 9);
    $pdf->text(56, 605, 'Prepared for ' . $name);
    $pdf->text(56, 622, 'Confirmation ' . $confirmationId);

    $pdf->rule(56, 780, 540, 780, 0.3);
    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Confidential · for principal only', 6.5, 1.6);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(380, 798, 'Singapore · mebusan.com');

    // ═══ Page 2 · What this is ═══
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '01 · What this is', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 28);
    $pdf->text(56, 145, 'Your file is open.');

    $pdf->setFont('helvetica', '', 11);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $pdf->paragraph(56, 200, 460,
        "This document explains how we operate, what you will receive from Mebusan in the normal run of " .
        "things, and what we expect from you. It is deliberately short. If you read only one document from " .
        "us, read this one.\n\n" .
        "Mebusan is private intelligence for cross-border wealth. We are not a news service, a compliance " .
        "vendor, or a bank. We exist because the information that matters to principals with internationally " .
        "structured wealth does not travel through normal channels, and when it does, it is already too late.\n\n" .
        "Your tier is " . $tier . ". That carries a specific response commitment (" . $responseWin . "), " .
        "a specific cadence (weekly briefing with event-triggered inserts), and a specific analyst relationship " .
        "(" . $analyst . "). Those three things are the contract. Nothing else is."
    );

    $pdf->rule(56, 570, 540, 570, 0.3);
    $pdf->setFont('helvetica', '', 9);
    $pdf->label(56, 595, 'The rhythm from here', 7, 1.6);

    $pdf->setFont('helvetica', '', 10);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $pdf->paragraph(56, 620, 460,
        "One short note per day this week: methodology primer, a word from your analyst, a preview of " .
        "your first briefing, security setup. After that, weekly briefing only, plus anything threshold-triggered."
    );

    $pdf->rule(56, 780, 540, 780, 0.3);
    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Page 02 · Mebusan welcome pack', 6, 1.4);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(480, 798, 'mebusan.com');

    // ═══ Page 3 · How we operate ═══
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '02 · How we operate', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 24);
    $pdf->text(56, 140, 'Every claim is falsifiable.');

    $pdf->setFont('helvetica', '', 11);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $pdf->paragraph(56, 185, 460,
        "Everything you receive from us carries three things: a confidence score (1–5), a named falsification " .
        "path, and a source posture (open, signal, or human).\n\n" .
        "Confidence 1 is a rumour worth tracking. Confidence 5 is public, verified, and cross-sourced. " .
        "Most of what we send you will live at 3 or 4. We will tell you exactly what would move a call from " .
        "4 to 5, or from 4 to 2.\n\n" .
        "Named falsification is not a hedge. It is a commitment. If we say a jurisdictional posture is " .
        "changing, we will tell you the specific observation that would prove us wrong. If that observation " .
        "lands, we say so in your next briefing — unprompted.\n\n" .
        "Human sources are always weighted down one full confidence level relative to their operator's claim. " .
        "This costs us some signal. We accept that cost."
    );

    $pdf->setFont('helvetica', '', 9);
    $pdf->label(56, 570, 'What we do not do', 7, 1.6);
    $pdf->setFont('helvetica', '', 10);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $pdf->paragraph(56, 595, 460,
        "We do not give legal, tax, or investment advice. We do not make predictions; we track postures. " .
        "We do not sell your data. We do not publish anything with your name on it. We do not take commissions " .
        "on anything we reference."
    );

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Page 03 · Mebusan welcome pack', 6, 1.4);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(480, 798, 'mebusan.com');

    // ═══ Page 4 · What you will receive ═══
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '03 · What you will receive', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 24);
    $pdf->text(56, 140, 'On your rhythm.');

    $items = [
        ['Weekly briefing · Monday 09:00',
         'Every jurisdiction on your coverage. Five sections: postures, threshold events, 90-day pipeline, action items, corrections. Attached as PDF, also in-app.'],
        ['Event-triggered inserts',
         'Anything that crosses a named threshold between briefings arrives within your response-window commitment. Amber for awareness; critical triggers a phone call.'],
        ['Monthly summary · first Monday',
         'Higher-level posture summary plus corrections and methodology updates. Explicitly short.'],
        ['Quarterly review · Private tier',
         'Structured one-hour call. We invite you fourteen days before each quarter end. Optional.'],
        ['Warrant canary · quarterly',
         'Public, signed, on the site. Auto-linked in the footer of every briefing.'],
    ];

    $y = 190;
    foreach ($items as [$h, $b]) {
        $pdf->setFont('helvetica', 'B', 11);
        $pdf->setFillColor(0.91, 0.89, 0.83);
        $pdf->text(56, $y, $h);
        $pdf->setFont('helvetica', '', 10);
        $pdf->setFillColor(0.65, 0.62, 0.56);
        $pdf->paragraph(56, $y + 18, 460, $b, 14);
        $pdf->rule(56, $y + 68, 540, $y + 68, 0.2);
        $y += 90;
    }

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Page 04 · Mebusan welcome pack', 6, 1.4);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(480, 798, 'mebusan.com');

    // ═══ Page 5 · What we expect from you ═══
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '04 · What we expect from you', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 24);
    $pdf->text(56, 140, 'Specifics, not noise.');

    $pdf->setFont('helvetica', '', 11);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $pdf->paragraph(56, 185, 460,
        "Mebusan is useful in proportion to how specific you are with us.\n\n" .
        "Tell us what actually matters. Not your portfolio. Not your background. The three or four things " .
        "that, if they moved tomorrow, would keep you up tonight. That is what we want to watch.\n\n" .
        "Correct us early. If your first briefing felt generic, that is a calibration signal. Tell your " .
        "analyst within the week and we narrow your coverage. If you feel something was too tentatively " .
        "stated, say so. We will sharpen the call.\n\n" .
        "Keep your secure channel active. Signal is strongly preferred for Advisory, required for Private. " .
        "Pair it with your analyst in the first week so the channel is warm before you ever actually need it.\n\n" .
        "Do not share your emergency support code. Ever. If anyone asks for it, the request is illegitimate " .
        "by definition, including any message claiming to be from us."
    );

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Page 05 · Mebusan welcome pack', 6, 1.4);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(480, 798, 'mebusan.com');

    // ═══ Page 6 · Your details (personalised) ═══
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '05 · Your file', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 24);
    $pdf->text(56, 140, 'Your specifics.');

    // Detail rows in monospace
    $rows = [
        ['Principal',            $name],
        ['Confirmation',         $confirmationId],
        ['Tier',                 $tier],
        ['Coverage',             $coverage],
        ['Analyst',              $analyst],
        ['Response commitment',  $responseWin],
        ['First briefing',       $firstBriefing],
        ['Secure channel',       'Signal · pair in week one'],
        ['Emergency code',       'In-app · Settings → Security'],
        ['Warrant canary',       'mebusan.com/warrant-canary.html'],
        ['Signed',               'Kerem Albayrak, founder'],
    ];

    $y = 200;
    foreach ($rows as [$k, $v]) {
        $pdf->setFont('courier', '', 8.5);
        $pdf->setFillColor(0.55, 0.52, 0.46);
        $pdf->text(56, $y, strtoupper($k));
        $pdf->setFont('helvetica', '', 11);
        $pdf->setFillColor(0.91, 0.89, 0.83);
        $pdf->text(220, $y, $v);
        $pdf->rule(56, $y + 10, 540, $y + 10, 0.2);
        $y += 28;
    }

    $pdf->rule(56, 740, 540, 740, 0.3);
    $pdf->setFont('helvetica', '', 9);
    $pdf->setFillColor(0.65, 0.62, 0.56);
    $pdf->paragraph(56, 760, 460,
        "Mebusan AI PTE LTD · Singapore · mebusan.com · desk@mebusan.com"
    );
    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Page 06 · Mebusan welcome pack', 6, 1.4);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(480, 798, 'confidential');

    return [
        'filename' => 'mebusan-welcome-' . preg_replace('/[^a-z0-9-]/i', '-', strtolower($nameSlug)) . '.pdf',
        'content'  => $pdf->output(),
    ];
};
