<?php
/**
 * PDF: Mebusan weekly briefing
 * Takes a briefing payload (postures, threshold events, pipeline, actions, corrections)
 * and renders it with the Mebusan five-section layout.
 */
require_once __DIR__ . '/../lib/pdf.php';

return function(array $vars): array {
    $weekOf    = $vars['week_of']    ?? date('j M Y');
    $name      = $vars['name']       ?? 'Principal';
    $analyst   = $vars['analyst_name'] ?? 'Mebusan desk';
    $postures  = $vars['postures']   ?? [
        ['Turkey', 'Watch → Elevated', 'Two correspondent banks reduced USD exposure over six weeks. CBRT holding rate despite inflation print.'],
        ['UAE', 'Stable', 'BO disclosure deadline 30 days out; most clients already compliant.'],
        ['Switzerland', 'Stable', 'Lex Koller review opened; cantons have quarter-end to submit positions.'],
    ];
    $thresholds = $vars['thresholds'] ?? [
        ['Turkey · correspondent-bank tightening', 'Confidence 4/5', 'Amber'],
        ['UAE · ADGM BO consultation window', 'Confidence 5/5', 'Green'],
    ];
    $pipeline = $vars['pipeline']   ?? [
        ['Singapore · MAS 13O consultation close', '9 days'],
        ['UK · non-dom transitional election', '14 days'],
        ['EU · sanctions package Friday', '3 days'],
    ];
    $actions  = $vars['actions']    ?? [
        'Review UAE-held structures for current BO filing.',
        'Confirm correspondent-bank posture on two USD corridors into Turkey.',
    ];
    $corrections = $vars['corrections'] ?? ['None this week.'];

    $pdf = new MinPDF('Mebusan briefing · ' . $weekOf, 'Weekly intelligence briefing');

    // Cover
    $pdf->addPage();
    $pdf->setStrokeColor(0.6, 0.58, 0.52);
    $pdf->rule(56, 56, 540, 56, 0.3);
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, 'Mebusan AI PTE LTD · Confidential', 6.5, 1.8);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 44);
    $pdf->text(56, 260, 'Weekly');
    $pdf->text(56, 310, 'briefing.');

    $pdf->setFillColor(0.54, 0.52, 0.46);
    $pdf->setFont('helvetica', '', 13);
    $pdf->text(56, 360, 'Week of ' . $weekOf);
    $pdf->text(56, 385, 'Prepared for ' . $name);
    $pdf->text(56, 410, 'Analyst ' . $analyst);

    $pdf->rule(56, 780, 540, 780, 0.3);
    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Five sections · five minutes', 6.5, 1.6);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(480, 798, 'mebusan.com');

    // Section 1 · Postures
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '01 · Postures', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 26);
    $pdf->text(56, 140, 'Where we stand.');

    $y = 210;
    foreach ($postures as [$jur, $state, $note]) {
        $pdf->setFont('helvetica', 'B', 12);
        $pdf->setFillColor(0.91, 0.89, 0.83);
        $pdf->text(56, $y, $jur);
        $pdf->setFont('courier', '', 9);
        $pdf->setFillColor(0.78, 0.62, 0.23); // amber-ish
        $pdf->text(280, $y, $state);
        $pdf->setFont('helvetica', '', 10);
        $pdf->setFillColor(0.65, 0.62, 0.56);
        $pdf->paragraph(56, $y + 18, 460, $note, 13);
        $pdf->rule(56, $y + 58, 540, $y + 58, 0.2);
        $y += 80;
        if ($y > 720) break;
    }

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Briefing · page 02', 6, 1.4);

    // Section 2 · Threshold events
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '02 · Threshold events', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 26);
    $pdf->text(56, 140, 'Crossed this week.');

    $y = 210;
    foreach ($thresholds as [$title, $conf, $bar]) {
        $pdf->setFont('helvetica', 'B', 12);
        $pdf->setFillColor(0.91, 0.89, 0.83);
        $pdf->text(56, $y, $title);
        $pdf->setFont('courier', '', 9);
        $pdf->setFillColor(0.62, 0.6, 0.54);
        $pdf->text(56, $y + 18, $conf . '  ·  ' . $bar);
        $pdf->rule(56, $y + 40, 540, $y + 40, 0.2);
        $y += 60;
        if ($y > 720) break;
    }

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Briefing · page 03', 6, 1.4);

    // Section 3 · 90-day pipeline
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '03 · 90-day pipeline', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 26);
    $pdf->text(56, 140, 'Scheduled, not predicted.');

    $y = 210;
    foreach ($pipeline as [$item, $when]) {
        $pdf->setFont('helvetica', '', 11);
        $pdf->setFillColor(0.91, 0.89, 0.83);
        $pdf->text(56, $y, $item);
        $pdf->setFont('courier', '', 9);
        $pdf->setFillColor(0.62, 0.6, 0.54);
        $pdf->text(430, $y, strtoupper($when));
        $pdf->rule(56, $y + 15, 540, $y + 15, 0.2);
        $y += 34;
        if ($y > 720) break;
    }

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Briefing · page 04', 6, 1.4);

    // Section 4 · Action items
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '04 · Action items', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 26);
    $pdf->text(56, 140, 'Specific, or we say nothing.');

    $pdf->setFont('helvetica', '', 11);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $y = 210;
    foreach ($actions as $act) {
        $pdf->text(56, $y, '·');
        $pdf->paragraph(80, $y, 440, $act, 14);
        $y += 38;
    }

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Briefing · page 05', 6, 1.4);

    // Section 5 · Corrections
    $pdf->addPage();
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 80, '05 · Corrections', 7, 1.6);
    $pdf->rule(56, 90, 540, 90, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 26);
    $pdf->text(56, 140, 'What we got wrong.');

    $pdf->setFont('helvetica', '', 11);
    $pdf->setFillColor(0.75, 0.72, 0.64);
    $y = 210;
    foreach ($corrections as $c) {
        $pdf->paragraph(56, $y, 460, $c);
        $y += 60;
    }

    $pdf->rule(56, 720, 540, 720, 0.3);
    $pdf->setFont('helvetica', '', 9);
    $pdf->setFillColor(0.65, 0.62, 0.56);
    $pdf->paragraph(56, 745, 460, 'Signed by ' . $analyst . ' on behalf of the desk. Reply to the email you received with this briefing to reach your analyst directly.');

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Briefing · page 06 · end', 6, 1.4);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(480, 798, 'confidential');

    return [
        'filename' => 'mebusan-briefing-' . preg_replace('/[^a-z0-9]+/i', '-', strtolower($weekOf)) . '.pdf',
        'content'  => $pdf->output(),
    ];
};
