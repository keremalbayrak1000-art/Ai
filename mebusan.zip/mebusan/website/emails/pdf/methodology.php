<?php
/** PDF: Mebusan methodology reference (8 pages) */
require_once __DIR__ . '/../lib/pdf.php';

return function(array $vars): array {
    $nameSlug = $vars['name_slug'] ?? 'methodology';
    $pdf = new MinPDF('Mebusan methodology', 'How we operate');

    $sections = [
        ['The contract',
         "Every claim we send you carries three things: a confidence score from 1 to 5, a named falsification path, and a source posture. This document explains how each is calibrated."],
        ['Confidence, 1 to 5',
         "One is a rumour worth tracking. Two is an unverified specific. Three is a plausible pattern. Four is cross-sourced with caveats. Five is public, verified, and corroborated. Most calls we send live at 3 or 4."],
        ['Falsification',
         "When we say a posture is changing, we name the specific observation that would prove us wrong. If that observation lands, we retract, unprompted, in your next briefing."],
        ['Sources · open, signal, human',
         "Open is verifiable public information. Signal is inferred from pattern observation across data series. Human is source-dependent and we weight it down one confidence level, always."],
        ['Thresholds',
         "Each jurisdiction has named thresholds that trigger alerts. These are not algorithmic; they are specified by our analysts. A threshold that never triggers is reviewed quarterly."],
        ['Corrections',
         "Corrections are a standing section in every briefing. Present even when empty. If it is empty two weeks in a row, we audit the callbook for missed ones."],
        ['What we do not do',
         "We do not make predictions. We track postures and pipelines. We do not give legal, tax, or investment advice. We do not take commissions. We do not publish anything bearing your name."],
        ['How to use this',
         "Read the confidence. If it is below 4, treat it as a watch-item, not a conclusion. Read the falsification path. That tells you what we are actually uncertain about. Read the source posture. Weight accordingly."],
    ];

    foreach ($sections as $i => [$heading, $body]) {
        $pdf->addPage();
        $pdf->setStrokeColor(0.6, 0.58, 0.52);
        $pdf->setFillColor(0.6, 0.58, 0.52);
        $pdf->label(56, 80, sprintf('%02d · Methodology', $i + 1), 7, 1.6);
        $pdf->rule(56, 90, 540, 90, 0.3);

        $pdf->setFillColor(0.91, 0.89, 0.83);
        $pdf->setFont('helvetica', 'L', 28);
        $pdf->text(56, 145, $heading);

        $pdf->setFont('helvetica', '', 11);
        $pdf->setFillColor(0.75, 0.72, 0.64);
        $pdf->paragraph(56, 205, 460, $body);

        $pdf->setFont('helvetica', '', 8);
        $pdf->label(56, 798, sprintf('Mebusan methodology · %d of %d', $i + 1, count($sections)), 6, 1.4);
        $pdf->setFillColor(0.42, 0.40, 0.36);
        $pdf->text(480, 798, 'mebusan.com');
    }

    return [
        'filename' => 'mebusan-methodology.pdf',
        'content'  => $pdf->output(),
    ];
};
