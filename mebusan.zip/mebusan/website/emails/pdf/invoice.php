<?php
/** PDF: Mebusan invoice/receipt */
require_once __DIR__ . '/../lib/pdf.php';

return function(array $vars): array {
    $invoiceId = $vars['invoice_id'] ?? 'MBSN-0000';
    $name      = $vars['name']       ?? 'Client';
    $tier      = $vars['tier']       ?? 'Advisory';
    $billing   = $vars['billing_cycle']  ?? 'Monthly';
    $amount    = $vars['amount']     ?? '$690.00';
    $period    = ($vars['period_start'] ?? '1 Apr 2026') . ' → ' . ($vars['period_end'] ?? '30 Apr 2026');
    $method    = $vars['payment_method'] ?? 'Card ending ••••';
    $issued    = $vars['issued_date']    ?? date('j M Y');

    $pdf = new MinPDF('Mebusan invoice ' . $invoiceId, 'Receipt · ' . $amount);

    $pdf->addPage();
    $pdf->setStrokeColor(0.6, 0.58, 0.52);

    // Top rule + company block
    $pdf->rule(56, 56, 540, 56, 0.3);
    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 7);
    $pdf->label(56, 80, 'Mebusan AI PTE LTD', 6.5, 1.8);
    $pdf->setFillColor(0.54, 0.52, 0.46);
    $pdf->setFont('helvetica', '', 9);
    $pdf->text(56, 102, 'Singapore · ACRA pending');
    $pdf->text(56, 118, 'desk@mebusan.com · mebusan.com');

    // Invoice heading
    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', 'L', 44);
    $pdf->text(56, 220, 'Invoice');
    $pdf->setFillColor(0.54, 0.52, 0.46);
    $pdf->setFont('courier', '', 11);
    $pdf->text(56, 250, $invoiceId);

    // Bill-to
    $pdf->rule(56, 290, 540, 290, 0.3);
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 310, 'Billed to', 7, 1.6);
    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', '', 13);
    $pdf->text(56, 332, $name);

    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(320, 310, 'Issued', 7, 1.6);
    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('courier', '', 11);
    $pdf->text(320, 332, $issued);

    // Line items table
    $pdf->rule(56, 380, 540, 380, 0.3);
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 400, 'Description', 7, 1.6);
    $pdf->label(430, 400, 'Amount', 7, 1.6);
    $pdf->rule(56, 420, 540, 420, 0.3);

    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', '', 12);
    $pdf->text(56, 445, 'Mebusan subscription · ' . $tier . ' · ' . $billing);
    $pdf->setFont('courier', '', 10);
    $pdf->setFillColor(0.62, 0.6, 0.54);
    $pdf->text(56, 464, strtoupper($period));

    $pdf->setFont('courier', '', 12);
    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->text(430, 445, $amount);

    $pdf->rule(56, 500, 540, 500, 0.3);

    // Total
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(320, 520, 'Total', 7, 1.6);
    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('courier', '', 18);
    $pdf->text(430, 530, $amount);

    // Paid via
    $pdf->rule(56, 580, 540, 580, 0.3);
    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(56, 600, 'Paid via', 7, 1.6);
    $pdf->setFillColor(0.91, 0.89, 0.83);
    $pdf->setFont('helvetica', '', 12);
    $pdf->text(56, 622, $method);

    $pdf->setFillColor(0.6, 0.58, 0.52);
    $pdf->label(320, 600, 'Status', 7, 1.6);
    $pdf->setFillColor(0.23, 0.48, 0.34); // green
    $pdf->setFont('helvetica', 'B', 12);
    $pdf->text(320, 622, 'PAID');

    // Footer
    $pdf->rule(56, 720, 540, 720, 0.3);
    $pdf->setFont('helvetica', '', 9);
    $pdf->setFillColor(0.62, 0.6, 0.54);
    $pdf->paragraph(56, 745, 460,
        "This document is the receipt for your Mebusan subscription payment. No further action required. " .
        "Coverage continues per the period above. Questions: reply to any email from us."
    );

    $pdf->setFont('helvetica', '', 8);
    $pdf->label(56, 798, 'Mebusan AI PTE LTD · Singapore', 6, 1.4);
    $pdf->setFillColor(0.42, 0.40, 0.36);
    $pdf->text(480, 798, 'mebusan.com');

    return [
        'filename' => 'mebusan-invoice-' . $invoiceId . '.pdf',
        'content'  => $pdf->output(),
    ];
};
