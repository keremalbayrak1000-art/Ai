<?php
/**
 * MEBUSAN · Mailer
 * ─────────────────────────────────────────────────────────────────
 * Unified email sender. Supports four providers via a single interface:
 *
 *   - resend     (recommended — modern API, good deliverability)
 *   - postmark   (excellent transactional deliverability)
 *   - sendgrid   (classic option)
 *   - smtp       (fallback — works on any host with PHP mail/SMTP access)
 *
 * Provider is chosen by the MEBUSAN_MAIL_PROVIDER env var. Credentials
 * come from matching env vars. A full setup guide sits in README-EMAIL.md.
 *
 * Deliverability hygiene (all providers):
 *   - DKIM/SPF/DMARC must be set up on mebusan.com (see setup guide)
 *   - List-Unsubscribe header (RFC 8058) included automatically
 *   - Text + HTML multipart bodies always
 *   - Consistent From / Reply-To / Return-Path
 *   - Sender Score-friendly: no link shorteners, no tracking pixels by default,
 *     HD logo embedded as CID attachment (not external URL)
 *
 * Usage:
 *   require 'emails/lib/mailer.php';
 *   $m = new MebusanMailer();
 *   $m->send([
 *     'to'         => 'client@example.com',
 *     'to_name'    => 'M. Ahmadi',
 *     'template'   => 'welcome-01-immediate',
 *     'vars'       => ['name' => 'M. Ahmadi', 'tier' => 'Advisory'],
 *     'attach_pdf' => 'welcome-pack',      // optional, generates on demand
 *     'category'   => 'lifecycle',          // tag for analytics
 *   ]);
 */

declare(strict_types=1);

class MebusanMailer
{
    private string $provider;
    private array  $creds;
    private string $fromEmail = 'desk@mebusan.com';
    private string $fromName  = 'Mebusan';
    private string $replyTo   = 'desk@mebusan.com';
    private string $rootDir;

    public function __construct(?array $config = null)
    {
        $this->rootDir = dirname(__DIR__, 2);
        $this->provider = $config['provider']
            ?? (getenv('MEBUSAN_MAIL_PROVIDER') ?: 'resend');
        $this->creds = [
            'resend'   => ['key' => getenv('RESEND_API_KEY') ?: ''],
            'postmark' => ['token' => getenv('POSTMARK_SERVER_TOKEN') ?: ''],
            'sendgrid' => ['key' => getenv('SENDGRID_API_KEY') ?: ''],
            'smtp'     => [
                'host'     => getenv('SMTP_HOST') ?: 'smtp.gmail.com',
                'port'     => (int)(getenv('SMTP_PORT') ?: 587),
                'user'     => getenv('SMTP_USER') ?: '',
                'pass'     => getenv('SMTP_PASS') ?: '',
                'encrypt'  => getenv('SMTP_ENCRYPTION') ?: 'tls',
            ],
        ];
    }

    /**
     * Send a single message.
     *
     * @param array $opts {
     *   @type string   $to          Recipient email (required)
     *   @type string   $to_name     Optional recipient display name
     *   @type string   $subject     Override the template's default subject
     *   @type string   $template    Template slug (e.g. 'welcome-01-immediate')
     *   @type array    $vars        Template variables
     *   @type string   $attach_pdf  PDF generator slug (optional)
     *   @type array    $attach_pdf_vars  Variables to pass to the PDF generator
     *   @type string   $category    Analytics tag (optional)
     *   @type string   $reply_to    Override default reply-to
     *   @type bool     $dry_run     If true, render but do not send (returns built message)
     * }
     * @return array { success: bool, id?: string, error?: string, dry_run?: array }
     */
    public function send(array $opts): array
    {
        if (empty($opts['to']) || !filter_var($opts['to'], FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'error' => 'invalid recipient'];
        }
        if (empty($opts['template'])) {
            return ['success' => false, 'error' => 'template required'];
        }

        // Render
        $rendered = $this->renderTemplate($opts['template'], $opts['vars'] ?? []);
        if (!$rendered) {
            return ['success' => false, 'error' => 'template not found: ' . $opts['template']];
        }

        $subject = $opts['subject'] ?? $rendered['subject'];
        $html    = $rendered['html'];
        $text    = $rendered['text'];

        // Attach PDF if requested
        $attachments = [];
        if (!empty($opts['attach_pdf'])) {
            $pdf = $this->generatePdf($opts['attach_pdf'], $opts['attach_pdf_vars'] ?? ($opts['vars'] ?? []));
            if ($pdf) {
                $attachments[] = [
                    'filename'    => $pdf['filename'],
                    'content'     => $pdf['content'],
                    'content_type' => 'application/pdf',
                ];
            }
        }
        // Attach a pre-built PDF blob (used when the generator has already been run, e.g. signed docs)
        if (!empty($opts['attach_raw_pdf']) && is_array($opts['attach_raw_pdf'])) {
            $raw = $opts['attach_raw_pdf'];
            if (!empty($raw['content']) && !empty($raw['filename'])) {
                $attachments[] = [
                    'filename'    => $raw['filename'],
                    'content'     => $raw['content'],
                    'content_type' => $raw['content_type'] ?? 'application/pdf',
                ];
            }
        }

        // Logo inline CID attachment (HD)
        $logoPath = $this->rootDir . '/website/emails/assets/logo-hd.png';
        $logoCid  = 'mebusan-logo';
        $inline   = [];
        if (is_readable($logoPath)) {
            $inline[] = [
                'cid'          => $logoCid,
                'filename'     => 'mebusan-logo.png',
                'content'      => file_get_contents($logoPath),
                'content_type' => 'image/png',
            ];
        }

        // List-Unsubscribe (RFC 8058) for Gmail/Outlook inbox-landing
        $unsubHash = hash_hmac('sha256', $opts['to'] . ($opts['template'] ?? ''), getenv('UNSUB_SECRET') ?: 'mebusan-unsub-2026');
        $unsubToken = urlencode($opts['to']) . '.' . substr($unsubHash, 0, 24);
        $unsubUrl   = 'https://mebusan.com/emails/unsubscribe.php?t=' . $unsubToken;

        $headers = [
            'List-Unsubscribe'      => '<mailto:unsubscribe@mebusan.com?subject=unsubscribe>, <' . $unsubUrl . '>',
            'List-Unsubscribe-Post' => 'List-Unsubscribe=One-Click',
            'X-Mebusan-Category'    => $opts['category'] ?? 'transactional',
            'X-Mebusan-Template'    => $opts['template'],
        ];

        $msg = [
            'from_email'  => $this->fromEmail,
            'from_name'   => $this->fromName,
            'to_email'    => $opts['to'],
            'to_name'     => $opts['to_name'] ?? '',
            'reply_to'    => $opts['reply_to'] ?? $this->replyTo,
            'subject'     => $subject,
            'html'        => $html,
            'text'        => $text,
            'attachments' => $attachments,
            'inline'      => $inline,
            'headers'     => $headers,
        ];

        if (!empty($opts['dry_run'])) {
            return ['success' => true, 'dry_run' => $msg];
        }

        // Log before send
        $this->logAttempt($msg);

        // Dispatch
        $result = $this->dispatch($msg);

        // Log result
        $this->logResult($msg, $result);

        return $result;
    }

    private function dispatch(array $msg): array
    {
        try {
            switch ($this->provider) {
                case 'resend':   return $this->sendResend($msg);
                case 'postmark': return $this->sendPostmark($msg);
                case 'sendgrid': return $this->sendSendgrid($msg);
                case 'smtp':     return $this->sendSmtp($msg);
                default:
                    return ['success' => false, 'error' => 'unknown provider: ' . $this->provider];
            }
        } catch (Throwable $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // ─── Provider: Resend ───────────────────────────────────────
    private function sendResend(array $msg): array
    {
        $key = $this->creds['resend']['key'];
        if (!$key) return ['success' => false, 'error' => 'RESEND_API_KEY missing'];

        $payload = [
            'from'     => $msg['from_name'] . ' <' . $msg['from_email'] . '>',
            'to'       => [$msg['to_email']],
            'subject'  => $msg['subject'],
            'html'     => $msg['html'],
            'text'     => $msg['text'],
            'reply_to' => $msg['reply_to'],
            'headers'  => $msg['headers'],
        ];
        $atts = [];
        foreach ($msg['attachments'] as $a) {
            $atts[] = [
                'filename'    => $a['filename'],
                'content'     => base64_encode($a['content']),
            ];
        }
        foreach ($msg['inline'] as $i) {
            $atts[] = [
                'filename'    => $i['filename'],
                'content'     => base64_encode($i['content']),
                'content_id'  => $i['cid'],
                'disposition' => 'inline',
            ];
        }
        if ($atts) $payload['attachments'] = $atts;

        return $this->httpPost('https://api.resend.com/emails', $payload, [
            'Authorization: Bearer ' . $key,
            'Content-Type: application/json',
        ]);
    }

    // ─── Provider: Postmark ─────────────────────────────────────
    private function sendPostmark(array $msg): array
    {
        $token = $this->creds['postmark']['token'];
        if (!$token) return ['success' => false, 'error' => 'POSTMARK_SERVER_TOKEN missing'];

        $atts = [];
        foreach ($msg['attachments'] as $a) {
            $atts[] = [
                'Name'        => $a['filename'],
                'Content'     => base64_encode($a['content']),
                'ContentType' => $a['content_type'] ?? 'application/octet-stream',
            ];
        }
        foreach ($msg['inline'] as $i) {
            $atts[] = [
                'Name'        => $i['filename'],
                'Content'     => base64_encode($i['content']),
                'ContentType' => $i['content_type'],
                'ContentID'   => 'cid:' . $i['cid'],
            ];
        }

        $h = [];
        foreach ($msg['headers'] as $k => $v) $h[] = ['Name' => $k, 'Value' => $v];

        $payload = [
            'From'        => $msg['from_name'] . ' <' . $msg['from_email'] . '>',
            'To'          => $msg['to_email'],
            'Subject'     => $msg['subject'],
            'HtmlBody'    => $msg['html'],
            'TextBody'    => $msg['text'],
            'ReplyTo'     => $msg['reply_to'],
            'MessageStream' => 'outbound',
            'Headers'     => $h,
        ];
        if ($atts) $payload['Attachments'] = $atts;

        return $this->httpPost('https://api.postmarkapp.com/email', $payload, [
            'Accept: application/json',
            'Content-Type: application/json',
            'X-Postmark-Server-Token: ' . $token,
        ]);
    }

    // ─── Provider: SendGrid ─────────────────────────────────────
    private function sendSendgrid(array $msg): array
    {
        $key = $this->creds['sendgrid']['key'];
        if (!$key) return ['success' => false, 'error' => 'SENDGRID_API_KEY missing'];

        $atts = [];
        foreach ($msg['attachments'] as $a) {
            $atts[] = [
                'content'      => base64_encode($a['content']),
                'filename'     => $a['filename'],
                'type'         => $a['content_type'] ?? 'application/octet-stream',
                'disposition'  => 'attachment',
            ];
        }
        foreach ($msg['inline'] as $i) {
            $atts[] = [
                'content'      => base64_encode($i['content']),
                'filename'     => $i['filename'],
                'type'         => $i['content_type'],
                'disposition'  => 'inline',
                'content_id'   => $i['cid'],
            ];
        }

        $payload = [
            'personalizations' => [[
                'to'      => [['email' => $msg['to_email']]],
                'subject' => $msg['subject'],
            ]],
            'from'     => ['email' => $msg['from_email'], 'name' => $msg['from_name']],
            'reply_to' => ['email' => $msg['reply_to']],
            'content'  => [
                ['type' => 'text/plain', 'value' => $msg['text']],
                ['type' => 'text/html',  'value' => $msg['html']],
            ],
            'headers' => $msg['headers'],
        ];
        if ($atts) $payload['attachments'] = $atts;

        return $this->httpPost('https://api.sendgrid.com/v3/mail/send', $payload, [
            'Authorization: Bearer ' . $key,
            'Content-Type: application/json',
        ]);
    }

    // ─── Provider: SMTP (fallback) ──────────────────────────────
    private function sendSmtp(array $msg): array
    {
        $cfg = $this->creds['smtp'];
        if (!$cfg['host'] || !$cfg['user']) {
            // If SMTP creds aren't set, fall back to PHP mail() with proper headers
            return $this->sendPhpMail($msg);
        }

        $boundary = '=_' . bin2hex(random_bytes(12));
        $boundaryRelated = '=_r' . bin2hex(random_bytes(12));
        $body = $this->buildMimeBody($msg, $boundary, $boundaryRelated);

        $eol = "\r\n";
        $hdr  = 'From: ' . $this->encodeName($msg['from_name']) . ' <' . $msg['from_email'] . '>' . $eol;
        $hdr .= 'Reply-To: ' . $msg['reply_to'] . $eol;
        $hdr .= 'MIME-Version: 1.0' . $eol;
        $hdr .= 'Content-Type: multipart/mixed; boundary="' . $boundary . '"' . $eol;
        foreach ($msg['headers'] as $k => $v) $hdr .= $k . ': ' . $v . $eol;

        // Build SMTP session
        $errNo = 0; $errStr = '';
        $proto = $cfg['encrypt'] === 'ssl' ? 'ssl://' : '';
        $sock  = @fsockopen($proto . $cfg['host'], $cfg['port'], $errNo, $errStr, 10);
        if (!$sock) return ['success' => false, 'error' => 'SMTP connect: ' . $errStr];

        $read = function() use ($sock) { return fgets($sock, 1024); };
        $send = function($line) use ($sock) { fwrite($sock, $line . "\r\n"); };

        $read();
        $send('EHLO mebusan.com');
        while (true) { $r = $read(); if (!str_starts_with($r, '250-')) break; }

        if ($cfg['encrypt'] === 'tls') {
            $send('STARTTLS'); $read();
            @stream_socket_enable_crypto($sock, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            $send('EHLO mebusan.com');
            while (true) { $r = $read(); if (!str_starts_with($r, '250-')) break; }
        }

        $send('AUTH LOGIN');           $read();
        $send(base64_encode($cfg['user'])); $read();
        $send(base64_encode($cfg['pass'])); $r = $read();
        if (!str_starts_with($r, '235')) { fclose($sock); return ['success' => false, 'error' => 'SMTP auth failed']; }

        $send('MAIL FROM:<' . $msg['from_email'] . '>'); $read();
        $send('RCPT TO:<' . $msg['to_email'] . '>');     $read();
        $send('DATA'); $read();

        $send('To: ' . $this->encodeName($msg['to_name']) . ' <' . $msg['to_email'] . '>');
        $send('Subject: ' . $this->encodeHeader($msg['subject']));
        $send($hdr);
        $send('');
        $send($body);
        $send('.');
        $r = $read();
        $send('QUIT'); fclose($sock);

        if (!str_starts_with($r, '250')) return ['success' => false, 'error' => 'SMTP send: ' . $r];
        return ['success' => true, 'id' => 'smtp-' . time()];
    }

    private function sendPhpMail(array $msg): array
    {
        $boundary = '=_' . bin2hex(random_bytes(12));
        $boundaryRelated = '=_r' . bin2hex(random_bytes(12));
        $body = $this->buildMimeBody($msg, $boundary, $boundaryRelated);

        $eol = "\r\n";
        $hdrs  = 'From: ' . $this->encodeName($msg['from_name']) . ' <' . $msg['from_email'] . '>' . $eol;
        $hdrs .= 'Reply-To: ' . $msg['reply_to'] . $eol;
        $hdrs .= 'Return-Path: ' . $msg['from_email'] . $eol;
        $hdrs .= 'MIME-Version: 1.0' . $eol;
        $hdrs .= 'Content-Type: multipart/mixed; boundary="' . $boundary . '"' . $eol;
        foreach ($msg['headers'] as $k => $v) $hdrs .= $k . ': ' . $v . $eol;

        $ok = @mail($msg['to_email'], $this->encodeHeader($msg['subject']), $body, $hdrs, '-f' . $msg['from_email']);
        return $ok
            ? ['success' => true, 'id' => 'mail-' . time()]
            : ['success' => false, 'error' => 'PHP mail() failed'];
    }

    private function buildMimeBody(array $msg, string $boundary, string $boundaryRelated): string
    {
        $eol = "\r\n";
        $out = '';

        // Outer: mixed (for attachments)
        $out .= '--' . $boundary . $eol;
        $out .= 'Content-Type: multipart/related; boundary="' . $boundaryRelated . '"' . $eol . $eol;

        // Inner: related (for inline CID images)
        $out .= '--' . $boundaryRelated . $eol;
        $boundaryAlt = '=_a' . bin2hex(random_bytes(8));
        $out .= 'Content-Type: multipart/alternative; boundary="' . $boundaryAlt . '"' . $eol . $eol;

        // Plain text
        $out .= '--' . $boundaryAlt . $eol;
        $out .= 'Content-Type: text/plain; charset=UTF-8' . $eol;
        $out .= 'Content-Transfer-Encoding: quoted-printable' . $eol . $eol;
        $out .= quoted_printable_encode($msg['text']) . $eol;

        // HTML
        $out .= '--' . $boundaryAlt . $eol;
        $out .= 'Content-Type: text/html; charset=UTF-8' . $eol;
        $out .= 'Content-Transfer-Encoding: quoted-printable' . $eol . $eol;
        $out .= quoted_printable_encode($msg['html']) . $eol;
        $out .= '--' . $boundaryAlt . '--' . $eol;

        // Inline CID parts
        foreach ($msg['inline'] as $i) {
            $out .= '--' . $boundaryRelated . $eol;
            $out .= 'Content-Type: ' . $i['content_type'] . '; name="' . $i['filename'] . '"' . $eol;
            $out .= 'Content-Transfer-Encoding: base64' . $eol;
            $out .= 'Content-ID: <' . $i['cid'] . '>' . $eol;
            $out .= 'Content-Disposition: inline; filename="' . $i['filename'] . '"' . $eol . $eol;
            $out .= chunk_split(base64_encode($i['content'])) . $eol;
        }
        $out .= '--' . $boundaryRelated . '--' . $eol;

        // Attachments
        foreach ($msg['attachments'] as $a) {
            $out .= '--' . $boundary . $eol;
            $out .= 'Content-Type: ' . ($a['content_type'] ?? 'application/octet-stream') . '; name="' . $a['filename'] . '"' . $eol;
            $out .= 'Content-Transfer-Encoding: base64' . $eol;
            $out .= 'Content-Disposition: attachment; filename="' . $a['filename'] . '"' . $eol . $eol;
            $out .= chunk_split(base64_encode($a['content'])) . $eol;
        }
        $out .= '--' . $boundary . '--' . $eol;

        return $out;
    }

    private function encodeHeader(string $s): string
    {
        return '=?UTF-8?B?' . base64_encode($s) . '?=';
    }

    private function encodeName(string $s): string
    {
        if ($s === '' || preg_match('/^[A-Za-z0-9 .,\'-]+$/', $s)) return $s;
        return $this->encodeHeader($s);
    }

    private function httpPost(string $url, array $payload, array $headers): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_CONNECTTIMEOUT => 6,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($code >= 200 && $code < 300) {
            $data = json_decode($body, true);
            return ['success' => true, 'id' => $data['id'] ?? $data['MessageID'] ?? 'ok-' . time()];
        }
        return ['success' => false, 'error' => $err ?: ('HTTP ' . $code . ': ' . substr((string)$body, 0, 200))];
    }

    // ─── Template renderer ─────────────────────────────────────
    public function renderTemplate(string $slug, array $vars): ?array
    {
        $dir  = $this->rootDir . '/website/emails/templates';
        $html = $dir . '/' . $slug . '.html';
        $text = $dir . '/' . $slug . '.txt';
        if (!is_readable($html)) return null;
        $baseHtml = is_readable($dir . '/_base.html') ? file_get_contents($dir . '/_base.html') : null;
        $baseTxt  = is_readable($dir . '/_base.txt')  ? file_get_contents($dir . '/_base.txt')  : null;

        $h = file_get_contents($html);
        $t = is_readable($text) ? file_get_contents($text) : strip_tags($h);

        // Extract {{subject: ...}} from the top of the HTML (first line or meta)
        $subject = '';
        if (preg_match('/^\s*\{\{\s*subject:\s*(.+?)\}\}/u', $h, $m)) {
            $subject = trim($m[1]);
            $h = preg_replace('/^\s*\{\{\s*subject:.+?\}\}\s*/u', '', $h, 1);
        }

        // Merge into _base if it has {{body}} placeholder
        if ($baseHtml && strpos($baseHtml, '{{body}}') !== false) {
            $h = str_replace('{{body}}', $h, $baseHtml);
        }
        if ($baseTxt && strpos($baseTxt, '{{body}}') !== false) {
            $t = str_replace('{{body}}', $t, $baseTxt);
        }

        // Variable substitution (simple {{var}} replacement)
        foreach ($vars as $k => $v) {
            $h = str_replace('{{' . $k . '}}', (string)$v, $h);
            $t = str_replace('{{' . $k . '}}', (string)$v, $t);
            $subject = str_replace('{{' . $k . '}}', (string)$v, $subject);
        }
        // Strip any leftover {{var}} placeholders so raw tokens do not land in inbox
        $h = preg_replace('/\{\{[a-z0-9_-]+\}\}/i', '', $h);
        $t = preg_replace('/\{\{[a-z0-9_-]+\}\}/i', '', $t);

        return ['html' => $h, 'text' => $t, 'subject' => $subject ?: 'A note from Mebusan'];
    }

    // ─── PDF generator dispatch ────────────────────────────────
    private function generatePdf(string $slug, array $vars): ?array
    {
        $path = $this->rootDir . '/website/emails/pdf/' . $slug . '.php';
        if (!is_readable($path)) return null;
        $generator = require $path;
        if (!is_callable($generator)) return null;
        $out = $generator($vars);
        return is_array($out) ? $out : null;
    }

    // ─── Logging ────────────────────────────────────────────────
    private function logAttempt(array $msg): void
    {
        $this->appendLog('attempt', $msg);
    }
    private function logResult(array $msg, array $result): void
    {
        $this->appendLog($result['success'] ? 'sent' : 'failed', array_merge($msg, ['result' => $result]));
    }
    private function appendLog(string $kind, array $data): void
    {
        $dir = $this->rootDir . '/website/cache/email_log';
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $line = json_encode([
            'ts'       => date('c'),
            'kind'     => $kind,
            'to'       => $data['to_email'] ?? '',
            'template' => $data['headers']['X-Mebusan-Template'] ?? '',
            'category' => $data['headers']['X-Mebusan-Category'] ?? '',
            'provider' => $this->provider,
            'ok'       => $data['result']['success'] ?? null,
            'error'    => $data['result']['error'] ?? null,
        ]) . "\n";
        @file_put_contents($dir . '/' . date('Y-m') . '.log', $line, FILE_APPEND | LOCK_EX);
    }
}
