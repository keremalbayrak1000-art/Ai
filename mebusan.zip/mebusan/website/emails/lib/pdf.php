<?php
/**
 * MEBUSAN · MinPDF
 * ─────────────────────────────────────────────────────────────────
 * Minimal pure-PHP PDF generator, zero dependencies.
 *
 * Built specifically for Mebusan's typographic aesthetic:
 *   - A4 pages, single-column letterpress-style layout
 *   - Helvetica (mapped to Mebusan's sans voice — Josefin Sans can't be
 *     embedded in simple PDFs without font subsetting, so we use the
 *     built-in base 14 fonts and let the layout do the lifting)
 *   - Hair-line .5pt rules for section separators
 *   - Small-caps monospace labels via Courier
 *   - Justified text via simple word wrap
 *
 * Usage:
 *   $pdf = new MinPDF();
 *   $pdf->addPage();
 *   $pdf->setFont('helvetica', 'B', 24); $pdf->text(56, 120, 'MEBUSAN');
 *   $pdf->paragraph(56, 200, 490, 'Body text ...');
 *   $pdf->rule(56, 300, 546, 300);
 *   $bytes = $pdf->output();
 *
 * Unit system: PDF points (1 pt = 1/72"). A4 = 595 × 842 pt.
 */

declare(strict_types=1);

class MinPDF
{
    public const A4_W = 595;
    public const A4_H = 842;

    protected array $pages = [];            // index -> stream
    protected array $objects = [];          // index (1-based) -> body bytes
    protected int   $currentPage = -1;
    protected string $font = 'Helvetica';
    protected string $fontStyle = '';
    protected float $fontSize = 10.0;
    protected float $lineHeight = 1.45;
    protected string $fillColor = '0 0 0';  // RGB 0..1 space-separated
    protected string $strokeColor = '0 0 0';
    protected string $title = 'Mebusan document';
    protected string $author = 'Mebusan AI PTE LTD';
    protected string $subject = '';

    public function __construct(string $title = 'Mebusan document', string $subject = '')
    {
        $this->title = $title;
        $this->subject = $subject;
    }

    public function addPage(): void
    {
        $this->pages[] = '';
        $this->currentPage = count($this->pages) - 1;
        $this->useFont();
    }

    public function setFont(string $face, string $style = '', float $size = 10.0): void
    {
        // Map to base-14 names
        $face = strtolower($face);
        $map = [
            'helvetica' => ['' => 'Helvetica', 'B' => 'Helvetica-Bold', 'I' => 'Helvetica-Oblique', 'BI' => 'Helvetica-BoldOblique'],
            'times'     => ['' => 'Times-Roman', 'B' => 'Times-Bold', 'I' => 'Times-Italic', 'BI' => 'Times-BoldItalic'],
            'courier'   => ['' => 'Courier', 'B' => 'Courier-Bold', 'I' => 'Courier-Oblique', 'BI' => 'Courier-BoldOblique'],
        ];
        $k = strtoupper($style);
        $name = $map[$face][$k] ?? 'Helvetica';
        $this->font = $name;
        $this->fontStyle = $k;
        $this->fontSize = $size;
        if ($this->currentPage >= 0) $this->useFont();
    }

    private function useFont(): void
    {
        $alias = $this->fontAliases()[$this->font];
        $this->pages[$this->currentPage] .= "/{$alias} {$this->fontSize} Tf\n";
    }

    private function fontAliases(): array
    {
        return [
            'Helvetica'              => 'F1',
            'Helvetica-Bold'         => 'F2',
            'Helvetica-Oblique'      => 'F3',
            'Helvetica-BoldOblique'  => 'F4',
            'Times-Roman'            => 'F5',
            'Times-Bold'             => 'F6',
            'Times-Italic'           => 'F7',
            'Times-BoldItalic'       => 'F8',
            'Courier'                => 'F9',
            'Courier-Bold'           => 'F10',
            'Courier-Oblique'        => 'F11',
            'Courier-BoldOblique'    => 'F12',
        ];
    }

    public function setFillColor(float $r, float $g, float $b): void
    {
        $this->fillColor = sprintf('%.3F %.3F %.3F', $r, $g, $b);
        if ($this->currentPage >= 0) $this->pages[$this->currentPage] .= $this->fillColor . " rg\n";
    }

    public function setStrokeColor(float $r, float $g, float $b): void
    {
        $this->strokeColor = sprintf('%.3F %.3F %.3F', $r, $g, $b);
        if ($this->currentPage >= 0) $this->pages[$this->currentPage] .= $this->strokeColor . " RG\n";
    }

    public function text(float $x, float $y, string $s): void
    {
        // PDF y-axis is from bottom; we expose top-down coords, so flip.
        $y = self::A4_H - $y;
        $esc = $this->escape($s);
        $this->pages[$this->currentPage] .= "BT {$x} {$y} Td ({$esc}) Tj ET\n";
    }

    public function paragraph(float $x, float $y, float $width, string $text, float $leading = 0): void
    {
        if ($leading <= 0) $leading = $this->fontSize * $this->lineHeight;

        // Normalize newlines: each \n\n starts a new para; single \n is a line break
        $paragraphs = preg_split('/\n\s*\n/', trim($text));
        $cursor = $y;
        foreach ($paragraphs as $para) {
            $lines = explode("\n", $para);
            foreach ($lines as $line) {
                $wrapped = $this->wrapLines(trim($line), $width);
                foreach ($wrapped as $wl) {
                    $this->text($x, $cursor, $wl);
                    $cursor += $leading;
                }
            }
            $cursor += $leading * 0.45; // paragraph gap
        }
    }

    private function wrapLines(string $text, float $width): array
    {
        $words = preg_split('/\s+/', $text);
        $lines = [];
        $buf = '';
        foreach ($words as $w) {
            $candidate = $buf === '' ? $w : $buf . ' ' . $w;
            if ($this->textWidth($candidate) <= $width) {
                $buf = $candidate;
            } else {
                if ($buf !== '') $lines[] = $buf;
                $buf = $w;
            }
        }
        if ($buf !== '') $lines[] = $buf;
        return $lines;
    }

    /** Rough width using baseline built-in font metrics. */
    private function textWidth(string $s): float
    {
        $len = mb_strlen($s, 'UTF-8');
        $perChar = str_starts_with($this->font, 'Courier') ? 0.60 : 0.52;
        return $len * $this->fontSize * $perChar;
    }

    public function rule(float $x1, float $y1, float $x2, float $y2, float $thickness = 0.5): void
    {
        $y1 = self::A4_H - $y1;
        $y2 = self::A4_H - $y2;
        $this->pages[$this->currentPage] .= "q {$thickness} w {$this->strokeColor} RG {$x1} {$y1} m {$x2} {$y2} l S Q\n";
    }

    public function rect(float $x, float $y, float $w, float $h, bool $fill = false): void
    {
        $y = self::A4_H - $y - $h;
        $op = $fill ? 'f' : 'S';
        $this->pages[$this->currentPage] .= "{$x} {$y} {$w} {$h} re {$op}\n";
    }

    public function label(float $x, float $y, string $s, float $size = 7.0, float $tracking = 1.6): void
    {
        // Tracked uppercase mono, Mebusan's signature label style
        $save = [$this->font, $this->fontStyle, $this->fontSize];
        $this->setFont('courier', '', $size);
        // Simple tracking via character-by-character placement
        $upper = strtoupper($s);
        $cursor = $x;
        $charW  = $size * 0.60;
        for ($i = 0, $n = strlen($upper); $i < $n; $i++) {
            $ch = $upper[$i];
            $this->text($cursor, $y, $ch);
            $cursor += $charW + $tracking;
        }
        $this->setFont(strtolower(explode('-', $save[0])[0]), $save[1], $save[2]);
    }

    /** Escape text for PDF string literal. */
    private function escape(string $s): string
    {
        $s = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);
        // PDF string default is WinAnsi; convert UTF-8 to CP1252 where possible
        $s = @iconv('UTF-8', 'CP1252//TRANSLIT', $s);
        return (string)$s;
    }

    public function output(): string
    {
        // Build objects array. PDF objects are 1-indexed.
        $this->objects = [];

        // 1. Catalog
        $this->objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";

        // 2. Pages list (index set after we know page count)
        $pageCount = count($this->pages);
        $pageKidsRefs = [];

        // Fonts object
        $fontAliases = $this->fontAliases();
        $fontDict = '';
        $fontObjStartIdx = 3 + $pageCount * 2; // pages + content streams occupy next slots
        $fontIdx = $fontObjStartIdx;
        $fontMap = [];
        foreach ($fontAliases as $full => $alias) {
            $fontDict .= "/{$alias} {$fontIdx} 0 R ";
            $fontMap[$fontIdx] = $full;
            $fontIdx++;
        }
        $resources = "<< /Font << {$fontDict}>> >>";

        // 3..(3+pageCount*2): page + content pairs
        $cursor = 3;
        foreach ($this->pages as $i => $stream) {
            $contentsRef = ($cursor + 1) . " 0 R";
            $pageObj = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " . self::A4_W . " " . self::A4_H . "] /Contents {$contentsRef} /Resources {$resources} >>";
            $this->objects[$cursor] = $pageObj;
            $pageKidsRefs[] = $cursor . ' 0 R';
            $cursor++;
            // Compress content stream? Keep uncompressed for portability.
            $streamBytes = $stream;
            $len = strlen($streamBytes);
            $this->objects[$cursor] = "<< /Length {$len} >>\nstream\n{$streamBytes}\nendstream";
            $cursor++;
        }

        // Pages dictionary
        $kids = implode(' ', $pageKidsRefs);
        $this->objects[2] = "<< /Type /Pages /Kids [{$kids}] /Count {$pageCount} >>";

        // Fonts (base-14)
        foreach ($fontMap as $idx => $name) {
            $this->objects[$idx] = "<< /Type /Font /Subtype /Type1 /BaseFont /{$name} /Encoding /WinAnsiEncoding >>";
        }

        // Document info (metadata)
        $infoIdx = $cursor + count($fontMap); // safety placement
        // Place at end
        $infoIdx = max(array_keys($this->objects)) + 1;
        $infoObj = sprintf(
            "<< /Title (%s) /Author (%s) /Subject (%s) /Producer (Mebusan MinPDF) /CreationDate (D:%s) >>",
            $this->escape($this->title),
            $this->escape($this->author),
            $this->escape($this->subject),
            date('YmdHis') . '+00\'00\''
        );
        $this->objects[$infoIdx] = $infoObj;

        // Serialize
        $out  = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [];
        foreach ($this->objects as $idx => $body) {
            $offsets[$idx] = strlen($out);
            $out .= "{$idx} 0 obj\n{$body}\nendobj\n";
        }

        $xrefPos = strlen($out);
        $maxIdx = max(array_keys($this->objects));
        $out .= "xref\n0 " . ($maxIdx + 1) . "\n";
        $out .= "0000000000 65535 f \n";
        for ($i = 1; $i <= $maxIdx; $i++) {
            if (isset($offsets[$i])) {
                $out .= sprintf("%010d 00000 n \n", $offsets[$i]);
            } else {
                $out .= "0000000000 65535 f \n";
            }
        }
        $out .= "trailer\n<< /Size " . ($maxIdx + 1) . " /Root 1 0 R /Info {$infoIdx} 0 R >>\nstartxref\n{$xrefPos}\n%%EOF\n";

        return $out;
    }
}
