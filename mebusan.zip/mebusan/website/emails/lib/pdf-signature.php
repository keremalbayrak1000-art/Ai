<?php
/**
 * MEBUSAN · MinPDF extension — signature support
 * ─────────────────────────────────────────────────────────────────
 * Renders browser-captured vector signatures as native PDF paths.
 * No image embedding, no external libs — every stroke becomes a
 * PDF path operator, which keeps the file tiny and the document
 * hash deterministic for legal-grade verification.
 */

declare(strict_types=1);
require_once __DIR__ . '/pdf.php';

class MebusanSignaturePDF extends MinPDF
{
    /**
     * Render captured canvas strokes as PDF vector paths.
     */
    public function drawStrokes(
        array $strokes,
        float $x, float $y, float $w, float $h,
        float $cW, float $cH,
        array $color = [0.05, 0.1, 0.3]
    ): void {
        if (empty($strokes) || $cW <= 0 || $cH <= 0 || $this->currentPage < 0) return;

        $sx = $w / $cW;
        $sy = $h / $cH;

        $stream = "q\n";
        $stream .= sprintf("%.3F %.3F %.3F RG\n", $color[0], $color[1], $color[2]);
        $stream .= "1 J 1 j\n";

        foreach ($strokes as $stroke) {
            if (!is_array($stroke) || count($stroke) < 2) continue;
            $first = true;
            $avgP = 0.0; $count = 0;
            foreach ($stroke as $pt) { $avgP += (float)($pt['p'] ?? 0.5); $count++; }
            $avgP = $count ? ($avgP / $count) : 0.5;
            $lineW = max(0.7, min(2.4, 0.9 + $avgP * 1.5));
            $stream .= sprintf("%.3F w\n", $lineW);

            foreach ($stroke as $pt) {
                $px = ($pt['x'] ?? 0) * $sx + $x;
                $py = self::A4_H - ($y + ($pt['y'] ?? 0) * $sy);
                if ($first) {
                    $stream .= sprintf("%.3F %.3F m\n", $px, $py);
                    $first = false;
                } else {
                    $stream .= sprintf("%.3F %.3F l\n", $px, $py);
                }
            }
            $stream .= "S\n";
        }

        $stream .= "Q\n";
        $this->pages[$this->currentPage] .= $stream;
    }

    public function drawTypedSignature(string $name, float $x, float $y, float $size = 32.0, array $color = [0.05, 0.1, 0.3]): void
    {
        $this->setFillColor($color[0], $color[1], $color[2]);
        $this->setFont('times', 'I', $size);
        $this->text($x, $y, $name);
        $this->setStrokeColor($color[0] + 0.1, $color[1] + 0.1, $color[2] + 0.1);
        $lineWidth = min(400, mb_strlen($name) * $size * 0.6);
        $this->rule($x, $y + $size * 0.2, $x + $lineWidth, $y + $size * 0.2, 0.4);
    }
}
