# MEBUSAN — 100 Data Collection & Intelligence Strategies

**Compiled April 2026 · Internal strategy document**

---

## SECTION A — CURRENCY & CAPITAL CONTROL SIGNALS (1–18)

**01 · Parallel exchange rate premium monitoring**
Track the spread between official and unofficial/parallel exchange rates for every monitored currency. Premium crossing 3% = Watch. Crossing 5% = Flag. Crossing 8% = Critical. Source: wise.com rates, local money transfer operators, Bloomberg FX composite. The Turkey parallel premium signal that flagged the current situation came from this exact methodology. Historical precedent: Lebanon premium crossed 8% in September 2019 — restrictions followed in October.

**02 · Central bank reserve drawdown velocity**
Monitor official foreign reserve levels published by each country's central bank. A reserve drawdown exceeding 5% month-on-month is an early capital flight signal. IMF Special Data Dissemination Standard (SDDS) countries publish this monthly. Source: IMF International Reserves template, individual central bank websites. Cross-reference with current account deficit to distinguish seasonal drawdown from stress drawdown.

**03 · Sovereign CDS spread monitoring**
Credit Default Swap spreads are the fastest-moving market signal for sovereign stress. A spread widening above 300bps = Watch. Above 500bps = Flag. Monitor daily via Bloomberg, Markit, or Refinitiv. For clients with banking exposure, CDS spreads are often the earliest signal that correspondent banking relationships are at risk. CFR Sovereign Risk Tracker updates this monthly as a free alternative.

**04 · Foreign exchange bid-ask spread tracking**
Wide bid-ask spreads in a currency's FX market indicate dealer reluctance and reduced liquidity — an early sign of stress before parallel premiums become visible. Monitor through ECB daily FX statistics and BIS FX turnover surveys. Spreads widening by more than 2x their 30-day average trigger a Watch flag.

**05 · Capital flow at-risk model per jurisdiction**
IMF capital-flows-at-risk methodology quantifies the probability of sudden capital outflows based on push and pull factors. Implement a simplified version: US dollar strength (DXY direction) × local monetary policy credibility score × foreign currency debt share = capital flight probability. Recalculate monthly per jurisdiction. Output feeds directly into risk gauge scoring.

**06 · Money transfer operator (MTO) rate divergence**
Track rates offered by Wise, Western Union, and local MTOs for each currency. When MTO rates begin diverging significantly from the official rate before a parallel premium is visible in data, this is the earliest signal of informal capital controls beginning to form. API access available from most major MTOs for institutional clients.

**07 · Swap spread monitoring for EM local currency bonds**
Swap spreads on local currency government bonds indicate the cost of hedging currency risk for foreign investors. When spreads widen sharply it signals international investor exit from a currency, often weeks before formal restrictions. Source: Bloomberg swap rates, BIS data.

**08 · Short interest in local currency ETFs**
Monitor short positions in country-specific ETFs (e.g. TUR for Turkey, EWA for Australia). Institutional investors who expect currency devaluation short these ETFs as a hedge. Rising short interest is a predictive signal. Source: FINRA short interest data, S3 Partners analytics.

**09 · CBRT/central bank intervention signals**
When central banks spend reserves defending a currency peg or corridor, the daily transaction data often leaks through the BIS quarterly review, local banking authority reports, and IMF Article IV consultations. Track these publication calendars and parse for intervention language. A central bank that has been intervening for 6+ weeks typically faces a choice: devalue, restrict, or collapse.

**10 · FX forward curve steepness**
An unusually steep or inverted FX forward curve (where the one-year forward rate diverges sharply from spot) signals that institutional investors are pricing in significant devaluation or restriction risk. Track for all monitored currencies. Threshold: forward rate diverging more than 15% from spot (annualised) = Flag.

**11 · Wire transfer rejection rate monitoring**
Banks track internally the rejection/return rate for outbound international wires. When this rises in a jurisdiction — due to correspondent banks tightening their exposure — it is a precursor to formal restrictions. Source: Swift transaction data (subscription), Accuity/Bankers Almanac data, direct relationship monitoring through banking contacts.

**12 · Eurodollar/offshore currency market stress**
Monitor offshore markets for a currency (e.g. CNH vs CNY, or any USD-settled forward for a restricted currency). When the offshore market begins pricing in restrictions through forward rate divergence, it often precedes the onshore announcement by days to weeks.

**13 · Gold premium in local currency**
In countries facing capital control risk, citizens begin buying gold as a store of value. Gold trading at a local premium above international LBMA prices (adjusted for FX) is a textbook early warning signal. Lebanon gold premium ran ahead of 2019 restrictions. Source: local commodity exchange prices, gold dealer rate surveys.

**14 · Cryptocurrency exchange volume spikes**
In countries with capital control history, cryptocurrency trading volume spikes on local exchanges when restriction risk rises. Binance P2P rates, LocalBitcoins data, and Chainalysis country-level flow data all capture this. A volume spike of 3x 30-day average = Watch signal for capital flight intent.

**15 · Real estate price denominated in USD vs local currency**
When local real estate sellers begin pricing in USD rather than local currency — informal dollarisation — this is a strong signal that local holders no longer trust the currency to hold value. Track through local real estate portals, Numbeo.com data, and local property agent networks.

**16 · ATM withdrawal limit changes**
Central banks typically reduce ATM withdrawal limits before formal capital controls to test public reaction and slow the pace of cash withdrawal. Monitor central bank circulars and local banking authority announcements for ATM/POS limit changes. Source: local central bank regulation databases.

**17 · Cross-border payment delay pattern**
When institutional cross-border payments begin taking longer than normal to clear for a specific country pair, this is an operational early warning of correspondent banking withdrawal or informal restriction. Source: Swift Analytics for corporates, client-reported transaction timing, correspondent banking relationship managers.

**18 · Remittance flow reversal**
Countries that historically receive large diaspora remittances sometimes see those flows reverse or slow when economic stress rises — diaspora stops sending money home because they lose confidence in the local banking system. World Bank remittance data, IFAD rural finance data. A 20%+ quarterly decline in remittance inflows = risk flag.

---

## SECTION B — BANKING SYSTEM SIGNALS (19–32)

**19 · Interbank lending rate stress (IBOR equivalents)**
Monitor each country's interbank offered rate for sudden spikes, which indicate banks are unwilling to lend to each other — a classic banking system stress signal. Turkey's TLREF, Lebanon's LEBOR (historical), UAE's EIBOR, Singapore's SORA. Spike of 200bps above 30-day moving average = Flag.

**20 · Non-performing loan ratio trends**
Published quarterly by most central banks and banking regulators. Rising NPL ratios above 10% of total loans indicate systemic banking stress that precedes depositor runs. Source: central bank financial stability reports, IMF Financial Soundness Indicators database (free).

**21 · Bank deposit flight early signals**
Monitor aggregate bank deposit levels published monthly/quarterly by central banks. A month-on-month deposit decline of more than 2% across the system = Watch. More than 5% = Flag. This is the metric that tracked Lebanese banking stress 18 months before restrictions.

**22 · Correspondent banking relationship mapping**
Maintain a database of which international banks maintain correspondent relationships with local banks in each monitored jurisdiction. When a major correspondent (e.g. Deutsche Bank, Citi, JP Morgan) terminates a relationship with a local bank, it is a material signal about risk appetite. Source: Accuity Global SWIFT data, Bankers Almanac, financial press.

**23 · Bank stock price relative to book value**
For countries with listed banks, monitor bank stock price-to-book value ratios. When banks trade significantly below book (P/B < 0.5), the market is pricing in balance sheet problems. Combined with other signals, this is a reliable crisis predictor. Source: Bloomberg, local stock exchange data.

**24 · Deposit guarantee scheme changes**
When governments change the terms or limits of deposit guarantee schemes — particularly if done quietly or without announcement — this signals awareness of banking system vulnerability at the government level. Source: IADI (International Association of Deposit Insurers) database, local banking authority websites.

**25 · IMF Article IV consultation findings**
The IMF conducts annual Article IV consultations with member countries. The published reports contain the IMF staff's frank assessment of banking system vulnerabilities. Parse these for key phrases: "elevated NPLs", "liquidity pressure", "capital adequacy concerns", "dollarisation risk". Source: IMF.org, typically published 6-12 months after consultation.

**26 · BIS quarterly review banking data**
The Bank for International Settlements publishes quarterly data on cross-border banking exposures by nationality of reporting banks. When international bank exposure to a country begins falling (deleveraging), it is a leading indicator of correspondent banking withdrawal and credit restriction. Source: BIS.org/statistics, free quarterly data.

**27 · Local banking regulator press releases**
Parse press releases from local banking authorities (e.g. CBRT, CBUAE, MAS, BNB, NBU) for language patterns associated with stress: "enhanced monitoring", "liquidity requirement review", "systemically important bank designation", "directed lending". Source: individual central bank websites, RSS feeds.

**28 · Credit rating agency outlook changes**
Monitor Moody's, S&P, and Fitch for sovereign and banking sector rating changes, but particularly outlook changes (from Stable to Negative), which precede actual rating downgrades by 6-18 months. Source: rating agency websites, Bloomberg credit functions. Outlook change = Watch. Rating downgrade = Flag.

**29 · Banking sector market cap concentration**
When a country's banking sector becomes increasingly concentrated (a few large banks holding disproportionate share), systemic risk rises. Monitor HHI (Herfindahl-Hirschman Index) for banking sector concentration via central bank reports. High concentration + stress = amplified risk.

**30 · Local bank liquidity coverage ratio (LCR) disclosures**
Basel III-compliant banks publish LCR data quarterly. An LCR trending toward the 100% minimum from well above it indicates liquidity stress building. Source: individual bank Pillar 3 disclosure reports, EBA transparency exercise for EU banks.

**31 · Interbank FX swap market stress**
When banks struggle to fund themselves in foreign currency, FX swap basis spreads widen — this is "dollar shortage" stress. Monitor EUR/USD, USD/TRY, USD/AED cross-currency basis swap spreads. Sharp widening = banks in that currency system are struggling to access dollars. Source: Bloomberg FX function.

**32 · Digital banking app disruption monitoring**
Monitor user reports on social media, downdetector.com, and local tech forums for recurring digital banking access problems in monitored jurisdictions. Consistent app failures often precede or accompany capital control announcements, as banks are operationally overwhelmed or deliberately restricting digital access.

---

## SECTION C — REGULATORY & SANCTIONS PIPELINE (33–46)

**33 · FATF monitoring — greylisting/blacklisting pipeline**
FATF publishes its mutual evaluation schedule publicly. Countries scheduled for evaluation in the next 12 months face elevated compliance pressure that often translates into rushed banking regulation changes. Track FATF plenary meeting outcomes and mutual evaluation reports. Source: fatf-gafi.org, updated after each plenary (February, June, October).

**34 · OFAC SDN list daily monitoring**
The US Treasury OFAC SDN (Specially Designated Nationals) list is updated multiple times per week. Monitor for additions affecting: individual names matching client profiles, entities in monitored countries, correspondent bank designations, and shell company structures. Source: OFAC.treasury.gov API, free daily diff. Critical for clients with US-linked accounts.

**35 · EU sanctions tracker**
EU sanctions are often coordinated but not always simultaneous with US designations. Monitor the EU Consolidated Financial Sanctions List (CFSL) for additions and changes. Source: European Commission sanctions API, updated daily. Cross-reference with client asset jurisdictions.

**36 · UK OFSI sanctions monitoring**
Post-Brexit, the UK Office of Financial Sanctions Implementation (OFSI) maintains an independent list that sometimes includes entities not on US/EU lists. Source: gov.uk/ofsi, daily XML export.

**37 · SWIFT MT940 restriction monitoring**
When SWIFT restricts messaging for specific countries or institutions (as happened with Russia, Iran, and historically with other sanctioned entities), monitor SWIFT.com communications and the list of connected BICs. Loss of SWIFT connectivity to a specific bank is often a precursor to or consequence of sanctions. Source: swift.com/our-solutions/compliance-and-shared-services.

**38 · Beneficial ownership register deadline tracking**
More than 50 countries have implemented or are implementing beneficial ownership registers for companies and property. Track implementation timelines, deadlines for existing structures, and enforcement periods. Source: Global Forum on Transparency and Exchange of Information for Tax Purposes, FATF mutual evaluations.

**39 · CRS/AEOI new jurisdiction additions**
The OECD Common Reporting Standard adds new participating jurisdictions regularly. Track the CRS status of every jurisdiction where clients hold assets, and flag when a jurisdiction announces CRS participation or upgrades its information exchange framework. Source: OECD.org/tax/automatic-exchange.

**40 · Local parliament/regulatory gazette monitoring**
Each jurisdiction publishes regulatory changes through official gazettes (e.g. Turkey's Resmî Gazete, UAE Federal Official Gazette, Singapore Government Gazette). RSS-feed these publications and parse for keywords: foreign exchange, banking, capital movement, reporting requirement, beneficial owner, trust, offshore. This catches changes before they are reported in financial press.

**41 · Real estate AML regulation pipeline**
Financial Action Task Force guidance on real estate AML is driving country-by-country regulatory tightening. Monitor FATF guidance updates and individual country implementation plans for real estate sector AML requirements. Source: FATF, UNODC.

**42 · Stablecoin/digital asset regulation per jurisdiction**
The regulatory status of digital assets changes rapidly per jurisdiction. Monitor Financial Stability Board country-by-country implementation reports, local financial regulator announcements, and MiCA implementation progress (EU). Relevant for clients holding digital assets or crypto exchange positions.

**43 · Tax treaty network changes**
When countries renegotiate or terminate double taxation agreements (DTAs), the implications for offshore structures can be significant. Monitor IBFD tax treaty database, UN Tax Committee updates, and OECD BEPS implementation progress. Treaty termination = potential structure review required.

**44 · Economic substance regulation changes**
BVI, Cayman, Jersey, Guernsey, and other offshore centres have all implemented economic substance rules post-2019. Monitor for changes to substance requirements, enforcement activities, and peer review findings from the OECD Global Forum. Source: individual jurisdiction financial services commission websites.

**45 · OECD/G20 Pillar Two global minimum tax implementation**
The 15% global minimum corporate tax is being implemented country by country. Track domestic legislation progress for each jurisdiction where clients hold operating businesses or holding structures. Source: OECD BEPS database, Deloitte global minimum tax tracker.

**46 · National security review of foreign investment changes**
Countries are expanding the scope of foreign investment screening (US CFIUS, UK NSI Act, EU FDI screening). Monitor for changes to screening thresholds, new sector designations, and enforcement actions in jurisdictions where clients hold business interests. Source: Baker McKenzie CFIUS tracker, Herbert Smith Freehills FDI monitor.

---

## SECTION D — PROPERTY & LAND SIGNALS (47–58)

**47 · Expropriation and forced sale precedents**
Track court decisions and government orders affecting foreign-owned property in monitored jurisdictions. A single expropriation case is a watch signal for broader risk. Monitor: ICSID (International Centre for Settlement of Investment Disputes) case registry, local court databases, investment treaty arbitration panels. Source: icsid.worldbank.org, italaw.com.

**48 · Foreign ownership restriction changes**
Monitor for changes to foreign ownership caps on property — introduced, tightened, or announced for consultation. Source: national property authority websites, legal gazette monitoring, CBRE/JLL country regulatory updates.

**49 · Property registry digitisation and transparency**
When countries digitise their land registries and make them publicly searchable, previously hidden beneficial ownership becomes visible. This creates retrospective disclosure risk for clients holding property through nominee or trust structures. Monitor: World Bank Land Portal, individual country property registry announcements.

**50 · Agricultural land foreign ownership restrictions**
Agricultural land faces separate and often stricter foreign ownership restrictions than residential or commercial property in many jurisdictions. Monitor EU agricultural land regulations (which restrict foreign buyers differently from urban property), Turkey farmland rules, and UAE agricultural land designations.

**51 · Urban zoning reclassification monitoring**
Reclassification of agricultural land as protected conservation, or urban land as restricted use, can materially affect property values and exit options. Monitor local planning authority publications, government gazette land use changes, and satellite imagery services that track land use change.

**52 · Property price index monitoring per city/district**
Track official property price indices for each monitored city (CBRE, Knight Frank, JLL, local valuation authorities). A price correction of more than 15% from peak in a monitored city = Watch flag for clients with property there. Relevant not just for value but for potential forced sale situations.

**53 · Construction cost inflation and developer stress**
When property developers in a market face acute stress (rising costs, debt defaults), they often trigger fire sale conditions that depress values and create AML scrutiny on transactions. Monitor: local developer bond spreads, construction cost indices, developer credit ratings.

**54 · Tourism and hospitality sector stress for property**
For clients with hospitality assets, monitor hotel occupancy rate data (STR/CoStar), RevPAR trends, and Airbnb supply/demand data by city. A 20%+ RevPAR decline in a monitored city = Watch flag.

**55 · Mortgage market stress signals**
In countries where foreign property owners use local mortgage financing, monitor mortgage default rates, bank foreclosure activity, and mortgage interest rate changes. Rising defaults in the same market = potential value risk and exit difficulty.

**56 · Dubai/Abu Dhabi property transaction registry**
DLD (Dubai Land Department) publishes transaction data daily. Monitor: transaction volume changes (30%+ quarterly decline = market stress signal), new AML disclosure requirements, and any regulatory circular changes from RERA. Source: dubailand.gov.ae data portal.

**57 · Singapore property cooling measures monitoring**
Singapore regularly adjusts ABSD (Additional Buyer's Stamp Duty) rates for foreign buyers. Track MAS and HDB policy announcements. Changes affect both acquisition plans and existing holdings. Source: MAS.gov.sg, HDB.gov.sg, URA policy updates.

**58 · Heritage/protected status designation risk**
In some jurisdictions (UK, France, Italy), properties can be designated as heritage or listed buildings, restricting renovation and exit options. Monitor relevant heritage authority activity for client property locations.

---

## SECTION E — GEOPOLITICAL & POLITICAL SIGNALS (59–70)

**59 · Political leader health and succession signals**
In countries with dominant political figures, health concerns about the leader create significant policy uncertainty. Monitor: unusual absence from public events, delegation of powers, emergency cabinet meetings, foreign media reports. This is a delicate but material risk signal for authoritarian-adjacent jurisdictions.

**60 · Election calendar and polling monitoring**
Maintain a 24-month forward calendar of elections for all monitored jurisdictions. Monitor polling data for scenarios that would trigger economic policy changes — particularly changes in foreign investment policy, banking regulation, or property rights. Source: IDEA Electoral Calendar, local polling aggregators.

**61 · Protest and civil unrest early indicators**
Monitor social media sentiment analysis for protest mobilisation signals in monitored cities. GDELT project provides real-time event data. ACLED (Armed Conflict Location and Event Data Project) provides structured conflict event data. An increase in protest event frequency of 3x 90-day average = Watch flag.

**62 · Governing coalition fragility monitoring**
Coalition governments in parliamentary systems can fall with little warning, creating regulatory uncertainty. Monitor vote confidence margins, defections, coalition agreement stress. Source: local parliamentary websites, Reuters political risk service, Politico Europe for EU countries.

**63 · Judicial independence signals**
In countries where judicial independence is weakening (executive interference in courts, politically motivated prosecutions), property rights and contract enforcement become less reliable. Monitor: World Justice Project Rule of Law Index, Transparency International Corruption Perceptions Index, individual country court rulings on foreign investor cases.

**64 · Central bank governor independence signals**
When a government dismisses, pressures, or replaces a central bank governor, monetary policy credibility collapses and currency risk escalates sharply. Monitor: news monitoring for central bank governance, formal appointment/dismissal notifications, central bank communication changes. Turkey's experience with multiple CBRT governor changes is the textbook case.

**65 · Emergency powers and state of exception monitoring**
When governments invoke emergency powers legislation — even for stated non-economic reasons — it typically includes powers to restrict financial flows. Monitor: national security law updates, state of emergency declarations, martial law situations in monitored jurisdictions.

**66 · China/US relations as proxy for regional risk**
The US-China relationship is the principal driver of EM risk sentiment. Monitor: trade negotiation status, Taiwan Strait military activity levels, technology export control announcements, and the Bloomberg US-China Trade War tracker. For clients with Southeast Asia and Hong Kong exposure, this is the primary background risk driver.

**67 · Regional contagion chain monitoring**
Financial crises spread through regional channels. If a neighbouring country enters acute stress, monitor for contagion signals in adjacent jurisdictions. Lebanon/Egypt/Jordan, Turkey/Greece/Eastern Europe, Argentina/Brazil/Chile are historical contagion chains. Source: BIS working papers on contagion measurement.

**68 · US secondary sanctions expansion monitoring**
US secondary sanctions can trap non-US entities in a country that becomes subject to a new sanctions programme. Monitor OFAC advisory notices, Congressional sanctions legislation progress, and SDN list expansion patterns. Particularly relevant for clients with Iran, Russia, Belarus, or Venezuela-adjacent exposures.

**69 · International arbitration treaty risk**
Monitor cases brought at ICSID and PCA (Permanent Court of Arbitration) against monitored jurisdictions. A country facing multiple investor-state dispute cases is signalling deteriorating treatment of foreign investors even if no formal policy change has been announced. Source: italaw.com, ICSID pending cases list.

**70 · Oil and energy geopolitics impact model**
For Gulf-region clients, oil price trajectory drives both economic performance and political stability. Build a simplified model: oil price below $60/barrel sustained for 6+ months = fiscal stress in Gulf states = increased regulatory activity and potential liquidity management measures. Source: World Bank commodity forecasts, EIA.

---

## SECTION F — CORPORATE STRUCTURE MONITORING (71–80)

**71 · Beneficial ownership register search automation**
Automate daily/weekly searches across all available beneficial ownership registers (UK HMRC, BVI BO register, Cayman BO portal, Luxembourg RCS, Netherlands KVK) for client-specified names, entities, and associated party names. Flag when new entries appear, when records change, or when associated entities are listed.

**72 · Economic substance review triggers**
Monitor for regulatory correspondence from offshore financial centres (BVI FSC, CIMA, JFSC) indicating that a client's structure has been selected for economic substance review. Source: regulatory correspondence monitoring, legal counsel in jurisdiction.

**73 · Company registry annual return deadlines**
Each jurisdiction requires annual returns for registered companies. Missing these creates deregistration risk and loss of corporate protections. Build a comprehensive deadline calendar per entity per jurisdiction. Source: company registry websites, registered agent correspondence.

**74 · Director/shareholder change monitoring**
In many jurisdictions, company ownership register changes are publicly filed and searchable. Monitor for unexpected changes to directors or shareholders in client-related entities — this can signal hostile corporate activity, unintended disclosure, or registered agent errors. Source: Companies House UK, BVI FSC, Malta MFSA.

**75 · Trust and foundation update requirements**
Trustees are required to update trust deeds and beneficiary records following regulatory changes (FATCA, CRS, local trust legislation). Track upcoming update deadlines and regulatory consultation outcomes for each jurisdiction where trusts are registered.

**76 · SPV/holding company jurisdiction risk scoring**
Score each jurisdiction used for holding company structures on: political risk, regulatory stability, tax treaty network, banking access, and CRS participation. Recalculate quarterly. If a jurisdiction's score falls below threshold (e.g. following FATF greylisting), trigger a structure review recommendation.

**77 · Patent box and IP holding regime changes**
For clients with IP held offshore, monitor OECD BEPS Action 5 implementation progress, modified nexus approach adoption, and individual country IP box regime changes. These affect the tax efficiency of offshore IP structures significantly.

**78 · Registered agent stability monitoring**
The financial health and regulatory standing of registered agents matters. If a registered agent is under investigation, loses its licence, or is subject to disciplinary action, all client structures serviced by that agent are at risk. Monitor registered agent licence status through individual FSC websites.

**79 · Cross-border merger and acquisition restrictions**
For clients with operating businesses, monitor changes to FDI screening, merger control thresholds, and foreign ownership caps that would affect the ability to exit or restructure. Source: KPMG/Deloitte FDI monitoring services, national investment promotion agencies.

**80 · Golden visa/citizenship by investment programme monitoring**
For clients holding residency or citizenship through investment programmes, monitor: programme suspension announcements, EU pressure on participating countries, increased due diligence requirements, and retrospective review announcements. Source: investment migration counsel reports, EU Parliament resolutions on golden visas.

---

## SECTION G — ALTERNATIVE DATA & SIGNALS (81–90)

**81 · Satellite imagery for property and infrastructure monitoring**
Commercial satellite imagery (Planet Labs, Maxar, Airbus Defence & Space) can detect: construction activity changes, property abandonment, infrastructure stress, and port/airport activity that predicts economic conditions. Use for monitoring commercial property clients in jurisdictions where data quality is otherwise poor.

**82 · Flight data for capital flight signals**
Monitor flight data from FlightAware/FlightRadar24 for unusual patterns of private jet movements in monitored jurisdictions. A spike in private flights out of a country — particularly by wealthy residents — often precedes publicly announced capital controls. This was observable before Zimbabwe and Venezuela restrictions.

**83 · Port and shipping data for economic stress**
Monitor AIS (Automatic Identification System) shipping data for port activity levels in monitored countries. Declining vessel traffic at a country's main commercial port is a leading indicator of economic contraction and trade disruption. Source: MarineTraffic, VesselsValue.

**84 · Mobile connectivity and internet freedom monitoring**
Internet shutdowns and throttling often precede or accompany political crises that create financial risk. Monitor: NetBlocks (internet disruption real-time), OONI (Open Observatory of Network Interference), Cloudflare Radar. Sustained internet disruption = immediate flag for clients with assets in that jurisdiction.

**85 · Social media sentiment by jurisdiction — localised**
Run language-specific sentiment analysis on local social media platforms (not just English Twitter). Turkish Twitter/X discussions of bank runs or capital controls in Turkish are often 48-72 hours ahead of English-language coverage. Telegram groups in Arabic, Persian, and Turkish often signal financial stress in real time. Source: Brandwatch, Meltwater, custom scraping with translation.

**86 · Property listing days-on-market tracking**
Track average days-on-market for property listings in monitored cities (Rightmove, Bayut, PropertyFinder, 99.co). Rising days-on-market is a leading indicator of market stress and exit difficulty. Threshold: 30%+ increase over 90-day moving average = Watch.

**87 · Google Trends for financial stress terms by country**
Monitor Google Trends search volume for country-specific financial stress terms: "capital controls", "bank run", "withdraw money", "dollar exchange" in local languages. Spikes in these search terms — particularly in local language — often precede formal announcements by 24-72 hours.

**88 · Grocery and consumer price index proxies**
When official inflation data is unreliable (a risk in Turkey, Argentina, Egypt), use independent proxies: supermarket price surveys (MIT Billion Prices Project, Premise Data), crowd-sourced price tracking (Numbeo). Sharp real-world inflation often precedes currency interventions and capital controls.

**89 · Real-time business closure/insolvency data**
Monitor company insolvency registrations in monitored jurisdictions. A spike in corporate insolvencies — particularly in the banking, real estate, or construction sectors — is a leading indicator of broader economic stress. Source: local insolvency registers, Dun & Bradstreet country risk alerts.

**90 · Dark web and intelligence community signal monitoring**
Financial crisis risk is sometimes telegraphed on forums and encrypted messaging platforms before it surfaces in mainstream financial data. Use legal OSINT techniques to monitor Telegram channels, relevant dark web forums, and intelligence community published assessments. Source: CISA advisories, Recorded Future Insikt Group reports, Jane's Country Risk (subscription).

---

## SECTION H — APP & WEBSITE IMPLEMENTATION (91–100)

**91 · Risk score recalculation engine**
Build an automated scoring engine that recalculates each jurisdiction's risk score daily by weighting the signals across sections A-G. Weight categories: banking signals 25%, currency signals 20%, regulatory pipeline 20%, geopolitical 15%, property 10%, alternative data 10%. Score output maps to: 0-2 = Stable, 3-4 = Watch, 5-7 = Elevated, 8-10 = Critical. Display as the 5-bar gauge already in the app.

**92 · Signal velocity tracking — not just level**
It is not just where the risk is, but how fast it is moving. Track the rate-of-change of each signal over 7, 30, and 90-day windows. A jurisdiction moving from score 3 to score 5 in two weeks is more urgent than one stable at 6. Display velocity as a directional arrow (↑ rising / → stable / ↓ falling) next to each asset card.

**93 · Client-specific risk overlay**
Layer the jurisdictional risk score with the client's specific exposure type. A banking account in Turkey is more exposed to capital control risk than property in Turkey. A trust structure in Singapore faces different risks from a residential property. Each asset type has a different exposure coefficient to each risk category. This makes the risk gauge asset-specific, not just jurisdiction-specific.

**94 · Predictive time-to-event modelling**
Use historical crisis data (IMF database, Reinhart-Rogoff crisis dataset, ACLED conflict events) to build a simplified time-to-event model: given current signal levels, what is the estimated probability of a restriction event in the next 30/60/90 days? Display as "Window" in the briefing: "Based on historical patterns, a 30-60 day window before formal restrictions is most likely if current trajectory continues." This is the confidence % mechanism already in the app.

**95 · Briefing personalisation engine**
Every briefing delivered to a client should reference only the signals relevant to their specific assets. Turkey banking risk briefing goes only to clients with Turkey banking exposure. Singapore structure filing briefing goes only to clients with Singapore structures. Build the routing logic now, even if manually executed initially. As volume scales, automate through client profile tagging.

**96 · Jurisdiction comparison view**
A screen showing all monitored jurisdictions side-by-side with their current risk scores across all dimensions. Useful for clients deciding where to move assets. Already started with the country profile, extend to a comparison table: pick two jurisdictions and see their scores across all five risk dimensions simultaneously.

**97 · Historical briefing archive with search**
All briefings should be permanently archived and searchable by the client. Search by: jurisdiction, date range, risk type, asset type, keyword. This allows clients to understand the full history of how a situation developed — critically useful when they need to make a decision and want context. Implement as a simple flat-file JSON store initially.

**98 · Website — interactive risk map**
Replace or supplement the static country list on the website with an interactive SVG world map. Jurisdictions monitored by Mebusan clients light up with their current risk colour (green/amber/red). Hovering shows a one-line status. This makes the intelligence product tangible to a website visitor who is deciding whether to apply. Build using D3.js or a simple SVG map library.

**99 · Secure document exchange portal**
Clients frequently need to share sensitive documents with Mebusan analysts — bank statements, structure diagrams, property documents. Build a zero-knowledge encrypted file upload portal (using client-side encryption before upload). Display as "Secure share" in the app. This removes the need for email, which is the weakest link in the security chain for this client type.

**100 · Analyst-to-client secure messaging thread**
Every client should have a persistent secure messaging thread with their named analyst, visible in the app. Not a chatbot — a real human thread. Messages are encrypted end-to-end. The analyst can push a briefing directly into the thread, add documents, or send a quick note. This is what differentiates Mebusan from every automated monitoring service: a human who knows your situation and sends you a message when something changes. Implement as a message list screen with read receipts. The analyst tool is a web admin panel that feeds into the same thread.

---

## IMPLEMENTATION PRIORITY MATRIX

| Priority | Strategies | Effort | Impact |
|---|---|---|---|
| Immediate | 01, 03, 33, 34, 71, 91, 95 | Low | Critical |
| Month 1 | 02, 19, 27, 37, 44, 92, 93 | Medium | High |
| Quarter 1 | 05, 21, 47, 59, 84, 94, 98 | Medium | High |
| Quarter 2 | 08, 22, 62, 73, 85, 96, 99 | High | Medium |
| Scale | 07, 81, 83, 87, 94, 100 | Very high | Very high |

---

## DATA SOURCE QUICK REFERENCE

| Source | What it provides | Cost | Update frequency |
|---|---|---|---|
| IMF SDDS | Reserve data, FSIs | Free | Monthly |
| BIS Statistics | Cross-border banking | Free | Quarterly |
| OFAC API | SDN list changes | Free | Daily |
| FATF website | AML/greylisting | Free | Plenary-based |
| Bloomberg | FX, rates, spreads | Subscription | Real-time |
| Refinitiv | News, ratings | Subscription | Real-time |
| ACLED | Conflict events | Free/paid tiers | Weekly |
| GDELT | Global events | Free | 15-minute |
| Wise API | FX rates (MTO) | Free | Real-time |
| Numbeo | Cost of living proxies | Free | Crowdsourced |
| ICIJ Leaks DB | Offshore structure names | Free | Updated irregularly |
| Satellite (Planet) | Imagery | Subscription | Daily |
| MarineTraffic | Shipping data | Subscription | Real-time |
| NetBlocks | Internet disruption | Free alerts | Real-time |
| italaw.com | Investor-state disputes | Free | As filed |

---

*Mebusan AI PTE LTD · Singapore · Confidential*

---

# 50 ADDITIONAL STRATEGIES (101–150)

**Compiled April 2026 · Addendum**

---

## SECTION I — DEBANKING & BANKING ACCESS (101–110)

**101 · Debanking risk profiling per client**
Build a debanking risk score for each client based on: industry type, country of origin, transaction pattern, and associated entity types. Use the OCC's preliminary debanking findings (December 2025) as a benchmark for what triggered offboarding at the nine largest US banks. Score each client's profile against these triggers and surface where they are vulnerable to access termination. Not just about protecting assets — about protecting the banking relationship that accesses them.

**102 · Correspondent banking access map per jurisdiction**
Maintain a live map of which major correspondent banks (JPMorgan, Citi, Deutsche Bank, Standard Chartered, HSBC) maintain relationships with local banks in each monitored jurisdiction. When a major correspondent withdraws, local bank access to USD and EUR clearing degrades — sometimes overnight. Source: BIS locational banking statistics, Accuity SWIFT directory, local bank annual reports listing correspondent relationships. Update quarterly.

**103 · Alternative banking pathway pre-identification**
For every monitored jurisdiction, pre-identify at least three alternative banking pathways a client could use if their primary bank loses correspondent access or restricts services. Include: EMI (Electronic Money Institution) options, multi-currency payment platforms (Wise, Airwallex), and regional banks with stable correspondent relationships. Deliver this as a "Contingency Banking Guide" per jurisdiction, updated annually.

**104 · EMI and fintech platform stability monitoring**
Electronic money institutions and fintech platforms (Wise, Revolut, Airwallex, Payoneer) are increasingly used for cross-border access in markets where traditional banking is restricted. Monitor their regulatory standing, capital adequacy (where published), and licence status in each operating jurisdiction. An EMI losing its licence creates immediate access disruption for clients using it as a banking alternative. Source: FCA register, MAS fintech register, CBBank registration databases.

**105 · Dollar clearing access vulnerability by bank**
Some local banks in monitored jurisdictions have only one or two correspondent relationships for USD clearing. Identify which client banks have single-correspondent dollar clearing and flag this as a concentration risk. If that one correspondent withdraws, dollar transactions stop. This is a known pre-crisis pattern in multiple jurisdictions. Source: SWIFT BIC directory, bank annual reports, correspondent banking database providers.

**106 · De-risking timeline tracking per jurisdiction**
Academic and BIS research shows that correspondent banking withdrawal follows a measurable pattern: first, high-risk clients are offboarded; then, high-risk products; then, entire jurisdictions. Build a de-risking phase model for each monitored jurisdiction — identifying where in the withdrawal timeline each country sits. A jurisdiction in Phase 2 (product-level withdrawal) should trigger a Watch for clients with banking there. Source: BIS working paper on de-risking, individual bank press releases, SWIFT transaction data.

**107 · Trade finance access as banking proxy**
When correspondent banks withdraw from a jurisdiction, trade finance (letters of credit, documentary collections) is typically the first product affected. Monitor trade finance availability through ICC (International Chamber of Commerce) Trade Register, local central bank data on trade credit, and exporter association reports. Declining trade finance access precedes general banking access restrictions by 6-18 months.

**108 · CBDC implementation monitoring for banking disruption**
Central Bank Digital Currencies, when implemented, can disintermediate commercial banks and create new transfer mechanisms. Monitor CBDC pilot programmes (BIS CBDC Tracker, Atlantic Council CBDC Tracker) for monitored jurisdictions. A CBDC going live can simultaneously improve direct transfer access while disrupting commercial banking relationships. Particularly relevant for China, UAE, Singapore, and several African markets.

**109 · Stablecoin access as capital flight alternative**
As debanking pressures intensify, commodity traders and wealth holders are increasingly using stablecoins (USDC, USDT) for cross-border value transfer. Monitor: stablecoin on-ramp availability per jurisdiction (which exchanges support fiat→stablecoin conversion locally), regulatory status of stablecoin use in each country, and client exposure to stablecoin-denominated positions. GENIUS Act framework (July 2025) provides a regulatory basis for this monitoring in the US context.

**110 · Payment rail redundancy assessment**
Identify for each client the full set of payment rails they can access: SWIFT (primary), SEPA (if applicable), FedWire/ACH (if USD), local RTGS, fintech rails (Wise, PayPal), and crypto. Score redundancy: a client relying solely on SWIFT for international transfers is more exposed to banking disruption than one with three independent rails. Deliver a "Payment Rail Resilience Score" per client, updated when their banking profile changes.

---

## SECTION J — SUCCESSION & GENERATIONAL RISK (111–118)

**111 · Succession planning gap detection**
For clients with complex multi-jurisdiction asset structures, identify whether a succession plan (will, trust deed, family charter, power of attorney) exists for each asset class and jurisdiction. A high-value property in Dubai with no UAE-compliant will is a succession risk — UAE succession law defaults to Sharia for non-Muslims who have not opted out. Build a succession gap matrix per client: asset type × jurisdiction × document status.

**112 · Generational asset concentration monitoring**
Track which assets in a client's portfolio are held in structures that can only be controlled by the original owner. Single-trustee trusts, sole-director companies, and accounts with no authorised representative create access failure risk on incapacity or death. Flag these structures and recommend resolution. Source: client-provided structure documentation, registered agent correspondence.

**113 · Power of attorney jurisdiction validity**
A power of attorney executed in one jurisdiction may not be valid in another without apostille certification or local notarisation. For clients with assets across multiple jurisdictions, map the validity of their existing POA documents. A gap means that a trusted person cannot act on the client's behalf in that jurisdiction during incapacity. Flag gaps and recommend jurisdiction-specific POA execution.

**114 · Digital asset succession risk**
Clients holding significant cryptocurrency positions face a unique succession problem: if private keys are not passed on correctly, assets are permanently lost. Monitor for: hardware wallet documentation, seed phrase storage, exchange account succession processes, and multi-sig wallet configurations. This is a growing risk category as digital asset values scale. Source: client-provided digital asset inventory, Ledger/Trezor documentation standards.

**115 · Family governance document monitoring**
For multi-generational clients, track the existence, currency, and jurisdiction-appropriateness of: family constitution, investment policy statement, trustee governance protocols, and family council meeting records. Outdated governance documents create disputes and legal vulnerability during generational transitions. Trigger a review reminder when documents are more than three years old or when a jurisdiction's trust/corporate law changes materially.

**116 · Life event monitoring for structure review triggers**
Marriage, divorce, birth of a child, death of a spouse, change of tax residency, or acquisition of a new citizenship all require structure review. Build a life event monitoring protocol: when a client reports or we detect a life event signal, automatically trigger a structure review checklist. Source: client self-reporting in app, public records monitoring (marriage registries, public company director filings).

**117 · Trustee and fiduciary health monitoring**
If a trusted individual (personal trustee, protector, executor) becomes incapacitated, dies, or is subject to regulatory action, the structures they serve are at risk. Monitor public records for changes in trustee status, licensed fiduciary disciplinary actions, and professional trustee company ownership changes. Source: local insolvency registers, professional body directories, company registry director changes.

**118 · Cross-border estate duty and inheritance tax changes**
Inheritance tax regimes change. UK IHT reforms are ongoing. EU succession regulation affects non-EU domiciled assets held by EU residents. Monitor changes to inheritance tax treaties, deemed-domicile rules, and estate duty thresholds for jurisdictions relevant to each client. A change in inheritance tax regime can require immediate structure review. Source: IBFD, Deloitte global private client tax guide (annual).

---

## SECTION K — INTELLIGENCE PRODUCT IMPROVEMENT (119–128)

**119 · Named analyst accountability per briefing**
Every briefing delivered through the app should carry the name, credentials, and regional specialisation of the analyst who prepared it. Not just "your analyst" but "Ahmad Karimi, MENA Specialist, 12 years private intelligence." This builds personal trust, increases the perceived value of the intelligence, and creates accountability. Implement as an analyst profile card attached to each briefing.

**120 · Briefing quality feedback loop**
After each briefing is delivered, allow the client to rate its usefulness (1-3 scale, no more) and optionally note what they would have found more useful. This data feeds directly into briefing calibration: if a client consistently rates currency risk briefings as highly useful but property briefings as less relevant, shift coverage emphasis accordingly. Aggregate feedback also identifies systemic gaps in the intelligence product. Build as a simple in-app feedback card, shown 48 hours after a briefing is opened.

**121 · Scenario modelling — three paths per risk**
For each flagged risk, provide three scenarios: Base case (most likely), Upside (risk resolves), Downside (risk escalates). Each scenario should have: a probability estimate, a timeline, and a specific recommended action for the client. This is how BlackRock's BGRI presents geopolitical risk — not as a binary flag but as a probability-weighted range of outcomes. Implement as a collapsible "Scenarios" section within each briefing.

**122 · Historical analogue matching**
When a new risk pattern emerges, identify the closest historical analogue: "This parallels Nigeria 2016", "This is structurally similar to Turkey 2021." Show the analogue with its timeline and outcome. This gives clients context for how fast these situations typically move and what the likely resolution path looks like. Source: Reinhart-Rogoff crisis dataset, IMF historical banking crisis database, academic early warning literature.

**123 · Signal-to-noise ratio scoring**
Not all signals are equally significant. Build a signal weighting model that distinguishes true early warnings from noise. An interbank rate spike that lasts one day is noise. One that persists for two weeks with parallel reserve drawdown is signal. Track signal persistence (how long a threshold exceedance lasts) and signal confluence (how many independent indicators point the same direction). Only escalate to the client when both persistence and confluence thresholds are met.

**124 · Counterparty risk chain mapping**
For clients with complex structures, map the full counterparty chain: their bank → bank's correspondent → correspondent's regulator → regulator's jurisdiction risk. A seemingly stable local bank can be severely disrupted if its sole USD correspondent is subject to sanctions action. Build a counterparty chain diagram per client and flag when any link in the chain moves into Watch territory.

**125 · Intelligence gap reporting**
Each week, identify what we do not know about a client's situation. Which jurisdictions are data-poor? Which signals are unavailable through current sources? Which asset types lack monitoring coverage? Deliver this as a "Coverage gaps" note to the analyst team and, selectively, to clients — explaining what we are watching and where our visibility is limited. Transparency about limitations is a trust signal.

**126 · Analyst briefing depth tiers**
Not every client needs the same depth of analysis. Build three briefing tiers: Headline (one paragraph, actionable summary), Standard (full briefing with context and timeline), Deep (full briefing plus underlying data, source citations, and analyst methodology notes). Map clients to tiers based on their stated preference from the deep profile and their engagement patterns. Clients who always read to the end should receive Deep tier.

**127 · Regulatory change lead time scoring**
Some regulatory changes give months of warning; others arrive overnight. Build a lead time database for common regulatory change types: FATF greylisting averages 18 months from evaluation to decision. Capital controls in Turkey have historically arrived with less than 48 hours warning. Communicate lead time expectations alongside every regulatory pipeline briefing — so clients understand how much time they realistically have to act.

**128 · Cross-client pattern intelligence**
Without identifying any specific client, aggregate signal patterns across the client base to identify emerging risks: if 40% of clients with Turkey exposure are receiving elevated flags simultaneously, that is a systemic signal worth escalating to all Turkey-exposed clients even those without a client-specific trigger. Build this as an aggregate monitoring layer with strict anonymisation. This makes the intelligence product stronger the more clients it serves.

---

## SECTION L — TECHNOLOGY & SECURITY (129–137)

**129 · End-to-end encryption for all briefing delivery**
All briefings delivered through the app should be encrypted at rest and in transit using client-specific keys. The client holds the decryption key. Even a breach of Mebusan servers should not expose briefing content. Implement using AES-256 with client-side key management. This is not just a security feature — it is a trust signal that distinguishes Mebusan from every generic monitoring service.

**130 · Zero-knowledge profile storage**
Client profile data (jurisdictions, asset types, account details) should be stored in a format where Mebusan analysts can see the structured fields needed to configure monitoring, but cannot reconstruct a full client profile from the stored data. Use field-level encryption where only the client can decrypt their raw profile. This protects against the insider threat that is the real risk in a private intelligence service.

**131 · Secure brief delivery via Signal/encrypted email option**
For clients who prefer not to use the app, offer briefing delivery via: Signal (group or direct), ProtonMail/Tutanota encrypted email, or a dedicated secure email with PGP encryption. Build the delivery system to be channel-agnostic — the briefing is generated once and routed to the client's preferred channel. Track open rates per channel to understand which clients are actively reading.

**132 · Device management and session control**
In the app settings, show the client a list of active sessions (device type, last active, location approximation). Allow one-tap session termination for any listed device. Allow the client to set a session timeout (15 minutes to 24 hours). This is standard in banking apps and critical for a privacy-first intelligence product. Implement using JWT tokens with configurable expiry and a session management API.

**133 · Burner-mode / duress code**
For clients in high-risk jurisdictions, implement a duress code: an alternate PIN that, when entered, shows a clean version of the app with no sensitive data. If a client is compelled to show their phone, the duress code protects them. This feature exists in some encrypted messaging apps and is appropriate for Mebusan's threat model. Also consider a panic wipe: a hardware button combination that immediately deletes local session data.

**134 · Offline briefing cache**
For clients in jurisdictions with unreliable internet (or who are travelling through restricted zones), cache the most recent briefings locally on device, encrypted. The app should be usable offline for reading previously downloaded content. This matters for clients in Turkey, Egypt, or other markets where internet availability is not guaranteed.

**135 · Penetration testing and bug bounty programme**
Schedule quarterly penetration testing of the app, API, and web infrastructure by a specialist firm (Cure53, NCC Group, Bishop Fox). Establish a responsible disclosure policy and consider a private bug bounty programme for security researchers. Publish a brief annual security transparency report — not the findings, but the commitment to the process. This is a trust signal for the client type Mebusan serves.

**136 · Supply chain security for intelligence sources**
The intelligence product is only as secure as its weakest data source. Build a supply chain security assessment for every data feed: who owns it, where is it hosted, what access controls exist, and what happens if it is compromised. Prioritise sources that are: geographically distributed, not dependent on US cloud infrastructure (relevant for clients with US sanctions exposure), and have a track record of operational security.

**137 · Air-gapped analyst workstation for sensitive profiles**
For the highest-risk client profiles (those with sanctions-adjacent exposure, political exposure, or known threat environment), analyst work should be conducted on air-gapped workstations that are not connected to the internet. Briefings are produced offline and uploaded via a dedicated secure transfer mechanism. This is standard practice in corporate intelligence firms handling sensitive mandates.

---

## SECTION M — WEBSITE & MARKETING INTELLIGENCE (138–145)

**138 · Intelligence-led content marketing**
The keremalbayrak.com Signals section and the mebusan.com blog should be driven by genuine intelligence, not generic commentary. Each article should contain at least one specific, verifiable data point that the reader cannot easily find elsewhere. This is what builds credibility with the exact audience Mebusan targets — people who consume serious financial intelligence and can tell the difference between analysis and filler.

**139 · Country risk briefing teasers on website**
Publish a two-paragraph teaser of each jurisdiction risk briefing on the website — enough to demonstrate the quality of the intelligence, not enough to replace the service. Each teaser ends with "Full briefing available to active clients." This creates a concrete demonstration of product quality for prospective clients comparing Mebusan to alternatives.

**140 · Private application referral system**
Mebusan's target client finds services through trusted introductions, not advertising. Build a formal referral programme: existing clients can generate a single-use invitation code. The code unlocks the application process for the referred party and gives the referring client a one-month service credit. Track referral chains to understand the social graph of the client network. This is how Amex Centurion, Black Tomato, and similar private services grow.

**141 · Warrant canary — publish and maintain**
The warrant-canary.html page already exists in the file structure. Ensure it is actually updated regularly (weekly or monthly) with a signed statement that Mebusan has not received any court orders to disclose client information. If the canary stops being updated, sophisticated clients will understand what that means. This is a trust mechanism used by privacy-respecting services like ProtonMail, Mullvad, and Lavabit.

**142 · Press and analyst relationship building**
Private intelligence is a field where reputation is everything. Identify five to ten journalists and analysts who write about offshore wealth, capital controls, and private banking (FT, The Economist, Bloomberg Private Wealth, Euromoney). Build relationships through providing background briefings and data, not seeking coverage. The goal is to be the source that serious financial journalists contact when they need context on a capital control situation — not to be profiled as a company.

**143 · Conference intelligence — attend and monitor**
The Mebusan target client attends: HNWI-focused events (FT Investing for Good, Private Client Investment Summit), family office conferences (STEP, Campden Wealth), and wealth management events (SuperReturn, UHNWI Summit Dubai). Build a conference calendar. Attend selectively with the goal of identifying prospective clients through conversation, not through sponsorship or booths. This is where private clients are met, not through digital advertising.

**144 · Anonymous application friction — intentional design**
The anonymous application path (sc-ob07 in the app) should have slightly higher friction than the standard path — not because we want to discourage it, but because clients who choose this path genuinely need the extra care. Require them to read and acknowledge specific additional privacy notes. Have an analyst call them (via Signal or an intermediary) before activating. The process itself communicates that Mebusan takes this seriously.

**145 · White-label or institutional version planning**
At scale, Mebusan's intelligence infrastructure could serve private banks, family offices, and multi-family offices as a white-label product. The monitoring infrastructure, briefing system, and analyst workflow are identical — only the client-facing branding and delivery mechanism change. Plan the architecture now to support multi-tenant deployment. This multiplies revenue without proportionally multiplying the client management burden.

---

## SECTION N — OPERATIONAL EXCELLENCE (146–150)

**146 · Analyst performance and coverage metrics**
Track for each analyst: average briefing turnaround time, client satisfaction scores, number of signals flagged ahead of public awareness, and jurisdictional coverage depth. Use these metrics not just for performance management but for resource allocation — identify which jurisdictions need deeper coverage and which analysts are stretched. Build as a simple internal dashboard updated weekly.

**147 · Intelligence library — reusable jurisdiction knowledge**
Build an internal library of jurisdiction-specific intelligence that any analyst can draw on: standard structure of each country's banking system, typical capital control mechanism and precedent history, key regulatory bodies and their contact details, and historical crisis timeline per country. This reduces onboarding time for new analysts and ensures consistency in briefing quality. Store in a secure internal wiki with version control.

**148 · Client review cadence — quarterly check-in**
Beyond reactive briefings, schedule a structured quarterly review for each client: does their coverage still match their situation? Have they acquired new assets, changed residency, or restructured? This is also when the deep profile is refreshed. Private banks do this as an AML requirement; Mebusan does it as a service quality standard. Deliver the review as a brief structured report with the analyst's recommendations for coverage changes.

**149 · Regulatory compliance audit trail**
Maintain a complete audit trail of all briefings delivered, all client interactions, and all data accessed for each client. This is both a regulatory requirement in Singapore (under the MAS risk management framework) and a protection against future disputes. Use append-only logging with cryptographic hashing to ensure the trail cannot be retrospectively altered. Store encrypted, with a seven-year retention period.

**150 · Crisis simulation exercises — internal**
Run quarterly simulated crisis scenarios with the analyst team: "Turkey announces capital controls at 3am. Client has $2M in Garanti accounts. What do we do in the next 6 hours?" These exercises identify gaps in the emergency response protocol, test the urgent channel in the app, and ensure analysts know the escalation path. Document findings and update the emergency response playbook after each exercise.

---

## UPDATED PRIORITY MATRIX (including strategies 101–150)

| Priority | Strategies | Notes |
|---|---|---|
| Immediate | 101, 102, 103, 119, 121, 129 | Banking access + product quality |
| Month 1 | 105, 111, 120, 123, 131, 141 | Debanking + succession + security |
| Quarter 1 | 107, 113, 122, 132, 138, 148 | Advanced signals + comms |
| Quarter 2 | 110, 116, 127, 133, 143, 145 | Operational excellence |
| Scale | 128, 137, 140, 144, 149, 150 | Infrastructure + growth |

---

*Mebusan AI PTE LTD · Singapore · Confidential · Total strategies: 150*

---

# 100 ADDITIONAL STRATEGIES (151–250)

**Compiled April 2026 · Second Addendum**

---

## SECTION O — SANCTIONS EXPOSURE & EVASION AWARENESS (151–165)

**151 · Shell company network mapping per jurisdiction**
For clients with holding structures in the same jurisdictions as known sanctions evasion networks, build a map of shell company concentration risk. FATF 2025 report identifies front company networks clustered in: UAE, Cyprus, Malta, Hong Kong, and several Central Asian hubs. When a client's structure shares a registered address, registered agent, or director with known sanctioned-adjacent entities, flag for review. Source: ICIJ Offshore Leaks DB, OpenCorporates, jurisdictional company registries.

**152 · Transshipment jurisdiction monitoring**
Countries regularly used as transshipment hubs in sanctions evasion networks include Turkey, UAE, Armenia, Georgia, Kazakhstan, and Serbia. When a client has banking or trade relationships that pass through these hubs, monitor for elevated enforcement activity that could create secondary disruption. Source: BIS Entity List additions, OFAC advisory notices on transshipment, DOJ indictments referencing transshipment countries.

**153 · Secondary sanctions exposure scoring**
US secondary sanctions can trap non-US entities regardless of direct SDN list exposure. Build a secondary sanctions exposure score for each client based on: proximity of their banking relationships to sanctioned jurisdictions, use of USD in transactions involving countries of concern, and any business relationships in sectors targeted by secondary sanctions (Russian oil, Iranian petrochemicals, North Korean trade). Source: OFAC 50% rule guidance, State Department Caution lists.

**154 · Professional enabler monitoring**
UK NCA identifies "professional enablers" — lawyers, accountants, and fiduciaries who knowingly or inadvertently help structure sanctions-evasive arrangements — as a primary enforcement target for 2025-2026. If a client's registered agent, lawyer, or accountant is subject to regulatory action for professional enabler activity, their associated structures face immediate review risk. Monitor: SRA/FCA regulatory actions, Law Society disciplinary records, ACCA/ICAEW enforcement actions.

**155 · Nominee director and shareholder risk**
When corporate structures use nominees — individuals who act as directors or shareholders on behalf of the true beneficial owner — the integrity of those nominees is a material risk. A nominee who is later discovered to be acting for a sanctioned party can contaminate the associated structure. Monitor nominee service provider compliance records and track any enforcement actions involving nominee arrangements in monitored jurisdictions.

**156 · Asset transfer to family member pattern detection**
FATF and IFI identify the rapid transfer of assets to family members or close associates as a classic pre-sanctions asset concealment pattern. For clients in jurisdictions with elevated sanctions risk (Russia-adjacent, Iran-linked, or high political exposure), monitor for unusual asset transfer patterns. This is not about assuming wrongdoing — it is about identifying when a client's banking relationships may be under scrutiny.

**157 · Cryptocurrency on-chain exposure monitoring**
If a client holds cryptocurrency, monitor their wallet addresses (with consent) for: transactions involving wallets on OFAC SDN list, use of mixers or privacy coins (Monero, Zcash) that are subject to enhanced scrutiny, and interactions with sanctioned exchanges. Source: Chainalysis, TRM Labs, Elliptic (commercial blockchain analytics). This is standard practice at any compliant crypto exchange but absent in most private wealth monitoring.

**158 · Dual-use goods and export control exposure**
For clients with operating businesses that manufacture or trade in products on dual-use goods lists (BIS Commerce Control List, EU Dual Use Regulation), monitor for: new additions to the product categories requiring licences, export destination changes that trigger control requirements, and enforcement actions against competitors in the same sector. FATF notes that export control evasion and sanctions evasion increasingly use the same networks.

**159 · Shadow fleet and maritime sanctions exposure**
The 2025 UK NCA red alert on shadow fleet networks is relevant for clients with shipping, oil trading, or commodity interests that interact with Russian or Iranian cargo. Monitor vessel flagging changes, AIS signal manipulations, and beneficial ownership changes in the maritime sector. Source: Windward AI, MarineTraffic, UKMTO, Pole Star maritime intelligence.

**160 · OFAC 50% rule monitoring**
The OFAC 50% rule means that an entity owned 50% or more by a sanctioned party is itself treated as sanctioned, even if not explicitly listed. For clients with minority stakes in businesses that may have sanctioned-party shareholders, build an ownership chain screening tool. Source: OFAC SDN list with aggregate ownership analysis, Refinitiv World-Check, Moody's Maxsight entity resolution.

**161 · Sanctions wind-down monitoring**
When sanctions programmes are suspended, modified, or terminated — as happened with certain Venezuela designations in 2025 — clients with exposure to those jurisdictions need to understand what becomes permissible and on what timeline. Monitor OFAC General License issuances, EU sanctions modification notices, and OFSI regulatory updates. A sanctions relaxation can be as significant as a tightening for clients wanting to resume or restructure relationships.

**162 · Data security and cross-border data flow restrictions**
The US Bulk Data Rule (fully enforced from July 2025) restricts US persons from sharing sensitive personal data with "countries of concern." For clients with dual nationality or business operations involving US persons and covered countries (China, Russia, Iran, Cuba, North Korea, Venezuela), this creates compliance obligations. Monitor DOJ Data Security Program enforcement actions and guidance updates. Source: DOJ National Security Division, Cleary Gottlieb tracker.

**163 · CFIUS and foreign investment screening exposure**
For clients with US-based investments or business interests, CFIUS increasingly reviews investments from a wide range of countries. Monitor the "fast-track" programme for allied-country investors, new sector designations requiring mandatory filing, and any CFIUS review of existing investments in the client's portfolio. Source: Treasury CFIUS annual report, CFIUS notice filings tracker.

**164 · Russian sanctions evasion network adjacency**
Even clients with no Russia exposure may be affected by Russian sanctions evasion enforcement if their banking relationships or corporate structures are in jurisdictions where Russian networks operate. Identify the three-hop adjacency: does the client's bank have correspondent relationships with banks that have documented Russian sanctions exposure? Source: SWIFT BIC analysis, OFAC enforcement actions naming correspondent banks, Kharon Intelligence.

**165 · Iran conflict sanctions cascades**
The Trump-Xi Beijing summit (May 14-15, 2026) has direct implications for Iran sanctions. If US-China tensions escalate over Iran, secondary sanctions targeting Chinese entities doing business with Iran will be a primary tool. For clients with Hong Kong, mainland China, or Chinese bank relationships, model the cascade effect of expanded Iran-related secondary sanctions. Source: State Department Iran sanctions advisories, Reuters sanctions tracker.

---

## SECTION P — CLIMATE & PHYSICAL RISK (166–175)

**166 · Physical climate risk per property location**
Real estate held in coastal zones, floodplains, or wildfire corridors faces physical climate risk that affects both asset value and insurability. Build a physical risk layer for each monitored property: flood zone designation, wildfire risk score, sea level rise projection at 2050, and storm surge exposure. Source: FEMA flood maps, Jupiter Intelligence physical risk data, RMS ClimateScore Global, Verisk climate models. Integrate into the country risk profile for property assets.

**167 · Insurance availability and premium trend monitoring**
In high-physical-risk markets, insurance withdrawal is the leading indicator of property value pressure. When major insurers exit a market or dramatically raise premiums, it signals that institutional capital is pricing physical risk into the asset. Monitor: Lloyd's of London market withdrawals, State Farm/Allstate US market exits (expanding globally), and reinsurance capacity by region. Source: Swiss Re sigma reports, Munich Re NatCat data.

**168 · Climate stress test per jurisdiction**
Regulators are now requiring banks and insurers to conduct climate stress tests (ECB 2026 thematic stress test includes geopolitical scenarios). When a jurisdiction's major banks perform poorly in climate stress tests, it signals potential credit restriction in climate-exposed sectors including real estate. Monitor: ECB stress test results, Bank of England climate scenario analysis, MAS environmental risk management guidelines.

**169 · Green building code and retrofit obligation monitoring**
Many jurisdictions are introducing minimum energy performance standards that require property owners to retrofit buildings by specific deadlines (EU EPBD requires EPC C or above for rentals by 2030). For clients with property in regulated jurisdictions, build a compliance calendar: which properties require what improvements by when, and what are the penalties for non-compliance. Source: EU EPBD implementation tracker, UK EPC regulations, Singapore Green Mark standards.

**170 · Carbon pricing impact on asset values**
Carbon pricing (EU ETS, UK ETS, Singapore carbon tax) affects the operating costs and valuations of carbon-intensive assets. For clients holding commercial property, industrial assets, or business interests in sectors subject to carbon pricing, monitor: carbon price trends, sector-specific carbon intensity, and upcoming expansion of carbon pricing schemes to new sectors. Source: ICAP carbon market tracker, World Bank carbon pricing dashboard.

**171 · Water scarcity risk for agricultural land**
Agricultural land value in water-stressed regions is increasingly affected by water rights, aquifer depletion, and drought patterns. For clients with agricultural land in the Middle East, North Africa, Australia, or western US, build a water risk score: current water stress index, aquifer depletion rate, and projected precipitation change by 2040. Source: WRI Aqueduct water risk tool, FAO AQUASTAT, World Bank water data.

**172 · Sea level rise and coastal property horizon risk**
For coastal property, the 20-year horizon risk is now a factor in mortgage financing and institutional valuation. Model the expected timeline for current sea level rise projections to affect client properties: flooding frequency, insurance availability, and mortgage market withdrawal. Source: NOAA sea level rise projections, CoastalDEM elevation data, first-street.org risk models.

**173 · Climate refugee and population displacement as property risk**
In regions where climate disruption is creating internal displacement (parts of MENA, South Asia, Sub-Saharan Africa), monitor for property demand shifts. Climate displacement can both increase demand in destination cities and crash demand in origin regions. For clients with property in climate-exposed markets, model the displacement scenario alongside the physical risk scenario. Source: UNHCR displacement data, IOM migration reports, climate migration scenario models.

**174 · Renewable energy infrastructure and land use conflict**
For clients with agricultural land or rural property, monitor government land acquisition programmes for renewable energy infrastructure (solar, wind, transmission). In some jurisdictions, compulsory acquisition powers are being used to facilitate energy transition projects. Source: national planning authority publications, renewable energy development zone designations, infrastructure planning decisions.

**175 · ESG-linked financing terms for client assets**
Assets that meet ESG criteria increasingly access cheaper financing and insurance. Assets that fail ESG criteria face the opposite. For clients with properties or businesses in regulated markets, monitor the evolution of ESG-linked lending standards and flag when a client's assets may become less financeable due to green standards tightening. Source: GFANZ (Glasgow Financial Alliance for Net Zero) standards, ICMA Green Bond Principles, LMA sustainability-linked loan standards.

---

## SECTION Q — ADVANCED SIGNAL SYSTEMS (176–188)

**176 · NLP-based regulatory text monitoring**
Build an NLP pipeline that ingests regulatory gazette text from all monitored jurisdictions, translates it (where needed), and classifies paragraphs into risk categories: banking restriction, capital flow, beneficial ownership, property, sanctions, tax. Surface only paragraphs that match active client profile tags. This eliminates the manual reading overhead while ensuring zero regulatory change is missed. Use a fine-tuned BERT or similar model for classification.

**177 · Earnings call sentiment for banking risk**
Public companies — including banks — hold quarterly earnings calls. NLP sentiment analysis of banking sector earnings calls in monitored jurisdictions provides a forward-looking signal about management confidence, asset quality concerns, and regulatory pressure. When banking CEOs start hedging language about "asset quality trends" or "regulatory engagement", this is a material signal weeks before official data. Source: Refinitiv earnings call transcripts, Seeking Alpha, LSEG Workspace.

**178 · Crowdsourced economic stress signals**
Platforms like Numbeo (cost of living), UberSuggest (search volume), and subreddit activity in local languages capture economic stress at a granular level that official statistics miss or lag. Monitor local language Reddit communities, Facebook groups, and Telegram channels for mentions of bank closures, ATM queues, forex black market, or food price spikes. These signals often precede official data by 4-8 weeks.

**179 · Diplomatic activity monitoring**
Unusual diplomatic activity — emergency consulate closures, ambassador recalls, bilateral meeting cancellations — often signals deteriorating political relationships that will subsequently affect financial access. Monitor: US State Department travel advisory changes, UK FCO advisories, diplomatic appointment tracker. A sudden escalation in diplomatic tension between a client's home country and a jurisdiction where they hold assets is a material flag.

**180 · Legal database monitoring for precedent shifts**
Track court decisions in monitored jurisdictions for decisions that affect property rights, trust validity, corporate structure enforceability, or tax treatment. A single high court decision reversing the tax treatment of offshore structures can affect thousands of clients. Source: BAILII (UK), EUR-Lex (EU), LexisNexis country-specific legal databases. Monitor for decisions within 72 hours of publication.

**181 · NGO and investigative journalism pipeline**
Investigative journalism outlets (ICIJ, OCCRP, Follow the Money, Finance Uncovered) often publish material that moves regulatory action weeks or months later. Build a monitoring pipeline for these publications, classified by jurisdiction and risk type. When a major investigative piece about a client's jurisdiction is published, proactively brief the client on the likely regulatory trajectory. Source: ICIJ, OCCRP, Global Witness, Transparency International investigation tracker.

**182 · IMF Article IV advance calendar**
The IMF publishes its Article IV consultation schedule in advance. When an Article IV review is scheduled for a monitored jurisdiction, pre-brief clients 2-3 weeks before publication: what the IMF is likely to find based on current signals, and what the published findings will mean for banking sector risk. The publication of a negative Article IV assessment can trigger rating agency reviews within weeks. Source: IMF.org consultation calendar.

**183 · MSCI and FTSE Russell index inclusion/exclusion monitoring**
When a country is added to or removed from major equity indices (MSCI Emerging Markets, FTSE Russell), large capital flows follow. Inclusion triggers inflows; exclusion triggers capital flight. Monitor MSCI and FTSE annual reviews and any interim index change announcements. Capital flow shifts of index rebalancing can materially affect currency stability. Source: MSCI.com, FTSE Russell index review calendar.

**184 · Central bank digital currency (CBDC) pilot monitoring**
74 countries are piloting or have launched CBDCs as of 2025 (Atlantic Council tracker). When a monitored jurisdiction announces a CBDC launch, model the implications: does it improve payment access (positive), restrict private banking (negative), or enable new financial surveillance (risk signal for clients with privacy concerns)? Build a CBDC impact template per jurisdiction type. Source: Atlantic Council CBDC Tracker, BIS CBDC research papers.

**185 · Trade credit insurance withdrawal monitoring**
When trade credit insurers (Atradius, Coface, Euler Hermes) restrict coverage for exports to or from a country, it is a leading indicator of institutional risk-off sentiment. These insurers have large research teams and act before public data confirms a deterioration. Monitor: Atradius country reports, Coface country risk assessments, Euler Hermes country grades. A downgrade by two or more trade credit insurers simultaneously = Flag.

**186 · Shipping lane and port disruption monitoring**
For clients with commodity positions, supply chain interests, or trade finance exposure, monitor key shipping lanes: Strait of Hormuz, Red Sea/Bab-el-Mandeb, Suez Canal, Strait of Malacca, Taiwan Strait. Disruption to any of these lanes creates immediate commodity price and supply chain effects. Source: UKMTO advisories, US Fifth Fleet advisories, Lloyd's Market Association Breach clauses, Pole Star maritime intelligence.

**187 · Artificial intelligence governance risk**
For clients with technology businesses operating in multiple jurisdictions, monitor the rapidly evolving AI governance landscape: EU AI Act implementation (high-risk system designations, conformity assessments), China's algorithmic regulation, US executive order implementation. New AI compliance obligations can create material operating costs and market access restrictions. Source: European Commission AI Act tracker, NIST AI Risk Management Framework.

**188 · Supply chain risk mapping for operating businesses**
For clients with operating businesses that depend on international supply chains, build a supply chain risk map: key supplier jurisdictions, concentration in single countries, tariff exposure, and dual-source capability. When tariffs escalate or a key supplier country faces stress, identify the client's specific exposure and timeline for impact. Source: Panjiva/S&P Global supply chain data, USTR tariff tracker.

---

## SECTION R — WEALTH MOBILITY & JURISDICTIONAL ARBITRAGE (189–198)

**189 · Neutral hub jurisdiction monitoring**
Singapore, UAE, Switzerland, and Liechtenstein are frequently cited as "neutral hubs" for wealth management that are relatively insulated from US-China geopolitical pressure. Monitor the ongoing neutral status of these hubs: bilateral relationships with major powers, FATF compliance status, banking sector health, and any signs of political alignment shift. Source: diplomatic tracker, FATF mutual evaluations, bilateral investment treaty updates.

**190 · Tax residency optimisation window monitoring**
Tax residency rules change. Portugal's NHR scheme ended; it introduced a replacement with different terms. UK non-dom rules are being fundamentally restructured. Italy's flat-tax regime continues attracting HNWI inflows. Build a rolling update of the attractiveness and stability of key tax residency destinations, with a specific focus on: rule-change risk, exit tax implications, and treaty network. Source: Ius Laboris country tax guides, KPMG Global Tax Navigator.

**191 · Investment migration programme stability scoring**
Golden visa and citizenship by investment programmes face ongoing pressure from EU institutions and bilateral trade partners. Score each programme's stability based on: EU pressure level, compliance with FATF standards, due diligence quality, programme modification frequency, and processing time trends. Source: Investment Migration Insider, Henley & Partners index, OECD automatic exchange assessments.

**192 · Wealth migration flow data**
Track where HNWI wealth is actually moving: millionaire migration reports (Henley, New World Wealth, Morgan Stanley), real estate purchase data by buyer nationality, residency permit statistics by country. This tells you where conditions are improving and where they are deteriorating from the perspective of people with skin in the game. Clients looking to diversify jurisdictions benefit from knowing current destination preferences. Source: Henley Private Wealth Migration Report (annual), New World Wealth migration tracker.

**193 · Bank account opening success rate by jurisdiction**
Maintain a constantly updated database of which banks in which jurisdictions are currently opening accounts for non-residents, which document packages are required, and what the typical rejection rate and timeline is. This is ground truth from the compliance trenches that is not published anywhere officially. Build from: registered agent networks, legal partner feedback, client experience reports.

**194 · Dual taxation agreement arbitrage monitoring**
When DTAs are renegotiated or terminated, new arbitrage opportunities or traps emerge. Monitor DTA modification announcements and model the implications for clients with cross-border income streams or asset structures that rely on treaty protection. The OECD MLI (Multilateral Instrument) continues modifying thousands of existing treaties simultaneously. Source: OECD MLI tracker, IBFD DTA database, UN Tax Committee publications.

**195 · Free zone and special economic zone evolution**
Free zones in UAE, Saudi Arabia, Oman, Egypt, and other emerging markets are continuously evolving their regulatory frameworks, ownership rules, and tax treatment. For clients with business interests structured through free zones, monitor: changes to 100% foreign ownership rules, VAT applicability changes, labour law modifications, and free zone licence category expansions. Source: individual free zone authority publications, Chambers Global free zone guides.

**196 · Wealth hub geopolitical alignment risk**
As US-China tensions drive geopolitical fragmentation, jurisdictions that previously maintained relationships with both blocs may be forced to choose alignment. For clients holding significant assets in jurisdictions that sit between competing blocs (UAE, Singapore, Turkey, Saudi Arabia), model the scenario where forced alignment restricts one side's capital access. Source: geopolitical alignment indices, diplomatic relationship databases.

**197 · Family office location trends — where they are moving**
Track where family offices are establishing new or additional offices: Singapore (accelerating), UAE (sustained), Luxembourg (European hub), Liechtenstein (privacy-focused), and Miami (US-base alternative). This intelligence signals where regulatory and tax conditions are improving and where they are deteriorating. Source: Campden Wealth family office surveys, family office directory additions, EY/Deloitte family office location studies.

**198 · Outbound investment restriction monitoring**
China, India, and several other countries impose restrictions on outbound investment by their nationals. For clients with these nationalities who hold assets abroad, monitor changes to outbound investment rules, reporting requirements, and enforcement activity. China's SAFE (State Administration of Foreign Exchange) quotas and reporting rules are particularly active in this space. Source: KPMG China tax newsletter, individual country central bank outbound investment regulations.

---

## SECTION S — CLIENT INTELLIGENCE DEEPENING (199–210)

**199 · Client context memory system**
Every interaction, preference signal, and reported change in a client's situation should be stored and surfaced to the analyst before each briefing. Build a client context timeline: "Client mentioned in June 2025 that they were considering selling the Dubai property. Briefing in July about AML changes affected this plan. Note in August: decision deferred." This is standard in premium advisory services but absent in most intelligence platforms. Implement as a timeline view in the analyst admin panel.

**200 · Life change signal detection from briefing engagement**
Track changes in client engagement patterns: a client who normally reads briefings within 2 hours suddenly stops opening them for 10 days. This can indicate: travel to a restricted jurisdiction, life event, or loss of phone access. Build an engagement monitoring dashboard for analysts. An extended engagement gap for a client in a high-risk jurisdiction triggers a welfare check through their preferred contact channel.

**201 · Multi-jurisdiction exposure correlation matrix**
For clients with assets across five or more jurisdictions, build a correlation matrix showing which risk events tend to occur together. Turkey banking stress and UAE property market both tend to react to US dollar strength. Singapore and Hong Kong regulatory changes often follow each other within 6-12 months. This allows anticipation: when Turkey flags, pre-brief on UAE second-order effects.

**202 · Client objective tracking over time**
Clients' objectives evolve: what started as "protect my Dubai property" may become "restructure for succession" or "prepare to exit Turkey entirely." Track stated and implied objectives from every client interaction and explicitly update the coverage configuration when objectives shift. Build as a structured objective log with quarterly analyst review.

**203 · Peer group anonymised benchmarking**
Without identifying any specific client, show clients how their risk profile compares to anonymised peers with similar asset configurations: "Clients with similar Turkey banking exposure have taken the following actions over the past 6 months." This peer comparison is a powerful motivator for action and is standard in financial advisory but absent in intelligence services.

**204 · Pre-emptive briefing — anticipated client questions**
Analysts who know a client's situation can anticipate questions before they're asked. When a major event occurs in a monitored jurisdiction, pre-empt the client's question: "Before you call: here is what this means for your specific structure." This changes the service relationship from reactive to genuinely proactive — the intelligence arrives before the client's morning news cycle.

**205 · VIP client protocol — ultra high risk situations**
For clients whose situations cross into genuinely high-risk territory (sanctions threat, active capital controls, political persecution risk), build an escalated service protocol: direct mobile number for the senior analyst, 24-hour monitoring, daily briefings, and a pre-agreed emergency contact procedure. This protocol should exist as a documented service tier even before it is needed.

**206 · Client-supplied intelligence integration**
Clients in their home markets often have ground-level intelligence that Mebusan's remote monitoring cannot capture: conversations with local bankers, gossip at a dinner party, a tip from a government contact. Build a secure way for clients to submit intelligence observations through the app — a "What I'm seeing" field that goes directly to the analyst team. This creates a two-way intelligence relationship rather than one-way briefing delivery.

**207 · Anticipatory document preparation**
When a risk situation is escalating, pre-prepare documents that a client may need in a crisis: a summary of their account details and correspondent bank chains; a one-page description of their structure that can be given to a new lawyer in any jurisdiction; a list of key contacts. Store these encrypted in the client portal. Build as a "Emergency Document Pack" feature in the app, downloadable via secure authentication.

**208 · Exit velocity modelling per asset**
For each monitored asset, model the realistic time-to-exit under current market conditions: how long does it take to sell a property in this jurisdiction and move the proceeds out? How long to liquidate a banking position given current transfer restrictions? How long to restructure a corporate structure? This exit velocity model tells clients whether they have days, weeks, or months to act — and how to prioritise.

**209 · Relationship mapping — who knows whom**
Build a relationship map for each client: who their key local advisors are in each jurisdiction, which banks they use, which law firms, which registered agents. When a relationship in this map becomes stressed (adviser under investigation, bank facing restrictions), the flag goes immediately to the analyst with the client relationship context to understand the impact. This is the operational intelligence layer that turns monitoring into actual protection.

**210 · Scenario pre-positioning sessions**
Quarterly, the analyst conducts a structured "what if" conversation with the client: "What would you do if Turkey announced capital controls tomorrow? Who would you call? What assets would you move first?" This is not about predicting specific events — it is about building the mental model so clients can act quickly when signals escalate. Document the outputs as a client contingency plan, updated annually.

---

## SECTION T — APP FEATURES TO BUILD (211–225)

**211 · Signal feed — always-on chronological intelligence stream**
A live, reverse-chronological feed of signals relevant to the client's specific profile, below the threshold for a full briefing. Individual data points that don't yet constitute a briefing but are worth knowing: "TRY parallel premium: 6.1% (was 5.9% yesterday)", "Dubai DLD transaction volume: -12% vs. last month", "MAS issued circular on UBO deadlines." This gives clients the feeling of continuous monitoring, not just episodic briefings. Display as a scrollable feed, similar to a financial data terminal.

**212 · Document vault — encrypted client document storage**
A zero-knowledge encrypted document storage area within the app where clients can securely store: structure diagrams, property title documents, bank correspondence, passports, and succession documents. Only the client can decrypt. The analyst can see that documents exist but not their content unless the client explicitly shares them. Display as a secure files section with folder organisation by jurisdiction.

**213 · Custom alert threshold per asset**
Allow clients to set their own notification threshold per asset: "Alert me if the Turkey banking risk score exceeds 4/5", "Alert me only if there is an active capital control signal, not general risk elevation." This gives sophisticated clients control over their notification volume without missing critical events. Build as a per-asset settings section within the watchpoints screen.

**214 · Secure direct message to analyst — with read receipts**
A persistent secure messaging thread with the named analyst, built into the app. Not a chatbot. The analyst uses a web admin tool to send messages; the client receives them in the app. Messages are encrypted. Read receipts show when the analyst's message was opened. The thread history is permanent and searchable. This is the central communication channel that replaces email for all sensitive matters.

**215 · Jurisdiction explorer — compare up to three**
A comparison screen that lets clients pick two or three jurisdictions and see them side-by-side across all five risk dimensions: banking, currency, regulatory, political, property. Useful for clients deciding where to diversify or where to exit. Display as a table with colour-coded risk bars. Include: current score, 90-day trend direction, and one-line status note per dimension.

**216 · Briefing archive — full searchable history**
All briefings ever delivered are permanently stored and searchable in the app. Search by: date, jurisdiction, risk type, keyword. Useful when a client needs to reconstruct a decision timeline or demonstrate to an adviser that they were warned about a risk. Store as compressed encrypted JSON, displayed as a formatted list with preview snippets.

**217 · Pre-crisis action checklist per jurisdiction**
A jurisdiction-specific, pre-populated checklist of actions a client should take before a crisis materialises: "Before Turkey capital controls: [list of steps]." The client can mark items as complete, and the analyst can see progress. This gamifies preparation and ensures nothing is missed under time pressure. Display as an interactive checklist within the country risk profile screen.

**218 · Multi-language support — Arabic, Turkish, French**
Mebusan's target clients include Arabic speakers (Gulf), Turkish speakers (Turkey, diaspora), and French speakers (West Africa, North Africa, francophone Europe). Build the app UI in these three languages plus English. Briefings remain in English initially, but navigation, labels, and system messages should be localised. Use i18n framework from the start rather than retrofitting later.

**219 · Biometric re-authentication for sensitive actions**
For actions like downloading documents, viewing account details, or sending a message to the analyst, require biometric re-authentication (Face ID/Touch ID). This is the "step-up authentication" pattern used by premium banking apps. Implement using the Web Authentication API (WebAuthn) for the web version and device biometric APIs for the native app version.

**220 · Scheduled briefing timing preferences**
Allow clients to specify when they want to receive weekly digests and non-urgent updates: "Monday mornings before 8am", "Never on weekends", "Only on weekdays". This respects the client's time zones and working patterns. Emergency alerts bypass this preference. Build as a notification scheduling system with timezone support.

**221 · Analyst availability indicator**
Show the client when their named analyst is active (green dot) vs. in a review session vs. out of office. For non-emergency communication, this sets expectations. For emergency communication, the out-of-office triggers automatic escalation to the duty analyst. Display as a subtle status indicator next to the analyst's name in the message thread.

**222 · Risk trajectory charts — 90-day view**
For each monitored asset, show a sparkline chart of the risk score over the past 90 days. A flat line at 2 = no change. A rising line from 2 to 4 over 6 weeks = escalating risk requiring attention. This visual history tells clients how fast a situation is moving and where it was when they onboarded. Display within each country risk profile screen.

**223 · Coverage audit — what are we not monitoring?**
A screen that shows, for a client's stated asset profile, what coverage gaps exist: "You mentioned agricultural land in Turkey — we are not currently monitoring Turkish land law changes for you. Add to coverage?" This converts the intelligence gap into a service expansion opportunity and ensures clients know what is and isn't covered. Display as a periodic notification and as a dedicated audit screen.

**224 · Referral tracking and reward**
When an existing client refers a new applicant through the referral code system, track: who was referred, when they applied, when they activated, and what credit the referring client has earned. Display the referring client's total credits and redemption status in their profile screen. This makes the referral programme visible and rewards action.

**225 · In-app jurisdiction news feed**
For each monitored jurisdiction, surface the three most relevant news items from the past 24 hours, filtered to the client's asset types. Not general news — only stories that mention: banking, capital controls, property law, tax, sanctions, or political stability in their specific countries. Pull from news API (NewsAPI, GDELT, or Refinitiv), filter by jurisdiction and topic, rank by relevance. Display as a collapsible "Latest" section below the briefing cards on the home screen.

---

## SECTION U — WEBSITE IMPROVEMENTS (226–235)

**226 · Interactive risk methodology page**
Build a dedicated page explaining exactly how Mebusan calculates risk scores: what signals are tracked, how they are weighted, what the thresholds mean, and what triggers a briefing vs. a flag vs. a critical alert. This is transparency that builds trust with sophisticated clients who want to understand the product they are paying for. Include a worked example using a fictional client profile.

**227 · Public signal archive — last 30 days**
Publish a rolling 30-day archive of jurisdictional risk level changes on the website, with one-sentence explanations. No client data. Just: "Turkey: elevated to Watch on April 14 due to parallel rate premium crossing 5%." This demonstrates that the monitoring is real, current, and specific — and creates a reason for prospective clients to return to the website regularly.

**228 · Client testimonial system — anonymous format**
Private clients cannot be named. Build a testimonial system that captures anonymous case summaries: "A client with property in the UAE and banking in Turkey was briefed on the capital control signal six weeks before formal restrictions were announced. They moved their position in week three." No names. Just outcomes. These case summaries are the most powerful marketing tool available.

**229 · Analyst profile pages on website**
Each analyst has a brief public profile: regional expertise, background (without identifying previous employers), languages spoken, and sample briefing topics. This humanises the service and answers the key question every prospective client has: who is actually reading my situation and what do they know? Keep profiles factual and understated — not promotional.

**230 · Pricing transparency upgrade**
The current pricing page has a five-question questionnaire. Add: a comparison table showing what each tier includes vs. does not include; a simple cost-per-jurisdiction calculator; and a "most clients in your situation choose" recommendation engine. Sophisticated clients want to understand what they are getting before they apply. Friction reduction at the pricing stage increases application completion rates.

**231 · FAQ depth — real questions, real answers**
The current FAQ covers general questions. Upgrade to cover: "Can I use Mebusan if I hold assets in a sanctions-listed country?", "What happens if my named analyst leaves?", "How quickly will I receive a briefing in a genuine emergency?", "Do you share information between clients?", "What is your process if you discover a client's structure poses a compliance risk?" These are the real questions sophisticated clients have.

**232 · Blog content calendar — 52 weeks planned**
Commission or write one substantive intelligence article per week, planned 12 weeks ahead. Topics drawn from: current events in monitored jurisdictions, regulatory pipeline updates, historical crisis analyses, jurisdiction profiles, and interview-style pieces with independent experts. The keremalbayrak.com Signals section supplements this — each article drives traffic back to mebusan.com apply. SEO target: own the search term "capital control signals" in key jurisdictions.

**233 · Application portal UX improvement**
The current apply.html has seven steps. Analyse where applicants drop off (implement heat map tracking with a lightweight analytics tool like Plausible). For each drop-off point, identify the friction and reduce it: shorter steps, clearer progress indication, ability to save and resume, and explicit "what happens next" messaging after submission.

**234 · Jurisdiction coverage map — interactive**
An SVG world map where monitored jurisdictions light up with their current risk colour. Hover reveals a one-line status. Click opens a country profile preview with the option to learn more. This is the most powerful single element the website could add — it makes the intelligence product tangible in five seconds. Build with D3.js, update risk colours from a simple JSON file that analysts update weekly.

**235 · Signal subscription — email digest for prospects**
Prospective clients who are not ready to apply can subscribe to a weekly email digest: one paragraph per relevant jurisdiction covering that week's most significant signal. No client-specific intelligence. Just the market-level signal layer. This keeps Mebusan top-of-mind for the right people and converts warm leads over time. Build using Resend or Postmark, with explicit GDPR-compliant opt-in.

---

## SECTION V — ANALYST TOOLS & OPERATIONS (236–245)

**236 · Analyst briefing templates by situation type**
Build a library of briefing templates for common situation types: capital control warning, regulatory deadline, property law change, sanctions addition, banking access restriction, succession gap identified. Each template has a standard structure, suggested data points to fill, and example language. This reduces analyst drafting time and ensures consistency in briefing quality across different analysts and situations.

**237 · Source confidence scoring**
Each signal used in a briefing should carry a source confidence score: Official (central bank data, government gazette) = 5/5. Commercial (Bloomberg, Reuters) = 4/5. Analytical (consultancy reports, law firm updates) = 3/5. OSINT (social media, local press) = 2/5. Unverified (anonymous tips, single-source) = 1/5. Briefings should only cite signals above 3/5 unless explicitly flagged as low-confidence. Display the aggregate confidence score of each briefing as a quality indicator.

**238 · Multi-analyst collaboration on complex briefings**
For clients with assets across five or more jurisdictions requiring expert knowledge in multiple regions, enable multi-analyst collaboration: a primary analyst manages the client relationship, but specialist analysts contribute sections. Build a co-authorship workflow in the admin panel with section-level review and approval. The client sees one seamless briefing — the analysts coordinate the content.

**239 · Briefing publication and distribution workflow**
Build a four-stage workflow for every briefing: Draft → Senior Review → Client Delivery → Archive. Senior review is mandatory for all Flag and Critical-level briefings. Standard briefings can be expedited but still require a quality check. Track average time from signal detection to client delivery — the target is under 4 hours for Watch-level briefings, under 1 hour for Flag-level.

**240 · Client profile version control**
Every change to a client's profile (new asset, changed jurisdiction, updated contact method, revised succession document status) should be version-controlled with a timestamp and the analyst who made the change. This creates an audit trail and allows the team to understand how a client's situation evolved. Build as an append-only log with diff display — similar to Git for client profiles.

**241 · Automated signal ingestion pipeline**
Build automated ingestion for the highest-value, most frequently updated signals: OFAC SDN list (daily diff), FATF watch list (quarterly), SWIFT country risk status (quarterly), central bank reserve data (monthly), parallel rate tracking (daily via MTO APIs). The automation reduces the manual monitoring burden and ensures signals are never missed due to human oversight. Alert analysts only when thresholds are crossed.

**242 · Internal knowledge base — jurisdiction intelligence library**
Maintain an internal wiki of everything Mebusan knows about each jurisdiction: banking system structure, historical crisis events, key contacts and advisers, regulatory body names and contact details, typical document requirements for account opening. New analysts are onboarded through this library; existing analysts contribute to it. This is the institutional knowledge that makes Mebusan more valuable with every passing month.

**243 · SLA (Service Level Agreement) monitoring**
Track internal service level performance: time-to-briefing for Flag events, time-to-respond for client messages, time-to-process new applications, and briefing accuracy rate (signals that turned into confirmed events). Publish an annual internal SLA report. Use it to identify where the service is underperforming and direct resources accordingly.

**244 · On-call duty analyst rotation**
Outside business hours, clients in genuine emergencies need to reach a human. Build a duty analyst rotation: one analyst is on call each evening and weekend, with a dedicated emergency line (Signal or encrypted voice). The duty analyst has access to all client profiles and the ability to send urgent briefings. The on-call schedule is visible to all analysts and updated weekly.

**245 · After-action review for confirmed risk events**
When a risk event that Mebusan was monitoring actually materialises (a capital control announcement, a regulatory change, a sanctions addition), conduct a structured after-action review: how early did we detect the signal? How much warning did clients receive? What could have been detected earlier? These reviews drive systematic improvement in the intelligence methodology and are documented in the internal knowledge base.

---

## SECTION W — LONG-TERM PLATFORM VISION (246–250)

**246 · Mebusan Intelligence API**
At scale, other wealth managers, private banks, and family office platforms will want to integrate Mebusan's risk scoring into their own systems. Build an intelligence API: a JSON endpoint that returns current risk scores, active signals, and briefing summaries for any monitored jurisdiction. Rate-limited, authenticated, and priced per query. This creates a B2B revenue stream alongside the direct client service. Document with OpenAPI spec.

**247 · Collective intelligence — client network effects**
As the client base grows, aggregate anonymised signals from clients become intelligence in their own right: where are clients experiencing banking friction? Which jurisdictions are seeing the most account enquiries? This collective intelligence layer makes the product more valuable the larger it gets — and it is something no individual client can replicate. Build anonymised aggregation with strict privacy controls.

**248 · Mebusan Lab — experimental intelligence methods**
Allocate 10% of analyst time to testing new signal sources and methodologies. Current candidates: shipping data for economic proxies; satellite imagery for property market monitoring; dark web monitoring for financial system stress indicators. Document every experiment: hypothesis, method, finding, and whether to operationalise. This is the R&D function of the intelligence product.

**249 · Sovereign intelligence partnership programme**
The intelligence Mebusan produces about financial system stress, capital control risk, and cross-border wealth flows is valuable to: financial stability researchers, central banks studying capital flight, and multilateral institutions monitoring emerging market risk. Build an anonymised data sharing programme with selected research partners that generates academic credibility and refines the methodology. Source: BIS research partnerships, IMF surveillance collaboration, academic finance departments.

**250 · Ten-year vision: Mebusan as the Bloomberg Terminal for private wealth risk**
The ultimate product vision is a real-time intelligence platform that any HNWI or their adviser can access to understand the risk landscape for their specific asset configuration — not generic country reports, but personalised, signal-driven, analyst-verified intelligence delivered the moment it matters. The 250 strategies in this document are the building blocks. The architecture already exists in the app and website. The question is execution pace and the depth of the analyst team behind it.

---

## CUMULATIVE PRIORITY MATRIX (strategies 1–250)

| Tier | Strategies | Time horizon |
|---|---|---|
| Foundation | 1, 19, 33, 34, 91, 101, 102, 129, 176, 211, 241 | Already building |
| Core product | 05, 21, 121, 122, 177, 199, 214, 222, 234, 239 | 0–3 months |
| Differentiation | 83, 94, 157, 178, 200, 208, 215, 227, 237, 246 | 3–9 months |
| Scale | 128, 181, 193, 203, 228, 244, 247, 249, 250 | 9–24 months |

---

*Mebusan AI PTE LTD · Singapore · Confidential · Total strategies compiled: 250*
