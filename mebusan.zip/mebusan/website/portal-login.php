<?php
/**
 * Mebusan · Portal Login
 * Client enters MB-XXXX-XXXX + email. If they match an active client, session is created.
 */
require_once __DIR__ . '/config.php';
session_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cid   = strtoupper(trim($_POST['client_id'] ?? ''));
    $email = strtolower(trim($_POST['email'] ?? ''));

    // Basic format check
    if (!preg_match('/^MB-[A-Z0-9]{4}-[A-Z0-9]{4}$/', $cid)) {
        $error = 'Invalid client ID format.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email.';
    } else {
        $f = MB_DATA_DIR . '/clients.json';
        $match = null;
        if (file_exists($f)) {
            $all = json_decode(file_get_contents($f), true) ?: [];
            foreach ($all as $c) {
                if ($c['id'] === $cid && strtolower($c['email'] ?? '') === $email && ($c['status'] ?? '') === 'active') {
                    $match = $c; break;
                }
            }
        }
        if ($match) {
            $_SESSION['client_id']   = $match['id'];
            $_SESSION['client_tier'] = $match['tier'];
            $_SESSION['client_ts']   = time();
            header('Location: portal.html'); exit;
        } else {
            $error = 'No matching active account.';
            sleep(1);
        }
    }
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>Client sign in · Mebusan</title>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&family=Inter:wght@300;400&family=DM+Mono:wght@300;400&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#060504;color:#e8e2d4;font-family:'Inter',sans-serif;font-weight:300;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
nav{position:fixed;top:0;left:0;right:0;padding:16px 32px;border-bottom:.5px solid rgba(232,226,212,.08)}
.logo{font-family:'Josefin Sans',sans-serif;font-weight:300;letter-spacing:.38em;font-size:12px;color:#e8e2d4;text-decoration:none}
.box{width:100%;max-width:400px;border:.5px solid rgba(232,226,212,.1);padding:48px 36px}
h1{font-size:22px;font-weight:300;letter-spacing:-.02em;margin-bottom:8px}
.sub{font-size:12.5px;color:#7a7568;margin-bottom:28px;line-height:1.7}
.field{margin-bottom:18px}
.label{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.14em;text-transform:uppercase;color:#7a7568;margin-bottom:8px;display:block}
input{width:100%;background:rgba(232,226,212,.03);border:.5px solid rgba(232,226,212,.14);color:#e8e2d4;font-family:'Inter',sans-serif;font-weight:300;font-size:14px;padding:12px 14px;outline:none}
input:focus{border-color:rgba(232,226,212,.3)}
input.id{font-family:'DM Mono',monospace;letter-spacing:.1em;text-transform:uppercase}
button{width:100%;background:#e8e2d4;color:#060504;border:none;font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.14em;text-transform:uppercase;padding:13px;margin-top:8px;cursor:pointer}
button:hover{background:#d4cfc3}
.err{font-family:'DM Mono',monospace;font-size:10px;color:#c8a03a;margin-top:16px;text-align:center;letter-spacing:.05em}
.bottom{text-align:center;margin-top:24px;padding-top:20px;border-top:.5px solid rgba(232,226,212,.05)}
.bottom a{font-family:'DM Mono',monospace;font-size:9.5px;color:#7a7568;letter-spacing:.1em;text-transform:uppercase;text-decoration:none}
.bottom a:hover{color:#e8e2d4}
</style>
</head>
<body>
<nav><a href="/" class="logo">MEBUSAN</a></nav>
<form method="post" class="box">
  <h1>Client access</h1>
  <div class="sub">Enter your client ID and email.</div>
  <div class="field">
    <label class="label">Client ID</label>
    <input class="id" type="text" name="client_id" placeholder="MB-XXXX-XXXX" required autofocus maxlength="11" value="<?= htmlspecialchars($_POST['client_id'] ?? '') ?>">
  </div>
  <div class="field">
    <label class="label">Email</label>
    <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
  </div>
  <button type="submit">Sign in</button>
  <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <div class="bottom">
    <a href="apply.html">Not a client? Apply →</a>
  </div>
</form>
</body>
</html>
