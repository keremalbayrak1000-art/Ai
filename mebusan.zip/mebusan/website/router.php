<?php
/**
 * keremalbayrak.com/router.php
 * Handles /reading/slug URLs.
 * Serves keremalbayrak.html BUT with correct per-article meta injected
 * in the <head> BEFORE JavaScript runs.
 * Google's first crawl sees the real title, description, og:image.
 * Human visitors get the full SPA after JS loads.
 */

$slug    = trim($_GET['slug'] ?? '', '/- ');
$baseUrl = 'https://keremalbayrak.com';
$imgBase = 'https://mebusan.com/api/og-image.php';

// ── Article index — title → meta ──────────────────────────────
// Mirrors the PRE array in keremalbayrak.html.
// Add new articles here as they're written.
$ARTICLES = [
  'how-capital-controls-are-signalled-months-before-they-arrive' => [
    'title' => 'How capital controls are signalled months before they arrive',
    'deck'  => 'The pattern that precedes capital control imposition is consistent across historical cases and observable in public data long before any formal announcement.',
    'cat'   => 'financial',
    'date'  => '2026-04-18',
  ],
  'what-the-ftx-collapse-looked-like-six-weeks-before-it-happened' => [
    'title' => 'What the FTX collapse looked like six weeks before it happened',
    'deck'  => 'The on-chain signals were present and observable weeks before FTX suspended withdrawals.',
    'cat'   => 'technology',
    'date'  => '2026-04-15',
  ],
  'russia-january-2022-the-signals-that-were-visible-six-weeks-before-the-freeze' => [
    'title' => 'Russia January 2022: the signals that were visible six weeks before the freeze',
    'deck'  => 'On-chain data and European property registries were already showing elite capital movement in January 2022.',
    'cat'   => 'geopolitical',
    'date'  => '2026-04-12',
  ],
  'lebanon-2018-a-banking-collapse-that-announced-itself-eighteen-months-early' => [
    'title' => 'Lebanon 2018: a banking collapse that announced itself eighteen months early',
    'deck'  => 'The Lebanese banking collapse was one of the most thoroughly telegraphed financial crises of the modern era.',
    'cat'   => 'financial',
    'date'  => '2026-04-10',
  ],
  'fatf-grey-listing-the-practical-consequences-for-assets-in-affected-jurisdictions' => [
    'title' => 'FATF grey listing: the practical consequences for assets in affected jurisdictions',
    'deck'  => 'When the Financial Action Task Force grey-lists a jurisdiction, the consequences for assets held there extend well beyond the headlines.',
    'cat'   => 'regulatory',
    'date'  => '2026-04-08',
  ],
  'sovereign-debt-deterioration-what-the-indicators-show-before-markets-respond' => [
    'title' => 'Sovereign debt deterioration: what the indicators show before markets respond',
    'deck'  => 'Sovereign debt crises rarely arrive without warning. The yield curve, reserve levels, and external financing metrics tell a coherent story months before markets price the risk.',
    'cat'   => 'markets',
    'date'  => '2026-04-05',
  ],
  'beneficial-ownership-registers-what-has-changed-and-what-it-means-for-existing-structures' => [
    'title' => 'Beneficial ownership registers: what has changed and what it means for existing structures',
    'deck'  => 'The global push toward beneficial ownership transparency has accelerated materially.',
    'cat'   => 'regulatory',
    'date'  => '2026-04-02',
  ],
  'uae-regulatory-evolution-what-vara-and-cbuae-changes-mean-in-practice' => [
    'title' => 'UAE regulatory evolution: what VARA and CBUAE changes mean in practice',
    'deck'  => 'The UAE has positioned itself as a serious financial hub but the regulatory environment is evolving faster than most clients track.',
    'cat'   => 'regulatory',
    'date'  => '2026-03-28',
  ],
  'information-asymmetry-and-why-it-defines-private-wealth-risk' => [
    'title' => 'Information asymmetry and why it defines private wealth risk',
    'deck'  => 'The difference between wealth that survives geopolitical disruption and wealth that does not is almost never the quality of the underlying assets.',
    'cat'   => 'geopolitical',
    'date'  => '2026-03-20',
  ],
  'nigerias-naira-eighteen-months-of-signals-before-the-2023-devaluation' => [
    'title' => "Nigeria's naira: eighteen months of signals before the 2023 devaluation",
    'deck'  => 'The naira devaluation of 2023 was eighteen months in the making. The CBN data told the story clearly for anyone reading it.',
    'cat'   => 'financial',
    'date'  => '2026-03-15',
  ],
  'crs-and-what-common-reporting-standard-expansion-means-for-offshore-accounts' => [
    'title' => 'CRS and what common reporting standard expansion means for offshore accounts',
    'deck'  => 'The Common Reporting Standard now covers over 100 jurisdictions. The information that flows between tax authorities is more full than most account holders appreciate.',
    'cat'   => 'regulatory',
    'date'  => '2026-03-10',
  ],
  'the-swiss-banking-system-what-the-credit-suisse-collapse-revealed-about-concentration-risk' => [
    'title' => 'The Swiss banking system: what the Credit Suisse collapse revealed about concentration risk',
    'deck'  => 'The Credit Suisse rescue revealed structural vulnerabilities that remain relevant for clients with significant Swiss banking exposure.',
    'cat'   => 'banking',
    'date'  => '2026-01-18',
  ],
  'turkey-reading-the-liras-trajectory-through-central-bank-policy-signals' => [
    'title' => "Turkey: reading the lira's trajectory through central bank policy signals",
    'deck'  => 'The Turkish lira has been in a persistent depreciation cycle. Understanding the CBRT policy posture is essential for assessing the pace and depth of that cycle.',
    'cat'   => 'financial',
    'date'  => '2026-01-03',
  ],
  'the-argentine-cycle-what-repeated-currency-crises-teach-about-signal-reliability' => [
    'title' => 'The Argentine cycle: what repeated currency crises teach about signal reliability',
    'deck'  => 'Argentina has gone through the capital control cycle multiple times. The signal pattern is consistent enough to be considered a template.',
    'cat'   => 'financial',
    'date'  => '2026-02-15',
  ],
  'wealth-and-jurisdiction-why-diversification-is-not-just-a-financial-concept' => [
    'title' => 'Wealth and jurisdiction: why diversification is not just a financial concept',
    'deck'  => 'The logic of diversification applies to jurisdictions as clearly as it applies to asset classes. The practice lags significantly behind the principle.',
    'cat'   => 'financial',
    'date'  => '2025-12-12',
  ],
];

// ── Also pull from generated articles cache ────────────────────
$cacheFile = __DIR__ . '/../cache/ka/articles.json';
if (file_exists($cacheFile)) {
    $cached = json_decode(file_get_contents($cacheFile), true);
    foreach ($cached['articles'] ?? [] as $art) {
        if (!empty($art['title'])) {
            $s = slugify($art['title']);
            if (!isset($ARTICLES[$s])) {
                $ARTICLES[$s] = [
                    'title' => $art['title'],
                    'deck'  => $art['deck'] ?? '',
                    'cat'   => $art['cat'] ?? 'financial',
                    'date'  => $art['date'] ?? date('Y-m-d'),
                ];
            }
        }
    }
}

function slugify($s) {
    return preg_replace('/^-|-$/', '', preg_replace('/[^a-z0-9]+/', '-', strtolower($s)));
}

// ── Find article from slug ─────────────────────────────────────
$article = $ARTICLES[$slug] ?? null;

// ── Build meta values ──────────────────────────────────────────
if ($article) {
    $title       = htmlspecialchars($article['title']);
    $desc        = htmlspecialchars($article['deck']);
    $cat         = urlencode($article['cat']);
    $titleEnc    = urlencode($article['title']);
    $canonical   = "$baseUrl/reading/$slug";
    $ogImage     = "$imgBase?t=$titleEnc&c=$cat&brand=kerem";
    $datePublished = $article['date'];
    $pageTitle   = $article['title'] . ' — Kerem Albayrak';
} else {
    // Fallback — homepage meta
    $title       = 'Kerem Albayrak';
    $desc        = 'Writing on capital controls, banking risk, and regulatory change.';
    $canonical   = $baseUrl;
    $ogImage     = "$imgBase?t=Kerem+Albayrak&c=financial&brand=kerem";
    $datePublished = date('Y-m-d');
    $pageTitle   = 'Kerem Albayrak';
}

// ── Read the HTML shell ────────────────────────────────────────
$html = file_get_contents(__DIR__ . '/../keremalbayrak.html');

// ── Inject per-article meta into <head> ───────────────────────
$metaBlock = <<<META
  <title>$pageTitle</title>
  <meta name="description" content="$desc" id="meta-desc">
  <link rel="canonical" href="$canonical" id="can">
  <meta property="og:url" content="$canonical" id="og-url">
  <meta property="og:title" content="$title" id="og-title">
  <meta property="og:description" content="$desc" id="og-desc">
  <meta property="og:image" content="$ogImage" id="og-image">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:type" content="article">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="$title" id="tw-title">
  <meta name="twitter:description" content="$desc" id="tw-desc">
  <meta name="twitter:image" content="$ogImage">
META;

// Replace existing meta block
$html = preg_replace('/<meta name="description"[^>]+id="meta-desc">/', '', $html);
$html = preg_replace('/<link rel="canonical"[^>]+id="can">/', '', $html);
$html = preg_replace('/<meta property="og:[^"]*"[^>]+>/', '', $html);
$html = preg_replace('/<meta name="twitter:[^"]*"[^>]+>/', '', $html);
$html = str_replace('<head>', '<head>' . "\n" . $metaBlock, $html);

// ── Inject hidden <img> for Google Images crawling ────────────
// This is the key: Google Images indexes <img> tags, not just og:image
if ($article) {
    $hiddenImg = '<img src="' . htmlspecialchars($ogImage) . '" alt="' . $title . '" width="1200" height="630" style="position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)" loading="eager">';
    $html = str_replace('</body>', $hiddenImg . "\n</body>", $html);
}

// ── JSON-LD Article schema pre-rendered ───────────────────────
if ($article) {
    $schema = json_encode([
        '@context'  => 'https://schema.org',
        '@type'     => 'Article',
        'headline'  => $article['title'],
        'description' => $article['deck'],
        'datePublished' => $datePublished,
        'author'    => ['@type' => 'Person', 'name' => 'Kerem Albayrak', 'url' => $baseUrl],
        'publisher' => ['@type' => 'Person', 'name' => 'Kerem Albayrak', 'url' => $baseUrl],
        'image'     => ['@type' => 'ImageObject', 'url' => $ogImage, 'width' => 1200, 'height' => 630],
        'url'       => $canonical,
        'keywords'  => implode(', ', [$article['cat'], 'Kerem Albayrak', 'wealth', 'regulation']),
    ]);
    $schemaTag = "<script type=\"application/ld+json\">$schema</script>";
    $html = str_replace('</head>', $schemaTag . "\n</head>", $html);
}

header('Content-Type: text/html; charset=utf-8');
header('X-Robots-Tag: index, follow');
echo $html;
