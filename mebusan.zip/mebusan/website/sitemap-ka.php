<?php
/**
 * keremalbayrak.com/sitemap.php
 * Generates XML sitemap with image entries for Google Image Search indexing.
 * Access: https://keremalbayrak.com/sitemap.xml (via .htaccess rewrite)
 */

header('Content-Type: application/xml; charset=utf-8');
header('X-Robots-Tag: noindex');

$baseUrl = 'https://keremalbayrak.com';
$imgBase = 'https://mebusan.com/api/og-image.php';

function slugify($s) {
    return preg_replace('/^-|-$/', '', preg_replace('/[^a-z0-9]+/', '-', strtolower($s)));
}

function imgUrl($title, $cat) {
    global $imgBase;
    return $imgBase . '?t=' . urlencode(substr($title,0,80)) . '&c=' . urlencode($cat) . '&brand=kerem';
}

// ── Static articles ────────────────────────────────────────────
$articles = [
  ['title' => 'How capital controls are signalled months before they arrive', 'cat' => 'financial', 'date' => '2026-04-18'],
  ['title' => 'What the FTX collapse looked like six weeks before it happened', 'cat' => 'technology', 'date' => '2026-04-15'],
  ['title' => 'Russia January 2022: the signals that were visible six weeks before the freeze', 'cat' => 'geopolitical', 'date' => '2026-04-12'],
  ['title' => 'Lebanon 2018: a banking collapse that announced itself eighteen months early', 'cat' => 'financial', 'date' => '2026-04-10'],
  ['title' => 'FATF grey listing: the practical consequences for assets in affected jurisdictions', 'cat' => 'regulatory', 'date' => '2026-04-08'],
  ['title' => 'Sovereign debt deterioration: what the indicators show before markets respond', 'cat' => 'markets', 'date' => '2026-04-05'],
  ['title' => 'Beneficial ownership registers: what has changed and what it means for existing structures', 'cat' => 'regulatory', 'date' => '2026-04-02'],
  ['title' => 'UAE regulatory evolution: what VARA and CBUAE changes mean in practice', 'cat' => 'regulatory', 'date' => '2026-03-28'],
  ['title' => 'Information asymmetry and why it defines private wealth risk', 'cat' => 'geopolitical', 'date' => '2026-03-20'],
  ["title" => "Nigeria's naira: eighteen months of signals before the 2023 devaluation", 'cat' => 'financial', 'date' => '2026-03-15'],
  ['title' => 'CRS and what common reporting standard expansion means for offshore accounts', 'cat' => 'regulatory', 'date' => '2026-03-10'],
  ['title' => 'Sanctions perimeter: how secondary sanctions affect third-country businesses', 'cat' => 'geopolitical', 'date' => '2026-03-05'],
  ['title' => 'Offshore company formation rates as a leading indicator of elite capital movement', 'cat' => 'financial', 'date' => '2026-02-28'],
  ['title' => 'Property registry data as a window into elite capital behaviour', 'cat' => 'financial', 'date' => '2026-02-22'],
  ['title' => 'The Argentine cycle: what repeated currency crises teach about signal reliability', 'cat' => 'financial', 'date' => '2026-02-15'],
  ['title' => 'Exchange rate regimes and what shifts in central bank language actually signal', 'cat' => 'financial', 'date' => '2026-02-08'],
  ['title' => 'Crypto exchange proof-of-reserve: what the data shows and what it does not', 'cat' => 'technology', 'date' => '2026-02-01'],
  ['title' => "Singapore as a wealth hub: regulatory stability and its limits", 'cat' => 'regulatory', 'date' => '2026-01-25'],
  ['title' => "The Swiss banking system: what the Credit Suisse collapse revealed about concentration risk", 'cat' => 'banking', 'date' => '2026-01-18'],
  ['title' => 'Geopolitical risk and portfolio construction: what the academic literature actually shows', 'cat' => 'geopolitical', 'date' => '2026-01-10'],
  ["title" => "Turkey: reading the lira's trajectory through central bank policy signals", 'cat' => 'financial', 'date' => '2026-01-03'],
  ['title' => 'On-chain intelligence: what blockchain data reveals about institutional behaviour', 'cat' => 'technology', 'date' => '2025-12-27'],
  ['title' => 'The IMF Article IV consultation process as an early warning tool', 'cat' => 'regulatory', 'date' => '2025-12-20'],
  ['title' => 'Wealth and jurisdiction: why diversification is not just a financial concept', 'cat' => 'financial', 'date' => '2025-12-12'],
  ['title' => 'Iran sanctions: the compliance and business risk for regional counterparties', 'cat' => 'geopolitical', 'date' => '2025-12-05'],
  ['title' => 'Correspondent banking and what de-risking means for cross-border payments', 'cat' => 'banking', 'date' => '2025-11-28'],
  ['title' => 'Digital asset regulation: the MiCA framework and what it means for European holders', 'cat' => 'regulatory', 'date' => '2025-11-20'],
  ['title' => 'Private credit and illiquidity risk: what the 2022-2024 cycle revealed', 'cat' => 'markets', 'date' => '2025-11-12'],
  ['title' => 'Political risk insurance: what it covers, what it does not, and when it matters', 'cat' => 'geopolitical', 'date' => '2025-11-05'],
];

// ── Pull generated articles from cache ────────────────────────
$cacheFile = __DIR__ . '/cache/ka/articles.json';
if (file_exists($cacheFile)) {
    $cached = json_decode(file_get_contents($cacheFile), true);
    foreach ($cached['articles'] ?? [] as $a) {
        if (!empty($a['title'])) {
            $articles[] = [
                'title' => $a['title'],
                'cat'   => $a['cat'] ?? 'financial',
                'date'  => isset($a['ts']) ? date('Y-m-d', $a['ts']) : date('Y-m-d'),
            ];
        }
    }
}

// Deduplicate
$seen = [];
$unique = [];
foreach ($articles as $a) {
    $k = slugify($a['title']);
    if (!isset($seen[$k])) { $seen[$k] = true; $unique[] = $a; }
}

$today = date('c');
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . "\n";
echo '        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";

// ── Homepage ──────────────────────────────────────────────────
echo "<url>\n";
echo "  <loc>{$baseUrl}</loc>\n";
echo "  <lastmod>{$today}</lastmod>\n";
echo "  <changefreq>daily</changefreq>\n";
echo "  <priority>1.0</priority>\n";
echo "  <image:image>\n";
echo "    <image:loc>" . htmlspecialchars(imgUrl('Kerem Albayrak writing on capital controls banking risk and regulation', 'financial')) . "</image:loc>\n";
echo "    <image:title>Kerem Albayrak — Writing on finance, regulation, and geopolitics</image:title>\n";
echo "    <image:caption>Kerem Albayrak writes on capital controls, banking risk, and regulatory change for people with assets across borders.</image:caption>\n";
echo "  </image:image>\n";
echo "</url>\n";

// ── One URL per article ────────────────────────────────────────
foreach ($unique as $a) {
    $slug      = slugify($a['title']);
    $url       = "$baseUrl/reading/$slug";
    $imgUrl    = imgUrl($a['title'], $a['cat']);
    $title     = htmlspecialchars($a['title']);
    $lastmod   = $a['date'] ? $a['date'] . 'T08:00:00+00:00' : $today;

    echo "<url>\n";
    echo "  <loc>" . htmlspecialchars($url) . "</loc>\n";
    echo "  <lastmod>{$lastmod}</lastmod>\n";
    echo "  <changefreq>monthly</changefreq>\n";
    echo "  <priority>0.8</priority>\n";
    echo "  <image:image>\n";
    echo "    <image:loc>" . htmlspecialchars($imgUrl) . "</image:loc>\n";
    echo "    <image:title>{$title}</image:title>\n";
    echo "    <image:caption>Kerem Albayrak — {$title}</image:caption>\n";
    echo "  </image:image>\n";
    echo "</url>\n";
}

echo '</urlset>';
