<?php
require_once __DIR__ . '/../config.php';
session_start();
if (empty($_SESSION['admin_ok']) || (time() - ($_SESSION['admin_ts'] ?? 0)) > 3600) {
    header('Location: login.php'); exit;
}
$_SESSION['admin_ts'] = time();

$id = $_GET['id'] ?? '';
$app = null;
if ($id) {
    $f = MB_DATA_DIR . '/applications/' . preg_replace('/[^A-Z0-9\-]/', '', $id) . '.json';
    if (file_exists($f)) $app = json_decode(file_get_contents($f), true);
}

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $app) {
    $action = $_POST['action'] ?? '';
    if ($action === 'approve' && $app['final_tier'] === 'private') {
        // Manually approve a Private applicant (creates Stripe checkout link for them)
        $app['status'] = 'approved_for_payment';
        $app['approved_at'] = time();
        @file_put_contents($f, json_encode($app, JSON_PRETTY_PRINT));
    }
    if ($action === 'reject') {
        $app['status'] = 'rejected';
        $app['rejected_at'] = time();
        @file_put_contents($f, json_encode($app, JSON_PRETTY_PRINT));
    }
    header('Location: applications.php?id=' . $id); exit;
}

function fmt_t($ts) { return $ts ? date('Y-m-d H:i', $ts) : '—'; }
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>Application · Mebusan Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&family=Inter:wght@300;400&family=DM+Mono:wght@300;400&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#060504;color:#e8e2d4;font-family:'Inter',sans-serif;font-weight:300;min-height:100vh}
.nav{border-bottom:.5px solid rgba(232,226,212,.08);padding:16px 32px;display:flex;justify-content:space-between;align-items:center}
.logo{font-family:'Josefin Sans',sans-serif;font-weight:300;letter-spacing:.38em;font-size:12px}
.back{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#7a7568;text-decoration:none}
main{padding:32px;max-width:800px;margin:0 auto}
h1{font-size:22px;font-weight:300;margin-bottom:8px;letter-spacing:-.02em}
.sub{font-family:'DM Mono',monospace;font-size:10px;color:#7a7568;letter-spacing:.1em;margin-bottom:32px}
.section{border:.5px solid rgba(232,226,212,.08);margin-bottom:20px}
.section-head{padding:12px 20px;font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.14em;text-transform:uppercase;color:#7a7568;border-bottom:.5px solid rgba(232,226,212,.06);background:rgba(232,226,212,.02)}
.row{display:grid;grid-template-columns:200px 1fr;gap:16px;padding:12px 20px;border-bottom:.5px solid rgba(232,226,212,.05);font-size:13px}
.row:last-child{border-bottom:none}
.row-l{font-family:'DM Mono',monospace;font-size:9px;color:#7a7568;letter-spacing:.1em;text-transform:uppercase;padding-top:2px}
.row-v{color:#e8e2d4;font-weight:300}
.tag{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.1em;text-transform:uppercase;padding:3px 8px;border:.5px solid rgba(232,226,212,.15);display:inline-block}
.tag.pending{color:#c8a03a;border-color:rgba(200,160,58,.3)}
.tag.active{color:#4a9a6e;border-color:rgba(58,122,88,.4)}
.tag.converted{color:#4a9a6e;border-color:rgba(58,122,88,.4)}
.tag.rejected{color:#aa3a2e;border-color:rgba(170,58,46,.3)}
.actions{display:flex;gap:8px;padding:20px;border-top:.5px solid rgba(232,226,212,.06);flex-wrap:wrap}
.btn{font-family:'DM Mono',monospace;font-size:9.5px;letter-spacing:.12em;text-transform:uppercase;padding:11px 18px;border:.5px solid rgba(232,226,212,.14);background:transparent;color:#e8e2d4;cursor:pointer;text-decoration:none}
.btn.primary{background:#e8e2d4;color:#060504;border:none}
.btn.danger{color:#aa3a2e;border-color:rgba(170,58,46,.3)}
.btn:hover{border-color:rgba(232,226,212,.3)}
.empty{padding:60px 20px;text-align:center;color:#7a7568}
</style>
</head>
<body>
<nav class="nav">
  <div class="logo">MEBUSAN · ADMIN</div>
  <a href="index.php" class="back">← Dashboard</a>
</nav>
<main>
<?php if (!$app): ?>
  <div class="empty">Application not found. <a href="index.php" style="color:#c8a03a">← Back</a></div>
<?php else: ?>
  <h1>Application</h1>
  <div class="sub"><?= htmlspecialchars($app['id']) ?> · <span class="tag <?= htmlspecialchars($app['status']) ?>"><?= str_replace('_',' ',$app['status']) ?></span></div>

  <div class="section">
    <div class="section-head">Identity</div>
    <div class="row"><div class="row-l">Email</div><div class="row-v"><?= htmlspecialchars($app['email']) ?></div></div>
    <div class="row"><div class="row-l">Alias</div><div class="row-v"><?= htmlspecialchars($app['alias'] ?: '—') ?></div></div>
    <div class="row"><div class="row-l">Submitted</div><div class="row-v"><?= fmt_t($app['submitted_at']) ?></div></div>
  </div>

  <div class="section">
    <div class="section-head">Tier assignment</div>
    <div class="row"><div class="row-l">Recommended</div><div class="row-v"><?= htmlspecialchars($app['recommended_tier']) ?></div></div>
    <div class="row"><div class="row-l">Chosen</div><div class="row-v"><?= htmlspecialchars($app['chosen_tier'] ?: 'auto') ?></div></div>
    <div class="row"><div class="row-l">Final</div><div class="row-v"><strong><?= htmlspecialchars($app['final_tier']) ?></strong></div></div>
    <div class="row"><div class="row-l">Billing cycle</div><div class="row-v"><?= htmlspecialchars($app['billing_cycle']) ?></div></div>
  </div>

  <div class="section">
    <div class="section-head">Exposure profile</div>
    <div class="row"><div class="row-l">Jurisdictions</div><div class="row-v"><?= (int)$app['jurisdiction_count'] ?></div></div>
    <div class="row"><div class="row-l">Asset types</div><div class="row-v"><?= htmlspecialchars(implode(', ', $app['asset_types'] ?? [])) ?></div></div>
    <div class="row"><div class="row-l">Concern level</div><div class="row-v"><?= htmlspecialchars($app['concern_level']) ?></div></div>
    <div class="row"><div class="row-l">Contact preference</div><div class="row-v"><?= htmlspecialchars($app['contact_preference']) ?></div></div>
  </div>

  <?php if (!empty($app['checkout_url'])): ?>
  <div class="section">
    <div class="section-head">Stripe</div>
    <div class="row"><div class="row-l">Checkout URL</div><div class="row-v"><a href="<?= htmlspecialchars($app['checkout_url']) ?>" style="color:#c8a03a;word-break:break-all" target="_blank"><?= htmlspecialchars($app['checkout_url']) ?></a></div></div>
  </div>
  <?php endif; ?>

  <form method="post" class="section">
    <div class="actions">
      <?php if ($app['status'] === 'pending' && $app['final_tier'] === 'private'): ?>
        <button class="btn primary" name="action" value="approve" type="submit">Approve for payment</button>
      <?php endif; ?>
      <?php if ($app['status'] !== 'rejected' && $app['status'] !== 'converted'): ?>
        <button class="btn danger" name="action" value="reject" type="submit" onclick="return confirm('Reject this application?')">Reject</button>
      <?php endif; ?>
      <a href="mailto:<?= htmlspecialchars($app['email']) ?>?subject=Mebusan%20application%20<?= htmlspecialchars($app['id']) ?>" class="btn">Email applicant</a>
    </div>
  </form>
<?php endif; ?>
</main>
</body>
</html>
