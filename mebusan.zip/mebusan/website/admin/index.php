<?php
require_once __DIR__ . '/../config.php';
session_start();

// Auth guard
if (empty($_SESSION['admin_ok']) || (time() - ($_SESSION['admin_ts'] ?? 0)) > 3600) {
    session_destroy();
    header('Location: login.php'); exit;
}
$_SESSION['admin_ts'] = time();

// Load data
global $MEBUSAN_TIERS;
$applications = load_all_applications();
$clients = load_all_clients();
$alert_queue = @json_decode(@file_get_contents(MB_CACHE_ALERTS . '/queue.json'), true) ?: [];
$forex = @json_decode(@file_get_contents(MB_CACHE_FOREX . '/latest.json'), true);
$risk = @json_decode(@file_get_contents(MB_CACHE_RISK . '/scores.json'), true);

// Counts
$c_pending = count(array_filter($applications, fn($a) => $a['status'] === 'pending'));
$c_checkout = count(array_filter($applications, fn($a) => $a['status'] === 'checkout_created'));
$c_active = count(array_filter($clients, fn($c) => $c['status'] === 'active'));
$c_private = count(array_filter($clients, fn($c) => $c['tier'] === 'private' && $c['status'] === 'active'));
$c_advisory = count(array_filter($clients, fn($c) => $c['tier'] === 'advisory' && $c['status'] === 'active'));
$c_monitor = count(array_filter($clients, fn($c) => $c['tier'] === 'monitor' && $c['status'] === 'active'));

// MRR
$mrr = 0;
foreach ($clients as $c) {
    if ($c['status'] !== 'active') continue;
    $t = $MEBUSAN_TIERS[$c['tier']] ?? null;
    if ($t) $mrr += $t['monthly'];
}

function load_all_applications() {
    $dir = MB_DATA_DIR . '/applications';
    if (!is_dir($dir)) return [];
    $apps = [];
    foreach (glob($dir . '/*.json') as $f) {
        $a = json_decode(file_get_contents($f), true);
        if ($a) $apps[] = $a;
    }
    usort($apps, fn($a, $b) => $b['submitted_at'] <=> $a['submitted_at']);
    return $apps;
}

function load_all_clients() {
    $f = MB_DATA_DIR . '/clients.json';
    if (!file_exists($f)) return [];
    $all = json_decode(file_get_contents($f), true) ?: [];
    usort($all, fn($a, $b) => ($b['activated_at'] ?? 0) <=> ($a['activated_at'] ?? 0));
    return $all;
}

function t($ts) {
    if (!$ts) return '—';
    $d = time() - $ts;
    if ($d < 60) return "${d}s ago";
    if ($d < 3600) return floor($d/60) . 'm ago';
    if ($d < 86400) return floor($d/3600) . 'h ago';
    return floor($d/86400) . 'd ago';
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>Mebusan · Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&family=Inter:wght@300;400;500&family=DM+Mono:wght@300;400&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#060504;color:#e8e2d4;font-family:'Inter',sans-serif;font-weight:300;min-height:100vh}
.nav{border-bottom:.5px solid rgba(232,226,212,.08);padding:16px 32px;display:flex;justify-content:space-between;align-items:center}
.logo{font-family:'Josefin Sans',sans-serif;font-weight:300;letter-spacing:.38em;font-size:12px}
.logout{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#7a7568;text-decoration:none}
.logout:hover{color:#e8e2d4}
main{padding:32px;max-width:1400px;margin:0 auto}
h1{font-size:22px;font-weight:300;margin-bottom:24px;letter-spacing:-.02em}
h2{font-size:14px;font-weight:400;margin:32px 0 12px;letter-spacing:.02em;color:#9e9888}
.stats{display:grid;grid-template-columns:repeat(6,1fr);gap:0;border:.5px solid rgba(232,226,212,.08);margin-bottom:32px}
.stat{padding:20px 22px;border-right:.5px solid rgba(232,226,212,.08)}
.stat:last-child{border-right:none}
.stat-n{font-size:24px;font-weight:300;margin-bottom:4px}
.stat-l{font-family:'DM Mono',monospace;font-size:8.5px;letter-spacing:.14em;text-transform:uppercase;color:#7a7568}
table{width:100%;border-collapse:collapse;border:.5px solid rgba(232,226,212,.08);font-size:12.5px}
th{font-family:'DM Mono',monospace;font-size:8.5px;letter-spacing:.14em;text-transform:uppercase;color:#7a7568;font-weight:300;text-align:left;padding:10px 14px;border-bottom:.5px solid rgba(232,226,212,.08);background:rgba(232,226,212,.02)}
td{padding:12px 14px;border-bottom:.5px solid rgba(232,226,212,.05);color:#bbb6ad}
tr:last-child td{border-bottom:none}
.tag{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.1em;text-transform:uppercase;padding:3px 8px;border:.5px solid rgba(232,226,212,.12);display:inline-block}
.tag.monitor{color:#9e9888}
.tag.advisory{color:#c8a03a;border-color:rgba(200,160,58,.3)}
.tag.private{color:#e8e2d4;border-color:rgba(232,226,212,.3)}
.tag.pending{color:#c8a03a;border-color:rgba(200,160,58,.3)}
.tag.active{color:#4a9a6e;border-color:rgba(58,122,88,.4)}
.tag.cancelled{color:#aa3a2e;border-color:rgba(170,58,46,.3)}
.tag.checkout_created{color:#9e9888}
.empty{padding:40px 20px;text-align:center;color:#7a7568;font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.1em}
.pipeline{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin-bottom:24px}
.stage{border:.5px solid rgba(232,226,212,.08);padding:16px;text-align:center}
.stage-n{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.16em;text-transform:uppercase;color:#7a7568;margin-bottom:6px}
.stage-t{font-size:12px;color:#e8e2d4;margin-bottom:6px}
.stage-s{font-family:'DM Mono',monospace;font-size:9px;color:#4a9a6e;letter-spacing:.08em}
.stage-s.stale{color:#c8a03a}
.stage-s.dead{color:#aa3a2e}
@media(max-width:900px){
 .stats,.pipeline{grid-template-columns:repeat(2,1fr)}
 main{padding:20px}
 table{font-size:11.5px}
 th,td{padding:8px 10px}
}
</style>
</head>
<body>

<nav class="nav">
  <div class="logo">MEBUSAN · ADMIN</div>
  <a href="logout.php" class="logout">Sign out</a>
</nav>

<main>
  <h1>Operations</h1>

  <div class="stats">
    <div class="stat"><div class="stat-n"><?= $c_active ?></div><div class="stat-l">Active clients</div></div>
    <div class="stat"><div class="stat-n">$<?= number_format($mrr) ?></div><div class="stat-l">MRR</div></div>
    <div class="stat"><div class="stat-n"><?= $c_private ?></div><div class="stat-l">Private</div></div>
    <div class="stat"><div class="stat-n"><?= $c_advisory ?></div><div class="stat-l">Advisory</div></div>
    <div class="stat"><div class="stat-n"><?= $c_monitor ?></div><div class="stat-l">Monitor</div></div>
    <div class="stat"><div class="stat-n"><?= $c_pending ?></div><div class="stat-l">Pending apps</div></div>
  </div>

  <h2>Pipeline status</h2>
  <div class="pipeline">
    <div class="stage"><div class="stage-n">01</div><div class="stage-t">Forex</div>
      <div class="stage-s <?= ($forex && (time() - ($forex['ts'] ?? 0)) < 25000) ? '' : 'stale' ?>">
        <?= $forex ? t($forex['ts']) : 'never' ?>
      </div>
    </div>
    <div class="stage"><div class="stage-n">02</div><div class="stage-t">Risk scores</div>
      <div class="stage-s <?= ($risk && (time() - ($risk['ts'] ?? 0)) < 100000) ? '' : 'stale' ?>">
        <?= $risk ? t($risk['ts']) : 'never' ?>
      </div>
    </div>
    <div class="stage"><div class="stage-n">03</div><div class="stage-t">Alert queue</div>
      <div class="stage-s"><?= count($alert_queue) ?> queued</div>
    </div>
    <div class="stage"><div class="stage-n">04</div><div class="stage-t">Briefings</div>
      <div class="stage-s">daily 8am</div>
    </div>
    <div class="stage"><div class="stage-n">05</div><div class="stage-t">Journal</div>
      <div class="stage-s">every 3d</div>
    </div>
  </div>

  <h2>Applications (<?= count($applications) ?>)</h2>
  <table>
    <thead><tr>
      <th>ID</th><th>Email</th><th>Tier</th><th>Status</th><th>Jurisdictions</th><th>Contact</th><th>Submitted</th>
    </tr></thead>
    <tbody>
    <?php if (!$applications): ?>
      <tr><td colspan="7" class="empty">No applications yet</td></tr>
    <?php else: foreach (array_slice($applications, 0, 50) as $a): ?>
      <tr>
        <td style="font-family:'DM Mono',monospace;font-size:10px"><?= htmlspecialchars($a['id']) ?></td>
        <td><?= htmlspecialchars($a['email']) ?></td>
        <td><span class="tag <?= $a['final_tier'] ?>"><?= $a['final_tier'] ?></span></td>
        <td><span class="tag <?= $a['status'] ?>"><?= str_replace('_', ' ', $a['status']) ?></span></td>
        <td><?= (int)$a['jurisdiction_count'] ?></td>
        <td><?= htmlspecialchars($a['contact_preference']) ?></td>
        <td style="font-family:'DM Mono',monospace;font-size:10px;color:#7a7568"><?= t($a['submitted_at']) ?></td>
      </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>

  <h2>Active clients (<?= $c_active ?>)</h2>
  <table>
    <thead><tr>
      <th>ID</th><th>Tier</th><th>Email</th><th>Jurisdictions</th><th>Channel</th><th>Activated</th>
    </tr></thead>
    <tbody>
    <?php if (!$clients): ?>
      <tr><td colspan="6" class="empty">No clients yet</td></tr>
    <?php else: foreach (array_slice($clients, 0, 100) as $c): ?>
      <tr>
        <td style="font-family:'DM Mono',monospace;font-size:10px"><?= htmlspecialchars($c['id']) ?></td>
        <td><span class="tag <?= $c['tier'] ?>"><?= $c['tier'] ?></span></td>
        <td><?= htmlspecialchars($c['email'] ?? '') ?></td>
        <td><?= count($c['jurisdictions'] ?? []) ?></td>
        <td><?= htmlspecialchars($c['alert_channel'] ?? 'email') ?></td>
        <td style="font-family:'DM Mono',monospace;font-size:10px;color:#7a7568"><?= t($c['activated_at'] ?? 0) ?></td>
      </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>

</main>

</body>
</html>
