<?php
require_once __DIR__ . '/../config.php';
session_start();
if (empty($_SESSION['admin_ok']) || (time() - ($_SESSION['admin_ts'] ?? 0)) > 3600) {
    header('Location: login.php'); exit;
}
$_SESSION['admin_ts'] = time();

$id = $_GET['id'] ?? '';
$client = null;
if ($id) {
    $f = MB_DATA_DIR . '/clients.json';
    if (file_exists($f)) {
        $all = json_decode(file_get_contents($f), true) ?: [];
        foreach ($all as $c) if ($c['id'] === $id) { $client = $c; break; }
    }
}

// Load briefings for this client
$briefings = [];
if ($client) {
    $dir = MB_DATA_DIR . '/briefings/' . $client['id'];
    if (is_dir($dir)) {
        foreach (glob($dir . '/*.json') as $bf) {
            $b = json_decode(file_get_contents($bf), true);
            if ($b) $briefings[] = $b;
        }
        usort($briefings, fn($a,$b) => $b['generated_at'] <=> $a['generated_at']);
    }
}

function fmt_t($ts) { return $ts ? date('Y-m-d H:i', $ts) : '—'; }
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>Client · Mebusan Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&family=Inter:wght@300;400&family=DM+Mono:wght@300;400&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#060504;color:#e8e2d4;font-family:'Inter',sans-serif;font-weight:300;min-height:100vh}
.nav{border-bottom:.5px solid rgba(232,226,212,.08);padding:16px 32px;display:flex;justify-content:space-between;align-items:center}
.logo{font-family:'Josefin Sans',sans-serif;font-weight:300;letter-spacing:.38em;font-size:12px}
.back{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#7a7568;text-decoration:none}
main{padding:32px;max-width:800px;margin:0 auto}
h1{font-size:22px;font-weight:300;margin-bottom:8px;letter-spacing:-.02em}
.sub{font-family:'DM Mono',monospace;font-size:10px;color:#7a7568;letter-spacing:.1em;margin-bottom:32px}
.section{border:.5px solid rgba(232,226,212,.08);margin-bottom:20px}
.section-head{padding:12px 20px;font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.14em;text-transform:uppercase;color:#7a7568;border-bottom:.5px solid rgba(232,226,212,.06);background:rgba(232,226,212,.02)}
.row{display:grid;grid-template-columns:200px 1fr;gap:16px;padding:12px 20px;border-bottom:.5px solid rgba(232,226,212,.05);font-size:13px}
.row:last-child{border-bottom:none}
.row-l{font-family:'DM Mono',monospace;font-size:9px;color:#7a7568;letter-spacing:.1em;text-transform:uppercase;padding-top:2px}
.row-v{color:#e8e2d4;font-weight:300}
.tag{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.1em;text-transform:uppercase;padding:3px 8px;border:.5px solid rgba(232,226,212,.15);display:inline-block}
.tag.active{color:#4a9a6e;border-color:rgba(58,122,88,.4)}
.tag.cancelled{color:#aa3a2e;border-color:rgba(170,58,46,.3)}
.tag.private{color:#e8e2d4;border-color:rgba(232,226,212,.3)}
.tag.advisory{color:#c8a03a;border-color:rgba(200,160,58,.3)}
.tag.monitor{color:#9e9888}
.briefing{padding:12px 20px;border-bottom:.5px solid rgba(232,226,212,.05);font-size:13px}
.briefing:last-child{border-bottom:none}
.briefing-ts{font-family:'DM Mono',monospace;font-size:9px;color:#7a7568;letter-spacing:.08em}
.empty{padding:60px 20px;text-align:center;color:#7a7568}
</style>
</head>
<body>
<nav class="nav">
  <div class="logo">MEBUSAN · ADMIN</div>
  <a href="index.php" class="back">← Dashboard</a>
</nav>
<main>
<?php if (!$client): ?>
  <div class="empty">Client not found. <a href="index.php" style="color:#c8a03a">← Back</a></div>
<?php else: ?>
  <h1>Client</h1>
  <div class="sub"><?= htmlspecialchars($client['id']) ?> · <span class="tag <?= htmlspecialchars($client['tier']) ?>"><?= htmlspecialchars($client['tier']) ?></span> · <span class="tag <?= htmlspecialchars($client['status']) ?>"><?= htmlspecialchars($client['status']) ?></span></div>

  <div class="section">
    <div class="section-head">Identity</div>
    <div class="row"><div class="row-l">Email</div><div class="row-v"><?= htmlspecialchars($client['email'] ?? '—') ?></div></div>
    <div class="row"><div class="row-l">Alias</div><div class="row-v"><?= htmlspecialchars($client['alias'] ?? '—') ?></div></div>
    <div class="row"><div class="row-l">Activated</div><div class="row-v"><?= fmt_t($client['activated_at'] ?? 0) ?></div></div>
    <div class="row"><div class="row-l">Last payment</div><div class="row-v"><?= fmt_t($client['last_payment'] ?? 0) ?></div></div>
    <div class="row"><div class="row-l">Next renewal</div><div class="row-v"><?= fmt_t($client['next_renewal'] ?? 0) ?></div></div>
  </div>

  <div class="section">
    <div class="section-head">Coverage</div>
    <div class="row"><div class="row-l">Jurisdictions</div><div class="row-v"><?= htmlspecialchars(implode(', ', $client['jurisdictions'] ?? [])) ?: '—' ?></div></div>
    <div class="row"><div class="row-l">Asset types</div><div class="row-v"><?= htmlspecialchars(implode(', ', $client['asset_types'] ?? [])) ?: '—' ?></div></div>
    <div class="row"><div class="row-l">Alert channel</div><div class="row-v"><?= htmlspecialchars($client['alert_channel'] ?? 'email') ?></div></div>
  </div>

  <div class="section">
    <div class="section-head">Stripe</div>
    <div class="row"><div class="row-l">Customer</div><div class="row-v" style="font-family:monospace;font-size:11px"><?= htmlspecialchars($client['stripe_customer'] ?? '—') ?></div></div>
    <div class="row"><div class="row-l">Subscription</div><div class="row-v" style="font-family:monospace;font-size:11px"><?= htmlspecialchars($client['stripe_sub'] ?? '—') ?></div></div>
    <div class="row"><div class="row-l">Payment fails</div><div class="row-v"><?= (int)($client['payment_fails'] ?? 0) ?></div></div>
  </div>

  <div class="section">
    <div class="section-head">Briefings (<?= count($briefings) ?>)</div>
    <?php if (!$briefings): ?>
      <div class="empty" style="padding:24px">No briefings generated yet</div>
    <?php else: foreach (array_slice($briefings, 0, 10) as $b): ?>
      <div class="briefing">
        <div class="briefing-ts"><?= fmt_t($b['generated_at']) ?></div>
        <div style="margin-top:6px"><?= htmlspecialchars(substr($b['summary'] ?: 'No summary', 0, 200)) ?></div>
      </div>
    <?php endforeach; endif; ?>
  </div>
<?php endif; ?>
</main>
</body>
</html>
