<?php
/**
 * Mebusan signal moderation API.
 * Backs admin/moderate.html.
 * 
 * Storage:
 *   cache/signals/pending.json   — ingested but not yet published
 *   cache/signals/approved.json  — published to Signal Wall
 *   cache/signals/rejected.json  — rejected; kept for audit
 *
 * Auth: requires admin session. Reuse the same session gate as admin/index.php.
 */

session_start();
if (!isset($_SESSION['mebusan_admin'])) {
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'unauthorised']);
    exit;
}

header('Content-Type: application/json');

$base = __DIR__ . '/../cache/signals';
if (!is_dir($base)) { @mkdir($base, 0755, true); }

$files = [
    'pending'  => $base . '/pending.json',
    'approved' => $base . '/approved.json',
    'rejected' => $base . '/rejected.json',
];

function load_bucket($path) {
    if (!file_exists($path)) return [];
    $raw = @file_get_contents($path);
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function save_bucket($path, $data) {
    $tmp = $path . '.tmp';
    file_put_contents($tmp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    rename($tmp, $path);
}

function audit_log($action, $id, $extra = []) {
    $log = __DIR__ . '/../cache/signals/moderation.log';
    $line = date('c') . "\t" . $action . "\t" . $id . "\t" . json_encode($extra) . "\n";
    @file_put_contents($log, $line, FILE_APPEND | LOCK_EX);
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // List all buckets
    $action = $_GET['action'] ?? 'list';
    if ($action === 'list') {
        echo json_encode([
            'pending'  => load_bucket($files['pending']),
            'approved' => array_slice(load_bucket($files['approved']), 0, 50), // recent only
            'rejected' => array_slice(load_bucket($files['rejected']), 0, 50),
        ]);
        exit;
    }
}

if ($method === 'POST') {
    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body) || !isset($body['action'], $body['id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'bad request']);
        exit;
    }
    $action = $body['action'];
    $id = $body['id'];

    $pending = load_bucket($files['pending']);
    $approved = load_bucket($files['approved']);
    $rejected = load_bucket($files['rejected']);

    $moved = null;

    switch ($action) {
        case 'approve':
            foreach ($pending as $k => $s) {
                if ($s['id'] === $id) { $moved = $s; unset($pending[$k]); break; }
            }
            if ($moved) {
                $moved['approved_at'] = date('c');
                $moved['approved_by'] = $_SESSION['mebusan_admin'] ?? 'admin';
                array_unshift($approved, $moved);
            }
            break;

        case 'edit_approve':
            foreach ($pending as $k => $s) {
                if ($s['id'] === $id) {
                    $updated = array_merge($s, $body);
                    unset($updated['action']); // housekeeping
                    $updated['approved_at'] = date('c');
                    $updated['edited'] = true;
                    $updated['approved_by'] = $_SESSION['mebusan_admin'] ?? 'admin';
                    unset($pending[$k]);
                    array_unshift($approved, $updated);
                    $moved = $updated;
                    break;
                }
            }
            break;

        case 'reject':
            foreach ($pending as $k => $s) {
                if ($s['id'] === $id) { $moved = $s; unset($pending[$k]); break; }
            }
            if ($moved) {
                $moved['rejected_at'] = date('c');
                $moved['rejected_by'] = $_SESSION['mebusan_admin'] ?? 'admin';
                array_unshift($rejected, $moved);
            }
            break;

        case 'unapprove':
            foreach ($approved as $k => $s) {
                if ($s['id'] === $id) { $moved = $s; unset($approved[$k]); break; }
            }
            if ($moved) {
                unset($moved['approved_at'], $moved['approved_by']);
                array_unshift($pending, $moved);
            }
            break;

        case 'restore':
            // Find in rejected or approved, move back to pending
            foreach ($rejected as $k => $s) {
                if ($s['id'] === $id) { $moved = $s; unset($rejected[$k]); break; }
            }
            if (!$moved) {
                foreach ($approved as $k => $s) {
                    if ($s['id'] === $id) { $moved = $s; unset($approved[$k]); break; }
                }
            }
            if ($moved) {
                unset($moved['rejected_at'], $moved['rejected_by'], $moved['approved_at'], $moved['approved_by']);
                array_unshift($pending, $moved);
            }
            break;

        default:
            http_response_code(400);
            echo json_encode(['error' => 'unknown action']);
            exit;
    }

    // Persist
    save_bucket($files['pending'], array_values($pending));
    save_bucket($files['approved'], array_values($approved));
    save_bucket($files['rejected'], array_values($rejected));

    // Sync approved to public signals.json (consumed by wall.html via api/signals.php)
    $public = __DIR__ . '/../cache/signals/public.json';
    save_bucket($public, array_slice($approved, 0, 200));

    audit_log($action, $id, ['operator' => $_SESSION['mebusan_admin'] ?? 'admin']);
    echo json_encode(['ok' => true, 'action' => $action, 'id' => $id]);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'method not allowed']);
