<?php
require_once __DIR__ . '/../config.php';
session_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    if (ADMIN_PASSWORD_HASH && password_verify($password, ADMIN_PASSWORD_HASH)) {
        $_SESSION['admin_ok'] = true;
        $_SESSION['admin_ip'] = $_SERVER['REMOTE_ADDR'] ?? '';
        $_SESSION['admin_ts'] = time();
        header('Location: index.php'); exit;
    }
    $error = 'Incorrect password.';
    sleep(1); // throttle brute force
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>Mebusan · Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&family=Inter:wght@300;400&family=DM+Mono:wght@300;400&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#060504;color:#e8e2d4;font-family:'Inter',sans-serif;font-weight:300;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.box{width:100%;max-width:360px;border:.5px solid rgba(232,226,212,.1);padding:40px 32px}
.logo{font-family:'Josefin Sans',sans-serif;font-weight:300;letter-spacing:.38em;font-size:13px;margin-bottom:32px;text-align:center}
.label{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.14em;text-transform:uppercase;color:#7a7568;margin-bottom:8px}
input{width:100%;background:rgba(232,226,212,.03);border:.5px solid rgba(232,226,212,.14);color:#e8e2d4;font-family:'Inter',sans-serif;font-weight:300;font-size:14px;padding:12px 14px;outline:none}
input:focus{border-color:rgba(232,226,212,.3)}
button{width:100%;background:#e8e2d4;color:#060504;border:none;font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.14em;text-transform:uppercase;padding:13px;margin-top:20px;cursor:pointer}
button:hover{background:#d4cfc3}
.err{font-family:'DM Mono',monospace;font-size:10px;color:#c8a03a;margin-top:12px;text-align:center}
.note{font-family:'DM Mono',monospace;font-size:9px;color:#3a3530;text-align:center;margin-top:24px;letter-spacing:.08em}
</style>
</head>
<body>
<form method="post" class="box">
  <div class="logo">MEBUSAN · ADMIN</div>
  <div class="label">Password</div>
  <input type="password" name="password" autofocus required>
  <button type="submit">Sign in</button>
  <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <div class="note">Authorised personnel only.</div>
</form>
</body>
</html>
