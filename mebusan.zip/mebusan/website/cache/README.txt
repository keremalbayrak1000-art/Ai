MEBUSAN — Cache Directory

This directory stores temporary API response caches.

Subdirectories:
  forex/     — Currency rate caches (1 hour TTL)
  risk/      — Country risk score caches (6 hour TTL)
  sanctions/ — OFAC/UN sanctions data (24 hour TTL)
  intel/     — AI analysis caches (1 hour TTL)
  alerts/    — Alert logs and threshold state

Permissions: 755 (directory), 644 (files)
On Hostinger: File Manager → Right-click → Permissions

The API will create these directories automatically if PHP has write access.
If not, create them manually via Hostinger File Manager.
