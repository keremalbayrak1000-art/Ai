# MEBUSAN — ADDITIONAL STRATEGIES & SYSTEM THINKING

**Compiled April 2026 · Focused addendum — functionality, intelligence systems, integrations**

---

## SECTION I — INTELLIGENCE SYSTEMS (NOT RESEARCH)

The core distinction Mebusan must own in every communication:

**Research** = aggregating public information and summarising it.
**Intelligence** = producing original assessments from non-public sources, delivered before the situation is publicly known.

Every competitor in this space does research. Bloomberg terminals, country risk reports, consultancy briefings — all research. Mebusan's value proposition is intelligence: an analyst who has spoken to a contact inside Garanti Bank telling a client what is happening before it appears in Reuters.

**Strategy 251 · Build and maintain a formal source network per jurisdiction**
For each monitored jurisdiction, the analyst team should have a documented contact network: at minimum two banking contacts, one legal/compliance professional, one property market participant, and one political economy analyst. These relationships are maintained through regular contact — not just activated in a crisis. The network is a Mebusan asset, not an individual analyst's personal network. Source quality is documented: how reliable have their tips been historically?

**Strategy 252 · Source reliability scoring and history**
Track every human source tip: what was reported, when, what actually happened, and the lag between source intelligence and public knowledge. Build a reliability score per source (anonymised internally). A source who has delivered accurate advance intelligence 8 out of 10 times gets a higher weighting in confidence scoring than one with a 5/10 track record. This turns institutional knowledge into a measurable asset.

**Strategy 253 · First-mover intelligence protocol**
When a human source delivers intelligence that has not yet appeared in any public source, activate a rapid protocol: the analyst writes a flash brief in under 30 minutes, routes it through expedited senior review (10 minutes), and delivers to affected clients within 60 minutes of the source call. Track the time gap between flash brief delivery and public news appearance — this gap is the core metric of Mebusan's intelligence value. Target: 24 hours ahead of public knowledge.

**Strategy 254 · Source signal vs. data signal distinction in briefings**
Every briefing should clearly distinguish what came from human intelligence vs. what came from data signals. Clients should know when their analyst spoke to someone vs. when the system flagged a number. This transparency builds trust and helps clients understand the confidence level. Use the source tag system (Human source / Signal data / Open source) already in the app.

**Strategy 255 · Counter-intelligence awareness**
In jurisdictions with active state surveillance (Turkey, UAE, Russia-adjacent, China), clients and analysts need to understand that communications about their assets may be monitored. Build a counter-intelligence protocol: which topics should never be discussed over standard channels, what signals suggest a client's communications have been compromised, and how to route genuinely sensitive intelligence through higher-security channels.

---

## SECTION II — CONFIDENCE SCORE SYSTEM (FULL DESIGN)

**Strategy 256 · Confidence score = weighted composite of four factors**
Each briefing confidence score is calculated as a weighted average:
- Signal data strength (independent signals pointing same direction) — 30%
- Human source corroboration (has a contact confirmed?) — 40%
- Historical pattern match (how closely does this match precedents?) — 20%
- Time-to-event consistency (is the timeline plausible?) — 10%

Output: 0–100%. Below 60% = stays in analyst queue. 60–74% = weekly digest only. 75–89% = immediate delivery if above client threshold. 90%+ = emergency delivery regardless of threshold.

**Strategy 257 · Confidence score trajectory as signal in itself**
A briefing that starts at 62% confidence and rises to 78% over five days is more urgent than one that has been static at 78% for two weeks. Track confidence score trajectory per risk situation and alert when velocity crosses a threshold: confidence rising more than 10 points in 72 hours = automatic escalation regardless of absolute level.

**Strategy 258 · Confidence score decay for stale signals**
If a risk situation remains at the same level for more than 30 days without new signals, its confidence score should decay slightly — not because the risk has passed, but because the model should not be overconfident in signals that haven't updated. Build in a 5% per-week decay cap that only applies to stale situations. This forces periodic re-assessment rather than allowing old high-confidence scores to persist indefinitely.

**Strategy 259 · False positive tracking and model recalibration**
Track how many confidence-threshold alerts were issued and how many resulted in actual restriction events. If the model is triggering too many false positives at 75% confidence, recalibrate the threshold or the weighting of individual signal types. Build a monthly recalibration review into analyst operations. This makes the confidence system self-improving over time.

**Strategy 260 · Confidence score public disclosure — within briefings only**
Never display confidence scores on the website or in marketing. Only in the client app, on specific briefings. The existence of a confidence system is a trust signal — it shows rigour. But publishing scores publicly invites comparison and criticism of individual assessments. Inside the client relationship, full transparency; outside it, none.

---

## SECTION III — FREE SYSTEM INTEGRATIONS (ZERO COST)

**Strategy 261 · Telegram Bot API — free, instant, end-to-end encrypted options**
Telegram's Bot API is free with no limits for private use. Build a Mebusan Telegram bot: when a briefing is generated, the bot pushes a notification to the client's private Telegram chat. The message contains: risk level, jurisdiction, one-sentence summary, and a link to the full briefing in the app. Setup: client provides their Telegram user ID; bot is added to a private channel. Implementation: Python/Node.js bot, hosted on a free tier (Railway, Render, Fly.io). Cost: zero.

**Strategy 262 · RSS feed per client — private, authenticated**
Generate a private RSS feed URL per client (authenticated with a secret token). The feed contains their briefings in standard RSS format. Any RSS reader (Feedly, Reeder, NetNewsWire, Readwise Reader) can subscribe. No additional infrastructure needed beyond a PHP endpoint that outputs RSS XML from the briefing database. Cost: zero. Benefit: clients who prefer their own reader get seamless integration without any app.

**Strategy 263 · Webhook delivery — Zapier, n8n, Make compatible**
When a briefing is published, POST a JSON payload to a client-specified webhook URL. The payload includes: risk level, jurisdiction, briefing ID, confidence score, and a one-paragraph summary. Clients can then use Zapier (free tier), n8n (self-hosted, free), or Make to route this into any tool they use: Notion, Obsidian, Airtable, Slack, email, SMS. Implementation: a single HTTP POST call from the briefing publication workflow. Cost: zero server-side.

**Strategy 264 · ICS calendar feed — filing deadlines and review dates**
Generate a per-client ICS calendar feed (authenticated URL) containing: regulatory filing deadlines, residency renewal dates, watchpoint review dates, and quarterly analyst check-in dates. Apple Calendar, Google Calendar, Outlook all subscribe to ICS feeds natively. When an analyst adds a deadline to a client's profile, it appears in the client's calendar automatically. Implementation: a PHP endpoint generating iCalendar format. Cost: zero.

**Strategy 265 · Email digest via SMTP — use existing Hostinger email**
The briefing digest email can be sent via Hostinger's SMTP, which is included in the hosting plan. Build a PHP mailer that sends a formatted HTML email once per week to each client's registered address. No third-party email service required until volume justifies it (Resend/Postmark free tiers cover the first 3,000 emails/month anyway). Cost: zero.

**Strategy 266 · Signal platform integration — disappearing messages option**
Signal's sealed sender protocol provides metadata resistance that Telegram lacks. Build the ability to deliver critical briefings via Signal using a dedicated Mebusan Signal number. Implementation: Signal-CLI (open source, free) on a VPS. Clients register their Signal number; critical alerts are sent as disappearing messages (set to 1 week). Cost: VPS hosting (~$5/month), otherwise zero.

**Strategy 267 · OFAC SDN diff notification — free API**
The OFAC SDN list is updated multiple times per week. Build an automated comparison between the current and previous list. When a new designation is added in a client-relevant jurisdiction or sector, automatically generate a draft briefing flagging the change. The full OFAC dataset is freely downloadable via OFAC.treasury.gov as XML/CSV. Automated diff using Python. Cost: zero.

**Strategy 268 · IMF World Economic Outlook API — free**
IMF publishes a comprehensive free API at imf.org/external/datamapper with all WEO data: GDP growth, inflation, current account, reserves. Build automated alerts when key indicators for monitored jurisdictions cross predefined thresholds — e.g., when the IMF projects a country's current account deficit to widen by more than 2% of GDP. This supplements market data with institutional assessments. Cost: zero.

**Strategy 269 · World Bank Open Data API — free**
World Bank publishes free APIs for: governance indicators, doing business index, financial inclusion data, and poverty metrics. Use to build structural country risk scores that update annually and supplement the real-time signal layer. When a country's governance indicator deteriorates significantly in the annual update, trigger a structure review recommendation. Cost: zero.

**Strategy 270 · GDELT event monitoring — free, real-time**
The GDELT Project provides a free, real-time feed of global events classified by type, location, and actor. Monitor for event types relevant to Mebusan: financial/economic crisis (event code 1210+), capital flight (1211), banking restrictions (1612), government economic interventions (1630-1640). GDELT updates every 15 minutes and provides a free BigQuery interface. Cost: zero within BigQuery free tier.

**Strategy 271 · RSS gazette monitoring — free**
Many central banks and regulators publish RSS feeds of their press releases and official gazette notifications. Build a supervised RSS aggregator that monitors: CBRT (Turkey), UAE Ministry of Finance, MAS (Singapore), Bank of England, ECB, FATF, OFAC. Filter incoming items for keywords relevant to client profiles. When a match is found, route to the analyst queue as a potential briefing trigger. Implementation: standard RSS parsing in Python. Cost: zero.

**Strategy 272 · Cloudflare Workers for signal processing — free tier**
Cloudflare Workers provides a generous free tier (100,000 requests/day) for serverless functions. Use to build lightweight signal processing functions: FX rate comparisons, gazette text classification, threshold crossing detection. The low latency of edge computing means signals are processed faster than traditional server architectures. Cost: zero on free tier.

**Strategy 273 · GitHub Actions for automated monitoring — free**
GitHub Actions provides 2,000 free minutes per month for private repositories. Use to run scheduled monitoring jobs: daily OFAC SDN diff, weekly IMF data pull, monthly BIS banking statistics update. Each workflow runs Python scripts that update the signal database and trigger analyst alerts when thresholds are crossed. Cost: zero.

**Strategy 274 · Plausible Analytics for website — privacy-first, €9/month or self-hosted free**
Replace Google Analytics (privacy invasive, GDPR-problematic) with Plausible.io. Self-hosted version is free and can be deployed on Mebusan's existing server. Provides: page views, referral sources, device data, and importantly — where the application drop-off happens. This data directly improves conversion without the privacy contradiction of a private intelligence service using Google tracking. Cost: zero (self-hosted).

---

## SECTION IV — NEW FUNCTIONALITY IDEAS

**Strategy 275 · Pre-crisis simulation mode**
A dedicated screen where a client can run a "what if" scenario: select a jurisdiction and a crisis type (capital controls / banking closure / sanctions designation / currency devaluation), and see what the impact would be on their specific assets based on their deep profile data. Display: which assets are affected, estimated financial impact range, available response options, and time-to-act estimate. This is not prediction — it is preparation. Build as a tap-through scenario tree.

**Strategy 276 · Anonymous shared briefing — forward to adviser**
Allow a client to generate a one-time shareable link for a specific briefing, stripped of their personal profile data, that they can forward to their lawyer, accountant, or family adviser. The link expires after 48 hours and requires a code to access. This allows clients to act on intelligence with their advisers without copying and pasting sensitive content into email. Build as a "Share brief" button on the article view with a QR code option.

**Strategy 277 · Exit velocity calculator per asset**
For each asset in the client's profile, calculate and display: realistic time to liquidate under current market conditions, estimated capital control window if current signals escalate, and recommended action timeline. Display as: "If Turkey crosses 8% parallel premium, you have approximately 3–6 weeks before restrictions typically formalise. Your transfer from Garanti would take 2–5 business days under current conditions." This converts abstract risk into concrete decision-making context.

**Strategy 278 · Jurisdiction safe-haven alternative finder**
When a jurisdiction is flagged, the app should proactively suggest alternatives: "Banking in Turkey is under pressure. Clients in similar situations have used: Wise (TRY→EUR direct), ING Netherlands (EUR account for Turkish residents), or Julius Bär Singapore (private banking with TRY-to-USD conversion)." Not a recommendation — a set of options to explore. Build as a collapsible section within the country risk profile.

**Strategy 279 · Analyst handoff protocol — visible to client**
When an analyst is on leave, changes role, or leaves Mebusan, the client should receive a proactive notification: "Your analyst Ahmad Karimi is on leave until [date]. During this period, your coverage will be managed by [name], MENA Specialist, [N] years experience. Your full briefing profile and context has been transferred." This prevents the anxiety of a silent handoff that makes clients feel their intelligence relationship has broken down.

**Strategy 280 · Risk score changelog — why did it change?**
When a jurisdiction's risk score changes (from 3 to 4, or from Watch to Flag), clients should receive a brief explanation of what changed and why. Not just "Turkey elevated to 4/5" but "Turkey elevated from Watch to Flag: parallel rate crossed 6%, reserve drawdown accelerated, and analyst contact in Istanbul confirmed restricted transfer processing at two major banks." The changelog makes the score system transparent and builds confidence in the model.

**Strategy 281 · Intelligence archive — lifetime access guarantee**
Promise clients that their briefing archive is stored permanently and will remain accessible even if they cancel their subscription (read-only mode for 24 months after cancellation). This is a strong trust signal: we are not holding their data hostage. It also means clients maintain an intelligence record of everything that happened during their subscription, which has genuine legal and advisory value.

**Strategy 282 · Structured data export — PDF and JSON**
Allow clients to export their full briefing history as: a formatted PDF (for sharing with advisers), a JSON file (for developers who want to build their own tools), or a CSV (for analysis in Excel). Include: briefing date, jurisdiction, risk level, confidence score, analyst name, source types. This gives clients full data portability and is a privacy-positive feature that builds trust.

**Strategy 283 · Compliance-ready audit report generation**
For clients who need to demonstrate to advisers, lawyers, or regulators that they were monitoring their cross-border exposure and received timely warnings, generate a formatted compliance audit report: "Between January and April 2026, the following risks were flagged, the following briefings were delivered, and the following actions were recommended." This makes Mebusan intelligence usable in a legal or regulatory context.

**Strategy 284 · Mebusan Score — single number per jurisdiction**
Distil each jurisdiction's full risk profile into a single Mebusan Score on a 1–10 scale. Not the multi-dimensional view — just one number that a busy client can glance at. Display prominently on the home screen next to each asset card. Update weekly. Show the delta from last week. This is the Bloomberg Risk Score equivalent for private wealth. Simple enough for a 5-second scan, granular enough to be meaningful.

**Strategy 285 · Automated regulatory filing calendar**
Pull from the strategy document: for each jurisdiction where a client has a structure, automatically build a compliance calendar with: company annual returns, trust deed review deadlines, UBO disclosure updates, tax return deadlines (where applicable), and economic substance filing dates. Push these to the client's calendar integration and display them in the app as a timeline view. Never let a client miss a filing deadline that could compromise their structure.

---

## THINGS YOU NEED TO DO — PRIORITY LIST

### Immediate (before any more building)

**1. Register com.mebusan.app as an Apple Services ID**
Go to developer.apple.com → Certificates, Identifiers & Profiles → Identifiers → + → Services IDs. Register `com.mebusan.app`, enable Sign In with Apple, add `mebusan.com` as domain, set redirect URI to `https://mebusan.com/api/auth.php`. Without this, the Apple Sign In button will fail in production.

**2. Rotate the compromised Twilio auth token**
The auth token `d94b23dae265a0143f699e90eacee216` was exposed. Go to Twilio console → Account → API Keys → revoke and regenerate. Update `config.php` on the server.

**3. Create the four Stripe products**
Go to Stripe Dashboard → Products → Create product for each tier:
- Monitor: $490/month and $415/month (annual)
- Advisory: $990/month and $840/month (annual)
- Private: $2,500/month and $2,125/month (annual)
Save the price IDs and update `config.php`.

**4. Upload sitemap.xml to Hostinger**
After deploying keremalbayrak.com — open the browser console on the live site, run `downloadSitemap()`, upload the resulting file to `public_html/sitemap.xml`. Then submit in Google Search Console.

**5. Register Mebusan AI PTE LTD with ACRA Singapore**
If not done: bizfile.acra.gov.sg → register the company. You need the UEN for invoicing, contracts, and the app's legal footer.

### Infrastructure (month 1)

**6. Set up the cron jobs on mebusan.com**
In Hostinger hPanel → Cron Jobs, add:
```
0 */4 * * *   curl -s "https://mebusan.com/api/blog.php?action=generate"
0 * * * *     curl -s "https://mebusan.com/api/forex.php?refresh=1"
*/30 * * * *  curl -s "https://mebusan.com/api/risk.php?refresh=1"
0 6 * * *     curl -s "https://mebusan.com/api/sanctions.php?refresh=1"
```

**7. Add Anthropic API key to config.php on both servers**
Without this: auto-article generation on keremalbayrak.com fails silently. Blog generation on mebusan.com fails. The AI support agents in the app will fail. Go to console.anthropic.com → API Keys → generate. Add to `/path/to/config.php` as `define('ANTHROPIC_API_KEY', 'sk-ant-...')`.

**8. Create the cache directories on mebusan.com server**
SSH or File Manager: create `/public_html/cache/blog/`, `/cache/forex/`, `/cache/intel/`, `/cache/risk/`, `/cache/alerts/`, `/cache/ka/`. Without these, the PHP caching system writes to the root and fails.

**9. Build the analyst admin panel (minimal viable)**
You need a simple password-protected web interface where you (the analyst) can: create a new briefing, assign it to a client, set the jurisdiction, risk level, and confidence score, and send it. Even a simple HTML form with PHP backend that writes to a JSON file is enough to start. The app reads from this file. This is the missing piece that makes the intelligence product actually deliverable.

**10. Set up OFAC SDN diff monitoring**
Download the OFAC SDN list today as a baseline: https://www.treasury.gov/ofac/downloads/sdnlist.txt. Set up a daily GitHub Action or cron job that downloads the current list, diffs against yesterday's, and emails you the additions. Cost: zero. This is strategy 267 implemented in one afternoon.

### Intelligence infrastructure (month 2)

**11. Build your source network — start with Turkey and UAE**
For Turkey: identify two Istanbul-based banking contacts (try LinkedIn, attend Turkey finance webinars, reach out through Turkish finance journalists). For UAE: connect with Dubai-based compliance officers, law firms in DIFC. These should be informal relationships — contacts who will answer a WhatsApp message. This is the human intelligence layer that makes everything else credible.

**12. Set up Telegram Bot for your own use first**
Build the Telegram bot for your own alerts before deploying to clients. Create a bot via @BotFather, set up a private channel, configure the webhook to push OFAC diffs and IMF data alerts to you. Test it for 30 days. Then extend to clients. Cost: zero.

**13. Create the methodology page on mebusan.com**
The "How we work" screen is now in the app. Build the equivalent as a standalone page at mebusan.com/methodology. Three sections: Intelligence vs Research, How a briefing is produced, Source types. This page is referenced in the app but needs to exist on the website. Use the content from the sc-methodology screen.

**14. Write the first three genuine intelligence briefings**
Not articles — actual briefings in the format of the app. Turkey banking risk (using real CBRT data). Singapore MAS UBO deadline (using the actual circular). UAE AML property compliance (using real DLD data). These become the first three entries in the app's briefing archive and demonstrate product quality before you have clients.

**15. Set up the warrant canary**
The page already exists at mebusan.com/warrant-canary.html. Sign and date it. Set a monthly calendar reminder to update it. If you ever receive a court order and cannot update it, sophisticated clients will understand what that means. This is a trust mechanism that costs nothing and signals seriousness.

### Growth (month 3+)

**16. Submit mebusan.com sitemap to Google Search Console**
Same process as keremalbayrak.com. Once the sitemap.xml is on the server, go to Search Console, add the property, and submit.

**17. Build the referral code system**
Simple implementation: a PHP function that generates a unique 8-character code per client, stores it in the database with the client ID, and checks it against the apply.html form. When used, flag the application as referred and credit the referring client one month. Build this before you have clients to refer — it is much harder to retrofit.

**18. Attend one intelligence or private wealth event in the next 90 days**
STEP (Society of Trust and Estate Practitioners) runs events in Dubai, Singapore, and London. These are attended by your exact target client's advisers. Presence at one event is worth more than months of digital marketing. Go not to present or sponsor — go to listen and meet people informally.

---

*Mebusan AI PTE LTD · Singapore · Strategy document — internal*
