<?php
/**
 * MEBUSAN · Test email send
 * Usage:  php scripts/test-email.php you@example.com welcome-01-immediate
 *
 * Loads .env, instantiates MebusanMailer, renders the named template,
 * and sends it to the given address. Reports success/failure.
 */

declare(strict_types=1);

// Load .env if present
$envFile = dirname(__DIR__) . '/.env';
if (is_readable($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        if (!str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        putenv(trim($k) . '=' . trim($v));
    }
}

require_once dirname(__DIR__) . '/website/emails/lib/mailer.php';

$to       = $argv[1] ?? '';
$template = $argv[2] ?? 'welcome-01-immediate';

if (!$to || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
    echo "Usage: php scripts/test-email.php <to@email> [template-slug]\n";
    exit(1);
}

echo "Sending $template to $to via " . (getenv('MEBUSAN_MAIL_PROVIDER') ?: 'resend') . "...\n";

$mailer = new MebusanMailer();
$result = $mailer->send([
    'to'       => $to,
    'to_name'  => 'Test Recipient',
    'template' => $template,
    'vars'     => [
        'name'                => 'Test Client',
        'name_slug'           => 'test',
        'tier'                => 'Advisory',
        'confirmation_id'     => 'MBSN-TEST-001',
        'first_briefing_date' => 'Monday, 28 April',
        'response_window'     => '24 hours',
        'coverage_summary'    => 'Turkey, UAE, Switzerland',
        'analyst_name'        => 'S. Aldemir',
        'analyst_first'       => 'S.',
        'analyst_email'       => 'desk@mebusan.com',
        'backup_analyst'      => 'desk@mebusan.com',
        'document_id'         => 'MBSN-DOC-TEST',
        'sign_url'            => 'https://mebusan.com/sign.html?t=TEST',
        'expires_at_human'    => '22 July 2026',
        'signed_at_human'     => date('j M Y · H:i') . ' UTC',
        'method'              => 'DRAWN',
        'document_hash_short' => 'abc123def456789a...',
        'code'                => '847329',
        'request_context'     => 'Test from CLI',
        'ip_masked'           => '127.0.•.••',
    ],
    'category' => 'test',
]);

echo json_encode($result, JSON_PRETTY_PRINT) . "\n";
exit($result['success'] ? 0 : 1);
