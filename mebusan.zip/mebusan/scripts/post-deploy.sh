#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# MEBUSAN · Post-deploy (run on the Hostinger host after rsync lands)
# Creates writable runtime directories, fixes permissions, verifies
# critical files are in place.
# ═══════════════════════════════════════════════════════════════════

set -euo pipefail
cd "$(dirname "$0")/.." || exit 1

echo "── Post-deploy ──"
echo "Working directory: $(pwd)"

# ── Create writable cache dirs ─────────────────────────────────
DIRS=(
    "cache"
    "cache/email_queue"
    "cache/email_sent"
    "cache/email_log"
    "cache/pdf_cache"
    "cache/critical_alerts"
    "cache/signatures"
    "cache/signed_documents"
    "cache/rate_limits"
    "cache/csrf_tokens"
    "cache/sessions"
    "cache/audit_log"
    "cache/signals"
    "cache/signals/pending"
    "cache/signals/approved"
    "cache/signals/rejected"
    "cache/signals/public"
    "cache/ingest"
    "cache/verify"
    "cache/verified"
    "cache/rate-verify"
    "cache/og"
)

for dir in "${DIRS[@]}"; do
    if [[ ! -d "$dir" ]]; then
        mkdir -p "$dir"
        echo "  created $dir"
    fi
done

# ── Permissions ────────────────────────────────────────────────
chmod 755 cache cache/*/ 2>/dev/null || true
find cache -type f -exec chmod 644 {} \; 2>/dev/null || true

# ── Verify critical files ──────────────────────────────────────
REQUIRED=(
    ".htaccess"
    "cache/.htaccess"
    "admin/.htaccess"
    "api/.htaccess"
    "api/_security.php"
    "emails/.htaccess"
    "emails/lib/mailer.php"
    "emails/queue.php"
    "sign.html"
)

MISSING=()
for f in "${REQUIRED[@]}"; do
    if [[ ! -f "$f" ]]; then
        MISSING+=("$f")
    fi
done

if [[ ${#MISSING[@]} -gt 0 ]]; then
    echo ""
    echo "WARNING: missing critical files:"
    printf '  %s\n' "${MISSING[@]}"
fi

# ── PHP sanity check ───────────────────────────────────────────
if command -v php &>/dev/null; then
    echo ""
    echo "── PHP sanity check ──"
    php -v | head -1

    # Lint the security layer
    if ! php -l api/_security.php &>/dev/null; then
        echo "ERROR: api/_security.php has syntax errors"
        php -l api/_security.php
    else
        echo "  _security.php  OK"
    fi

    if ! php -l emails/lib/mailer.php &>/dev/null; then
        echo "ERROR: emails/lib/mailer.php has syntax errors"
        php -l emails/lib/mailer.php
    else
        echo "  mailer.php     OK"
    fi

    if ! php -l emails/queue.php &>/dev/null; then
        echo "ERROR: emails/queue.php has syntax errors"
        php -l emails/queue.php
    else
        echo "  queue.php      OK"
    fi
fi

echo ""
echo "── Done ──"
echo ""
echo "Remaining manual steps:"
echo "  1. Verify cron jobs are set (ingest-signals hourly, cron 5-min, queue 5-min)"
echo "  2. Add SPF/DKIM/DMARC DNS records if not already done"
echo "  3. Verify mail provider domain"
echo "  4. Test the signup flow end-to-end"
