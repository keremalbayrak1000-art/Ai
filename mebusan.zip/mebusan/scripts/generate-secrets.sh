#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# MEBUSAN · Secret generator
# Prints secure random values for MEBUSAN_SECRET, MEBUSAN_INTERNAL_KEY,
# UNSUB_SECRET to stdout. Append to .env:
#
#   ./scripts/generate-secrets.sh >> .env
#
# Or copy-paste the values into Hostinger's environment UI.
# ═══════════════════════════════════════════════════════════════════

set -euo pipefail

# openssl is on every modern system; use it for 32 bytes of entropy
gen() {
    openssl rand -hex 32
}

echo ""
echo "# ── Secrets generated $(date -u +"%Y-%m-%dT%H:%M:%SZ") ──"
echo "MEBUSAN_SECRET=$(gen)"
echo "MEBUSAN_INTERNAL_KEY=$(gen)"
echo "UNSUB_SECRET=$(gen)"
echo ""
echo "# To hash an admin password:"
echo "#   php -r \"echo password_hash('YOUR_PASSWORD_HERE', PASSWORD_BCRYPT);\""
echo ""
