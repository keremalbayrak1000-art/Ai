#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# MEBUSAN · Deploy script
# Rsyncs website/ to Hostinger public_html/ via SSH.
#
# Requires:
#   - SSH access to Hostinger (set up key-based auth first)
#   - SSH host configured in ~/.ssh/config as "mebusan" — example:
#
#     Host mebusan
#         HostName your-host.hostinger.com
#         User u1234567
#         IdentityFile ~/.ssh/mebusan_ed25519
#         Port 65002
#
# Usage:
#   ./scripts/deploy.sh              # deploy to production
#   ./scripts/deploy.sh --dry-run    # preview changes without pushing
# ═══════════════════════════════════════════════════════════════════

set -euo pipefail

HOST_ALIAS="${MEBUSAN_SSH_ALIAS:-mebusan}"
REMOTE_PATH="${MEBUSAN_REMOTE_PATH:-public_html}"
LOCAL_PATH="website/"
DRY_RUN_FLAG=""

if [[ "${1:-}" == "--dry-run" ]]; then
    DRY_RUN_FLAG="--dry-run"
    echo "── DRY RUN ── no files will be written ──"
fi

# ── Pre-flight checks ──────────────────────────────────────────
if [[ ! -d "$LOCAL_PATH" ]]; then
    echo "Error: run this from the repo root, not $(pwd)" >&2
    exit 1
fi

if [[ ! -f ".env" ]]; then
    echo "Warning: no .env found locally. That's fine if you've configured env vars on the server directly."
fi

# Confirm before pushing to prod
if [[ -z "$DRY_RUN_FLAG" ]]; then
    echo "About to deploy to $HOST_ALIAS:$REMOTE_PATH/"
    read -p "Continue? (y/N) " -n 1 -r
    echo ""
    [[ ! $REPLY =~ ^[Yy]$ ]] && exit 0
fi

# ── Run rsync ──────────────────────────────────────────────────
rsync \
    --archive \
    --compress \
    --human-readable \
    --delete \
    --delete-excluded \
    --itemize-changes \
    $DRY_RUN_FLAG \
    --exclude='cache/email_queue/*.json' \
    --exclude='cache/email_sent/*' \
    --exclude='cache/email_log/*' \
    --exclude='cache/signatures/*.json' \
    --exclude='cache/signed_documents/*.pdf' \
    --exclude='cache/critical_alerts/*' \
    --exclude='cache/rate_limits/*' \
    --exclude='cache/csrf_tokens/*' \
    --exclude='cache/sessions/*' \
    --exclude='cache/audit_log/*.log' \
    --exclude='cache/signals/*/*.json' \
    --exclude='cache/ingest/*' \
    --exclude='cache/verify/*' \
    --exclude='cache/verified/*' \
    --exclude='cache/og/*' \
    --exclude='cache/email_prefs.json' \
    --exclude='.DS_Store' \
    --exclude='*.swp' \
    --exclude='*.tmp' \
    --exclude='*.bak' \
    "$LOCAL_PATH" \
    "$HOST_ALIAS:$REMOTE_PATH/"

if [[ -z "$DRY_RUN_FLAG" ]]; then
    echo ""
    echo "── Deployed ──"
    echo "Next: ssh $HOST_ALIAS 'cd $REMOTE_PATH && bash scripts/post-deploy.sh'"
    echo "(or run scripts/post-deploy.sh manually on the host)"
fi
