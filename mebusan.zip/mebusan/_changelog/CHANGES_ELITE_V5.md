# CHANGES · ELITE v5 · E-sign + security hardening + GitHub-ready

**v5 is v4 + e-sign flow + comprehensive security hardening + GitHub repo structure.**
No regressions from v4. All prior features preserved.

---

## E-sign flow

### Vector signature capture in pure PHP

Added `emails/lib/pdf-signature.php` — a MinPDF extension that renders browser-captured canvas strokes as native PDF vector paths. Not raster images. This means:

- Signed PDFs stay small (tens of KB, not megabytes)
- Signatures scale cleanly at any zoom level
- The PDF hash is deterministic, making it cryptographically verifiable

### Engagement letter PDF generator

`emails/pdf/engagement-letter.php` — 5-page engagement letter that renders differently based on whether signature data is provided:

- **Unsigned** (default): 5 pages ending with a blank signature panel and instructions to sign online
- **Signed**: Same 5 pages plus a 6th attestation page with:
  - Vector signature (drawn) or typed-italic rendering (typed)
  - Timestamp (UTC ISO-8601)
  - Masked IP
  - Document ID (`MBSN-DOC-...`)
  - Base-document SHA-256 hash
  - Attestation text

### Signing page · `/sign.html`

Self-contained HTML, zero dependencies, matches Mebusan aesthetic exactly:

- Josefin Sans wordmark header (via system fallback, no external font)
- PDF viewer (browser-native, no PDF.js)
- Canvas signature with pressure-sensitive strokes + smoothing
- Typed-signature fallback (styled italic serif)
- Consent checkbox (required before submit enables)
- Frame-busting + CSP-hardened
- Bot heuristics: rejects if session < 3s or interactions < 3

### Success page · `/sign-complete.html`

Post-sign confirmation with attestation display (document, timestamp, method, hash).

### Server endpoints (four)

- `api/sign-request.php` — creates signing session, issues HMAC token, called server-side from signup flow
- `api/sign-session.php` — GET lookup of session metadata (redacted) or post-sign verification
- `api/sign-doc.php` — streams the unsigned or signed PDF with strict cache headers
- `api/sign-submit.php` — validates payload, generates signed PDF, persists, audit-logs, emails countersigned copy

### Two new email templates

- `engagement-sign-required` — sent on payment success with unsigned PDF attached and sign link
- `engagement-signed` — countersigned copy with signed PDF attached and green attestation box

### Onboarding orchestration

`emails/queue.php::scheduleOnboarding($recipient)` — new method that:

1. Creates signing session
2. Fires engagement-sign-required immediately
3. Schedules welcome-01 at T+5 minutes
4. Schedules welcome-02 through welcome-07 at T+1h / T+4h / T+24h / T+3d / T+7d / T+14d

The client sees signing first, then the full welcome sequence unfolds regardless of when they sign.

---

## Security hardening

### Server-level (`.htaccess` stack)

- **Root `.htaccess`** — force HTTPS, HSTS 2 years, strict CSP with Stripe allowances, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, Cross-Origin-* policies, remove server fingerprinting, block common scanner probes (wp-admin, .env, .git), deny dotfiles and backup extensions
- **`cache/.htaccess`** — total lockdown: deny all direct access, block PHP execution as defense-in-depth
- **`admin/.htaccess`** — max isolation: no caching, DENY framing, stricter CSP, optional IP allowlist
- **`api/.htaccess`** — API-specific: no caching, DENY framing, block shared includes (`_*.php`)
- **`emails/.htaccess`** — only three public entrypoints reachable (send.php, unsubscribe.php, queue.php); everything else denied

### PHP security layer · `api/_security.php`

- **Derived keys** — master secret derives per-purpose HMAC keys (signing, unsub, session) via `MebusanSecurity::secret($purpose)`
- **Rate limiting** — per-IP + per-endpoint file-based counter, customisable window/limit, automatic `429 Retry-After` + audit log
- **CSRF** — double-submit tokens via `csrfToken()` / `requireCsrf()`
- **HMAC signing tokens** — stateless, for e-sign/unsub/reset flows, `issueSigningToken()` / `verifySigningToken()`
- **Secure sessions** — `SameSite=Strict`, `HttpOnly`, `Secure`, periodic regeneration
- **Audit log** — append-only at `cache/audit_log/YYYY-MM.log`, masked IP + masked UA
- **Input sanitisers** — `str()`, `email()`, `phoneE164()`, `int()` with bounds
- **IP helpers** — `clientIp()` with optional proxy trust, `maskIp()` / `maskEmail()`
- **Admin IP allowlist** — CIDR-aware via `requireAdminIp()`
- **Honeypot + timing checks** — `honeypotCheck()` / `timingCheck()` for signup-style forms
- **Uniform API headers** — `applyApiHeaders()` sets CSP, X-Frame-Options, Permissions-Policy, etc.

### Client-side security · `js/security.js`

Loaded on every page:

- Frame-busting (backed up by CSP `frame-ancestors`)
- Automatic honeypot injection into all forms (hidden field + load-time marker)
- Fetch wrapper adds `X-CSRF-Token` and `X-Mebusan-Ctx` (ms + interactions + tz) on same-origin state-changing requests
- `.secure-content` class disables right-click, copy, print keyboard shortcuts
- Sensitive clipboard auto-clear (30 second expiry) via `mebusanCopySensitive(text)`
- Soft devtools detection with Mebusan-branded console warning
- `window.opener` nulling from untrusted referrers

### What this stack protects against

| Threat | Defence |
|---|---|
| Scraping / recon | `.htaccess` + CSP + fingerprint removal |
| Credential stuffing | Rate limit + bcrypt + IP allowlist |
| Session hijacking | SameSite=Strict + HttpOnly + Secure + regeneration |
| CSRF | Double-submit tokens |
| Clickjacking | X-Frame-Options + frame-ancestors + JS bust |
| XSS | Strict CSP + input sanitisers |
| MITM / downgrade | HSTS + upgrade-insecure-requests |
| Enumeration | Constant-time `hash_equals` |
| E-sign forgery | HMAC + document hash anchoring |
| Bot signup | Honeypot + timing + interaction count |
| Data exfiltration | Per-purpose keys + .htaccess cache lockdown |

---

## GitHub-ready structure

### Root-level files

- `CLAUDE.md` — master context file that Claude Code auto-reads on every session (replaces the paste-prompt entirely)
- `README.md` — GitHub landing page
- `LICENSE` — proprietary, all rights reserved
- `.gitignore` — excludes secrets and runtime state
- `.env.example` — complete env-var template

### `docs/`

- `SECURITY.md` — threat model, defence layers, operator checklist, incident response
- `BRAND.md` — expanded voice + colour + typography + forbidden words
- `EMAIL.md` — email system architecture, provider setup, template inventory, DNS requirements
- `SIGNING.md` — e-sign flow details, security properties, legal standing, operational concerns
- `DEPLOYMENT.md` — complete Hostinger deployment guide

### `scripts/`

- `generate-secrets.sh` — one command produces crypto secrets for .env
- `deploy.sh` — rsync to Hostinger with safe exclusions and confirmation prompt
- `post-deploy.sh` — runs on host: creates cache dirs, sets perms, lints PHP, verifies critical files
- `test-email.php` — send any template to any address for deliverability testing

### Workflow for Claude Code on Mac

```bash
git clone git@github.com:YOUR/mebusan.git
cd mebusan
```

Open in Cursor, Zed, VS Code, or Claude Code CLI. Start a session. `CLAUDE.md` is auto-loaded. Ask for what you want. No context-pasting needed.

---

## File tree additions · v4 → v5

```
mebusan/
├── CLAUDE.md                                  [NEW · auto-loaded by Claude Code]
├── LICENSE                                    [NEW]
├── .env.example                               [NEW]
├── .gitignore                                 [NEW]
├── README.md                                  [UPDATED]
│
├── docs/                                      [NEW directory]
│   ├── SECURITY.md
│   ├── BRAND.md
│   ├── EMAIL.md
│   ├── SIGNING.md
│   └── DEPLOYMENT.md
│
├── scripts/                                   [NEW directory]
│   ├── generate-secrets.sh
│   ├── deploy.sh
│   ├── post-deploy.sh
│   └── test-email.php
│
└── website/
    ├── .htaccess                              [NEW · root security]
    ├── sign.html                              [NEW · signature capture]
    ├── sign-complete.html                     [NEW · post-sign success]
    │
    ├── cache/.htaccess                        [NEW · cache lockdown]
    ├── admin/.htaccess                        [NEW · admin hardening]
    ├── api/.htaccess                          [NEW · API hardening]
    ├── emails/.htaccess                       [NEW · email lockdown]
    │
    ├── js/security.js                         [NEW · client-side helpers]
    │
    ├── api/
    │   ├── _security.php                      [NEW · shared security layer]
    │   ├── sign-request.php                   [NEW]
    │   ├── sign-session.php                   [NEW]
    │   ├── sign-doc.php                       [NEW]
    │   └── sign-submit.php                    [NEW]
    │
    └── emails/
        ├── lib/pdf-signature.php              [NEW · vector sig rendering]
        ├── pdf/engagement-letter.php          [NEW · 5+1 page PDF]
        ├── templates/engagement-sign-required.{html,txt}   [NEW]
        └── templates/engagement-signed.{html,txt}          [NEW]
```

Plus: `emails/queue.php` gained `scheduleOnboarding()`, `emails/lib/mailer.php` gained `attach_raw_pdf` support, `emails/lib/pdf.php` properties changed from private to protected for extension support.

---

## Operator to-do delta from v4

New items:

- Run `./scripts/generate-secrets.sh` to populate `.env` crypto values
- Set `MEBUSAN_SECRET` (64-char hex) on Hostinger env
- Set `ADMIN_PASSWORD_HASH` (bcrypt via `password_hash`)
- Create `cache/signatures`, `cache/signed_documents`, `cache/rate_limits`, `cache/csrf_tokens`, `cache/sessions`, `cache/audit_log` subdirs (auto-handled by `post-deploy.sh`)
- Submit site to `hstspreload.org` after 30 days of clean HSTS
- Optional: set `MEBUSAN_ADMIN_IPS` to your CIDR for belt-and-braces admin auth
- Optional: set `MEBUSAN_TRUST_PROXY=1` if using Cloudflare

Unchanged items from v4:

- Rotate compromised Twilio token
- Six Stripe products
- DNS records for email (SPF / DKIM / DMARC)
- Three cron jobs
- PGP key for warrant canary

---

## Deliverables

`mebusan.zip` — the full GitHub-ready repo. Extract, push to your GitHub repository, and Claude Code will have full context on every session via `CLAUDE.md`.

---

*Mebusan AI PTE LTD · Singapore · April 2026*
