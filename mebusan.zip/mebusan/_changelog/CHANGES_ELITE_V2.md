# CHANGES_ELITE_V2.md

**Session 3 addendum · 22 April 2026**  
Accumulated changes layered on top of `mebusan_v3_elite.zip` (v1) to produce `mebusan_v3_elite_v2.zip`.

---

## Headline

This session added 10x the structural depth of the previous v3 package: six new country deep-dives, five new blog posts, a full reference surface (glossary + methodology + editorial standards + governance + case studies), a founder's letter, a careers page, an admin moderation pipeline with server-side API, a site-wide service-worker registration, an RSS feed for the journal, and comprehensive sitemap coverage.

---

## 01 · Infrastructure

### Service worker registered site-wide
- New file: `js/sw-register.js` — shared registration script
- Injected into every main page (`about.html`, `pricing.html`, `apply.html`, `scanner.html`, `ask.html`, `wall.html`, `warrant-canary.html`, `services.html`, `faq.html`, `docs.html`, `intelligence.html`, `contact.html`, `discreet.html`, `anonymous.html`, `press.html`, `blog.html`, `portal.html`, `jurisdictions.html`) and every sub-folder page (`jur/*.html`, `journal/*.html`, `legal/*.html`, plus new `admin/moderate.html`)
- `index.html` uses inline SW registration plus `mebusan_last_visit` localStorage set for the offline page to surface

### Signal moderation pipeline
- **Ingest rewrite** (`api/ingest-signals.php`): new signals now land in `cache/signals/pending.json` by default. Admin must approve before they reach the Signal Wall. Legacy direct-write preserved behind `?bypass_moderation=1` flag for backfill/emergency.
- **Read path upgrade** (`api/signals.php`): prefers `cache/signals/public.json` (written by admin moderation API), falls back to legacy `cache/signals.json` for pre-moderation deployments.
- **New admin panel** (`admin/moderate.html`): tabbed pending/approved/rejected queue, inline actions (approve / edit-and-approve / reject / unpublish / restore), bulk-approve-high-confidence, trigger-ingest-now button, edit modal for pre-publication revision, 60s polling.
- **Server-side API** (`admin/moderate-api.php`): session-gated, bucket storage with atomic writes, audit logging to `cache/signals/moderation.log`, public.json sync on each write.

### Verify flow wired into apply
- `apply.html` `sendCode()` and `verifyCode()` now talk to `/api/verify.php` (the shared verify endpoint added in v1), supporting both SMS and email channels depending on which contact field the user filled. Dev mode support preserves local testing. Auto-advance to next step on successful verification.

---

## 02 · New country deep-dives (6)

All follow the jur-page template: status strip → hero with stats → current indicators → 90-day pipeline → active theses with confidence ratings → related coverage → CTA → footer.

| File | Posture | Focus |
|------|---------|-------|
| `jur/cyprus.html` | Watch | Non-dom regime, banking-sector rebuild post-2013, Russian-linked account lookback, Moneyval mid-cycle |
| `jur/malta.html` | Watch | MEIN framework, MFSA enforcement tempo, CJEU proceedings on CBI, Moneyval follow-up |
| `jur/luxembourg.html` | Stable | CSSF posture, AIFMD II transposition, SOPARFI/RAIF vehicles, ELTIF 2.0 |
| `jur/monaco.html` | Stable | Residency scarcity, banking concentration (ACPR-supervised), AEOI maturity, property absorption |
| `jur/hong-kong.html` | Watch | Article 23 Year 2, HKMA posture, cross-booking to Singapore, CEPA/GBA integration |
| `jur/israel.html` | Watch | Olim ten-year exemption, BoI policy, banking posture, counterparty texture for non-resident relationships |

### Jurisdictions index upgrade
- `jurisdictions.html`: promoted all 6 new country cards from "client-only coverage" placeholders to linked deep-file cards with Last-signal timestamps
- Added Israel as a 17th EMEA jurisdiction
- Updated summary counts: 14 total public files, 6 stable, 17 EMEA juris with 11 public files, 13 APAC with 2 public files
- Updated hero copy from "Eight countries" to "Fourteen countries"

---

## 03 · New journal posts (5)

All follow the `post.css` template with post-back, post-head, post-meta, post-body, post-footer, post-cta, related-posts. Mebusan voice maintained.

| Slug | Length | Category | Summary |
|------|--------|----------|---------|
| `family-office-structure-test.html` | 7 min | Methodology | Six questions to ask about a proposed family office structure before the lawyers get expensive. Pre-counsel diligence framework. |
| `property-absorption-signal.html` | 9 min | Macro · Property | Residential property absorption as a capital-flow composition signal. Four metrics, three current readings (Dubai 71%, London shift, Singapore supply-constrained). |
| `uk-nondom-one-year-on.html` | 11 min | Policy | 12-month post-mortem on the UK non-dom regime end. 17% departure rate over 24 months, concentrated in two segments. What we got right and wrong. |
| `enforcement-tempo.html` | 8 min | Framework | Four patterns to read in regulatory enforcement tempo, three common pitfalls, three robust correlations with downstream events. |
| `hedge-vs-bet.html` | 10 min | Concept | Distinguishing genuine jurisdictional hedges from concentrated positions disguised as hedges. Four independence axes, three common failures, the real cost of hedging. |
| `what-private-intelligence-is-not.html` | 6 min | Editorial | Negative definition piece. What intelligence is frequently confused with (investigation, advisory, journalism, risk consulting, aggregation, commentary, politics) and the lines we hold. |

### Journal index
- `journal/index.html`: now lists all 11 posts (5 original + 6 new)
- Filter bar extended: Methodology, Macro, Regulation, Property, Policy, Framework, Editorial
- All posts dated and ordered newest-first

### Journal RSS feed
- New: `journal/feed.xml` — RSS 2.0 feed covering all 11 posts with GUIDs, categories, pubDates, and descriptions. Ready for `<link rel="alternate" type="application/rss+xml">` or readers like NetNewsWire.

---

## 04 · Reference surface (5 new pages)

### `glossary.html`
~80 domain terms across A through W with live client-side search filter, alphabet nav, and section hiding. Covers:
- Regulatory bodies (CSSF, CBC, HKMA, MAS, ESMA, EBA, FINMA)
- Acronyms (AEOI, AIFMD, BO, CRS, FATCA, FATF, KYC, PEP, UBO, UCITS)
- Vehicles (SOPARFI, RAIF, ELTIF, FIHV, Section 13O/U)
- Macro terms (NEER, MPR, parallel rate, reserves, de-dollarisation)
- Mebusan constructs (active thesis, falsification path, documentation thickening, quiet re-pricing, source types, posture categories, human/signal/open source)
- Integration with corrections inbox at the foot for missing-term submissions

### `methodology.html`
Seven-section deep explanation of how we produce intelligence:
1. Source types (3-category framework with confidence weighting)
2. Weighting (independence check, incentive analysis, recency gating, confidence calibration)
3. Thesis construction (claim + confidence + falsification path + horizon)
4. Falsification discipline (publishing errors alongside predictions)
5. Cadence (daily/fortnightly/weekly/dedicated by posture)
6. Publication standards (substantive + specific + named filters)
7. What we do not do (negative definition: no execution, no prop positions, no contingent fees, no paid placement, no calendar-driven content)

### `editorial-standards.html`
Six-section editorial operations document:
1. Writing principles (lead with claim, specific instances behind general claims, calibrated confidence, no em-dashes)
2. Review process (3-person: analytical → editorial → adversarial)
3. Correction policy (typo / factual / interpretive / thesis-falsified / withdrawn matrix)
4. Voice and diction (no marketing register, no colour phrases, no "AI-powered", Latinate-over-colloquial for precision)
5. Machine-assistance transparency (bounded use, never for finished analytical text)
6. Conflicts and disclosures (proprietary positions, commercial relationships, source relationships, data origin)

### `governance.html`
Six-section governance document:
1. Ownership (founder-held, capital-structure-not-ethics framing)
2. Principals (founder, desk lead, corrections inbox, security & compliance)
3. Advisory (deliberately no formal advisory board; informal reader relationships without compensation)
4. Ethics framework (7-row table: proprietary positions, commercial referrals, contingent fees, client conflicts, source protection, data handling, machine assistance)
5. Succession (4-point protocol: client continuity, material publications, warrant canary, wind-down option)
6. Jurisdictional considerations (why Singapore: regulatory quality, client neutrality, PDPA, structural stability)

Includes top-of-page fact strip with legal entity, jurisdiction, ACRA status, and ownership posture.

### `case-studies.html`
Three anonymised client engagements:
- **Case 01**: Family office reading the correspondent-bank cycle correctly. EMEA, Private tier, 9 months. Shows 4-signal assembly, stage-2-to-3 progression, alternative establishment, outcome.
- **Case 02**: Principal reading regulatory consultation for sub-clause signal, not surface content. APAC, Advisory tier, 14 days. Identifying the question worth asking vs. answering it.
- **Case 03**: Jurisdiction posture change that clients did not want to hear. EMEA secondary tier, 11 clients affected, Stable → Watch. Willingness to publish against client preference.

Each case has context, observations, recommendation, and outcome block with amber-accented styling.

---

## 05 · Firm-voice pages (2 new)

### `letter.html`
Founder's letter from Kerem Albayrak. Drop-cap opening, three sections separated by thin dividers:
1. Why the firm exists (what adjacent industries answer, what was missing)
2. Capital structure as ethics foundation (founder-owned, will not take capital)
3. Four continuities clients should expect (voice, restraint, correction, independence)
Closes with personal "long private argument with reality" framing, then signature block with date and rev number.

### `careers.html`
Five-section honest careers page:
1. Shape of the firm (small, not a growth plan, contract-first path to perm)
2. What we hire for (careful writing, calibrated confidence, adversarial reading, self-correction, low need for volume)
3. Current openings: Desk analyst (open, contract-to-perm), Signals engineer (open, part-time), Client lead (watching, not hiring)
4. What the work is actually like (mostly reading, slow writing, rare meetings, output-only metric)
5. Compensation (fair not competitive-in-arms-race-sense, no equity, profit share, remote by default)

---

## 06 · Sitemap and surface

- `sitemap.xml`: rebuilt. 50+ entries covering all 14 country deep-dives, all 11 journal posts, new reference surface, letter, careers, trust pages, RSS feed
- `index.html` footer: restructured into 5 columns (Intelligence / Tools / Firm / Reference / Legal) surfacing all new pages; Journal nav link now points to `journal/index.html` instead of legacy `blog.html`

---

## 07 · What did NOT change this session

- Brand rules: untouched (Josefin Sans logo, cream/bg/amber/green palette, .5px borders, no em-dashes, no "AI-powered")
- Pricing: untouched ($290/$690/$1,200 monthly; $245/$585/$1,020 annual)
- Mobile app v7: untouched (still at `app/mebusan_app_v7.html`)
- Capacitor config: untouched
- App Store metadata: untouched
- PWA manifest: untouched
- Icons: untouched
- Warrant canary: already rebuilt in earlier pass; unchanged this session
- Legal pages (privacy, terms, security, transparency, dpa, gdpr): untouched this session, were rebuilt in earlier pass

---

## 08 · Operator action items unchanged from v1

These user TODOs carry across unchanged:

1. **URGENT:** Rotate compromised Twilio token `d94b23dae265a0143f699e90eacee216`
2. Set env vars: `ANTHROPIC_API_KEY`, Stripe keys + 6 price IDs, Twilio creds (new token), `ADMIN_PASSWORD_HASH`
3. Create 6 Stripe products (Monitor / Advisory / Private × monthly / annual)
4. Create cache subdirs on Hostinger: `cache/ingest`, `cache/verify`, `cache/verified`, `cache/rate-verify`, `cache/og`, **and now `cache/signals`** (for pending.json, approved.json, rejected.json, public.json, moderation.log)
5. Register Apple Services ID `com.mebusan.app`
6. Register with ACRA Singapore, add UEN to config
7. Submit sitemap.xml to Google Search Console
8. Set up cron: hourly `php api/ingest-signals.php` + 5-minute `php api/cron.php`
9. Run `icons/generate-pngs.sh` locally for PNG outputs
10. Generate PGP key for warrant canary signing

---

## 09 · New operator action items from this session

1. **Admin workflow change:** the Signal Wall now shows only moderation-approved signals. After deploying v2, log into `/admin/moderate.html` daily (or whenever cron runs ingest) to approve / reject / edit incoming signals. Bulk-approve-high-confidence button is available for the high-confidence items.
2. **Backfill consideration:** if the site already has live signals in `cache/signals.json`, run `api/ingest-signals.php?bypass_moderation=1` once to preserve them, or let moderation pipeline take over naturally (Signal Wall falls back to legacy file if `cache/signals/public.json` doesn't exist yet).
3. **RSS feed discovery:** add `<link rel="alternate" type="application/rss+xml" title="Mebusan Journal" href="/journal/feed.xml">` to the `<head>` of `index.html` if you want browsers/readers to auto-discover the feed. Minor, optional.
4. **Legal pages review:** the legal pages (privacy, terms, security, transparency, dpa) were written by the team; have counsel review before production launch if you have not already.
5. **Founder email in use:** `k.a@mebusan.com`, `desk@mebusan.com`, `corrections@mebusan.com` are all referenced across new pages. Ensure all three are deliverable.

---

## 10 · File count summary

| Surface | Before session 3 | After session 3 |
|---------|------------------|-----------------|
| Country deep-dives | 8 | 14 |
| Journal posts | 6 (5 substantive + index) | 12 (11 substantive + index + RSS) |
| Reference pages | 0 | 5 (glossary, methodology, editorial, governance, case studies) |
| Firm-voice pages | 1 (about) | 3 (+ letter, careers) |
| Admin panels | 5 | 6 (+ moderate.html) + moderate-api.php |
| Total HTML pages | ~45 | ~70 |
| Total lines of new HTML | — | ~8,500 |

---

**End of CHANGES_ELITE_V2.md**  
*22 April 2026 · Mebusan v3 elite v2 package*
