# CHANGES · ELITE v4 · Email lifecycle + critical alert system

**v4 is v3 + complete email infrastructure + critical-alert phone call system.**
No regressions from v3. All prior features preserved.

---

## Email lifecycle system

### Mailer infrastructure · `emails/lib/mailer.php`

Provider-agnostic sender supporting four backends via a single API:
- **Resend** (recommended) · API-based · best inbox-landing in class
- **Postmark** · transactional specialist
- **SendGrid** · enterprise option
- **SMTP** · fallback for any host with PHP mail access

Features:
- MIME multipart (text + HTML + CID-inlined logo + attachments) built natively
- RFC 8058 `List-Unsubscribe` + `List-Unsubscribe-Post` headers for Gmail / Outlook one-click
- Simple `{{var}}` template substitution with `{{subject: ...}}` first-line convention
- Per-send JSONL logging to `cache/email_log/YYYY-MM.log`
- Dry-run mode for testing without sending
- Automatic UTF-8 → quoted-printable encoding
- Hash-based unsubscribe tokens via `UNSUB_SECRET`

### Pure-PHP PDF generator · `emails/lib/pdf.php`

`MinPDF` class · zero dependencies · no Composer required.
- A4 pages (595 × 842 pt)
- Base-14 PDF fonts (Helvetica / Times / Courier in 4 styles each)
- Text positioning, word-wrapped paragraphs, rules, rectangles
- Mebusan signature `label()` method — tracked uppercase mono
- RGB fill + stroke colour control
- Document metadata (title, author, subject)
- Outputs valid PDF 1.4 bytes that render identically in all viewers

Works on any shared PHP host. No imagemagick, wkhtmltopdf, or Chrome required.

### 22 email templates

**Welcome sequence · 7 emails over 14 days** (auto-scheduled on signup):
1. `welcome-01-immediate` · "Your file is open" · welcome-pack PDF attached
2. `welcome-02-primer` · "How we think" · methodology PDF · +1h
3. `welcome-03-analyst` · "{{analyst_first}} here" · from the analyst · +4h
4. `welcome-04-first-briefing` · structure preview · +24h
5. `welcome-05-security` · security guide PDF · +3d
6. `welcome-06-first-week` · personally signed by Kerem · +7d
7. `welcome-07-two-weeks` · routine cadence explainer · +14d

**Billing · 5 emails:**
- `billing-invoice-paid` (attaches invoice PDF)
- `billing-card-expiring`
- `billing-payment-failed`
- `billing-plan-change`
- `billing-subscription-cancelled`

**Alerts · 4 emails:**
- `alert-threshold-critical` (fires alongside phone call + in-app overlay)
- `alert-threshold-amber`
- `alert-posture-change`
- `briefing-weekly` (attaches briefing PDF)

**Transactional · 2 emails:**
- `verify-otp`
- `security-login-new-device`

**Analyst / meta · 4 emails:**
- `analyst-reply`
- `quarterly-review-invitation`
- `canary-renewed`

All templates have HTML + plain-text variants. Each opens with eyebrow label, large display title, structured body, and ends with mono-tracked metadata row. Shared `_base.html` wrapper handles the logo, footer, unsubscribe link.

### 5 PDF generators

- `welcome-pack.php` · 6 pages · personalised, branded, signed by Kerem
- `methodology.php` · 8 pages · full methodology reference
- `security-guide.php` · 4 pages · Signal + 2FA + emergency-code setup
- `briefing-template.php` · 6 pages · weekly briefing layout (cover + 5 sections)
- `invoice.php` · 1 page · branded invoice with PAID stamp

All use MinPDF. All return `['filename' => str, 'content' => bytes]`.

### HD logo assets

- `logo-hd.png` (600×150, 5.9 KB) — CID-attached in every email
- `logo-hd@2x.png` (1200×300, 12.1 KB) — retina
- `logo-footer.png` (400×70, 2.6 KB) — compact footer version

Rendered from DejaVuSans-ExtraLight with baked-in tracking to match the web `Josefin Sans .38em` aesthetic. Cream `#e8e2d4` on deep-black `#070707`.

### Lifecycle scheduler · `emails/queue.php`

Cron-driven JSON-file queue:
- `scheduleWelcome($recipient)` fires welcome-01 inline and enqueues 02–07
- `processDue()` runs every 5 minutes via cron
- Retry backoff: 5min → 15min → 1hr → 4hr → dead-letter
- JSON files in `cache/email_queue/<ts>-<uuid>.json`
- Sent jobs archived to `cache/email_sent/`
- Failed jobs archived with `FAILED-` prefix

Configurable via `MEBUSAN_QUEUE_MAX_PER_RUN` and `MEBUSAN_QUEUE_RETRY_BACKOFF` env vars.

### Send endpoint · `emails/send.php`

HTTP API with internal-key auth (`MEBUSAN_INTERNAL_KEY`).
- `action: schedule_welcome` · fires full 7-email sequence for new subscriber
- `action: send_now` · sends a single email immediately

### Unsubscribe · `emails/unsubscribe.php`

- Hash-verified tokens (HMAC-SHA256 truncated to 24 chars)
- Per-category preferences: marketing / lifecycle / briefings / alerts / billing
- Billing and critical-alerts hardcoded as never-opt-out-able
- RFC 8058 one-click POST support (Gmail / Outlook compatible)
- GET UI with inline on/off toggles
- Minimal Mebusan-styled preferences page

---

## Critical alert phone-call system

Three simultaneous channels fire when a critical threshold crosses:

### 1. Email · `alert-threshold-critical`
Full-context email with observation / implication / confidence / falsification.

### 2. Phone call · `api/alert-call.php` + `alert-twiml.php` + `alert-call-status.php`
- Triggers Twilio Programmable Voice call to client's E.164 phone
- TwiML response plays British English Polly voice (Amy-Neural):
  > "[Name], this is Mebusan. A critical alert has been issued on your [jurisdiction] coverage. [Headline]. To acknowledge, press 1. To request an analyst callback within fifteen minutes, press 2."
- DTMF 1 = acknowledge · hangup with confirmation
- DTMF 2 = dial analyst conference bridge
- No response = automatic escalation to on-call analyst
- Status callback updates alert record as call progresses
- Answering-machine detection via `MachineDetection=DetectMessageEnd`

### 3. In-app overlay · injected into `app/mebusan_app.html`
- Full-screen non-dismissible alert
- Amber warm accent border + animated entry
- Haptic vibration pattern on supported devices
- Single soft-tone audio cue (440Hz, 0.95s, gentle exponential ramp)
- Shows: jurisdiction, headline, observation, implication, confidence, falsification, analyst, alert ID, timestamp
- Three actions gate dismissal:
  - **Open full briefing** (navigates to briefing view with ack)
  - **Request analyst callback** (fires SMS to on-call analyst, 15-min SLA)
  - **Acknowledge only** (records ack, dismisses)
- `POST /api/alert-acknowledge.php` · records in-app ack
- `POST /api/alert-callback-request.php` · records callback request + SMS-pings analyst via Twilio

No customer support phone number exposed. Analyst callback is the single voice channel, and it's analyst-initiated within a 15-minute SLA.

---

## Documentation

### `emails/README-EMAIL.md`
Operator setup guide with:
- DNS record specifics (SPF / DKIM / DMARC / optional BIMI)
- Provider comparison and recommendation
- Complete env-var reference
- Writable directory requirements
- Cron setup
- Signup-flow wiring examples
- Billing webhook integration examples
- Critical alert pipeline wiring
- Testing procedure (dry-run + mail-tester.com)
- Inbox-landing checklist
- Template inventory
- What the system deliberately does NOT do

---

## File tree additions · v3 → v4

```
website/
├── api/
│   ├── alert-call.php                        [NEW · Twilio voice trigger]
│   ├── alert-twiml.php                       [NEW · voice script TwiML]
│   ├── alert-call-status.php                 [NEW · Twilio status webhook]
│   ├── alert-acknowledge.php                 [NEW · in-app ack endpoint]
│   └── alert-callback-request.php            [NEW · callback intent + analyst SMS]
├── emails/                                   [NEW · entire subdirectory]
│   ├── lib/mailer.php                        [NEW]
│   ├── lib/pdf.php                           [NEW]
│   ├── templates/ (44 files)                 [NEW]
│   ├── pdf/ (5 generators)                   [NEW]
│   ├── assets/ (3 HD logos)                  [NEW]
│   ├── queue.php                             [NEW]
│   ├── send.php                              [NEW]
│   ├── unsubscribe.php                       [NEW]
│   └── README-EMAIL.md                       [NEW]
├── cache/
│   ├── email_queue/                          [NEW · dir]
│   ├── email_sent/                           [NEW · dir]
│   ├── email_log/                            [NEW · dir]
│   ├── pdf_cache/                            [NEW · dir]
│   └── critical_alerts/                      [NEW · dir]
└── app/mebusan_app.html                      [MODIFIED · +206 lines critical alert overlay]
```

---

## Operator to-do delta from v3

New items added to v3's action list:

- Rotate compromised Twilio token
- Set up SPF / DKIM / DMARC on `mebusan.com`
- Verify domain at chosen mail provider (Resend recommended)
- Generate `UNSUB_SECRET` (32-byte hex)
- Generate `MEBUSAN_INTERNAL_KEY` (32-byte hex)
- Add cron: `*/5 * * * * php website/emails/queue.php`
- Create cache subdirs: `email_queue`, `email_log`, `email_sent`, `pdf_cache`, `critical_alerts`

---

## Paste-prompt deliverable

Shipped alongside v4: `MEBUSAN_PASTE_PROMPT.md` — a single comprehensive document to paste into Claude Code (Mac) for all future work. Captures brand rules, file tree, voice calibration, pitfalls, and extension ideas. ~550 lines, self-contained.

---

*Mebusan AI PTE LTD · Singapore · April 2026*
