# CHANGES_ELITE_V3.md

**Session 4 addendum · 22 April 2026**  
Layered on top of `mebusan_v3_elite_v2.zip` to produce `mebusan_v3_elite_v3.zip`.

---

## Headline — "Perfection" pass

This release focuses on polish, speed, indexability, and closing the loop on the full client journey. Nothing unnecessary was added; broken or cheap surfaces were fixed.

---

## 01 · Killed every cheap popup

Every `alert()`, `confirm()`, and `prompt()` call in the app and website has been replaced with elite inline UI:

- `admin/moderate.html`: inline toast + modal confirm (matches elite design language). No more browser-native dialogs.
- `app/mebusan_app.html`: bottom-sheet confirmation for sign-out and subscription cancellation. Animated with cubic-bezier, respects safe-area-inset, backdrop blur. Zero native popups remaining anywhere.

---

## 02 · Comprehensive JSON-LD across 66/66 non-admin pages

Every single public page now emits structured data Google can see without ambiguity:

- **Every page** carries: `Organization` (Mebusan AI PTE LTD, legal name, Singapore address, knowsAbout, areaServed covering all 14 jurisdictions), `Person` (Kerem Albayrak, givenName/familyName, jobTitle, worksFor, email, sameAs), `WebSite`, and `BreadcrumbList`.
- **Every journal post** adds `Article` with `author: { @id: kerem }` and `publisher: { @id: mebusan }`.
- **Every country deep-dive** adds `Article + AnalysisNewsArticle` about the specific country.
- **`keremalbayrak.html`** is now explicit `ProfilePage` with Kerem as `mainEntity`.
- **`jurisdictions.html`** is `CollectionPage`. Journal index is `Blog`. FAQ is `FAQPage`. Contact is `ContactPage`.

Google will index every Kerem Albayrak mention and every Mebusan mention as clearly linked, co-occurring entities. The schema-injection script (`inject_schema.py`) lives at the project root and can be re-run over the tree at any time.

---

## 03 · Instant navigation

Rewrote `js/sw-register.js` to include:

- **Speculation Rules API** — Chrome/Edge prerender on moderate-eagerness hover, excluding `/admin`, `/api`, and `/portal`.
- **Hover/touch/focus prefetch fallback** — Safari/Firefox see `<link rel="prefetch">` appended the moment a user intends to navigate.
- **Cross-fade on click** — 160ms opacity ramp on internal link clicks, respects `prefers-reduced-motion`, restores opacity on `pageshow`.

The site now feels measurably instant on supported browsers.

---

## 04 · robots.txt upgraded

Explicit allow blocks for Googlebot, Googlebot-Image, Googlebot-News, Bingbot, Applebot, Applebot-Extended, DuckDuckBot, YandexBot, plus all AI crawlers. Crawl-delay removed for major search engines. Journal RSS feed exposed as a sitemap.

---

## 05 · Service worker v8

`sw.js` shell cache expanded from 16 URLs to 30, now including: journal index, jurisdictions index, methodology, glossary, trust, governance, letter, careers, editorial-standards, case-studies, warrant-canary, plus all 4 shared stylesheets. Cache version bumped to `v8-2026-04-22` so stale v7 caches clear on next visit.

---

## 06 · End-to-end in-app flow

The Mebusan mobile app (`app/mebusan_app.html`, renamed from `_v7`) now carries a full in-app signup → tier → pay → activate → dashboard journey. No redirects to the web.

**State-aware Account page** — renders differently for logged-out vs subscribed users:

- Logged-out: clean CTA rows, preview-access badge, notification toggles.
- Subscribed: tier badge (amber pulse dot), 3-stat hero strip (coverage, response commitment, next briefing countdown), quick-action row (Analyst / Alerts / Plan), jurisdiction chips, billing row with real card hint, sign-out via bottom sheet.

**Access overlay** — 5-step flow with:
- Step 1: Name / email / phone capture with dial prefix
- Step 2: 6-digit verification with auto-advance, paste support, dev-mode code surfacing, offline fallback
- Step 3: Tier selection with monthly/annual toggle (live price reflow)
- Step 4: Payment summary + Apple Pay button (with real Apple logo path) OR card fields (live-formatted: number grouping, MM/YY expiry, numeric CVC)
- Step 5: Elite success screen with confirmation ID, next briefing date, assigned analyst status

**Analyst message sheet** — conversation with bubble UI (theirs + yours), auto-growing textarea compose, simulated reply after 1.6s, "online" status pulse, named analyst for Private tier, auto-scroll to bottom.

**Plan management sheet** — Change plan (re-opens access overlay at step 3 with prefill), Update payment method, View invoices, Pause subscription, Cancel subscription (opens a second confirmation sheet with copy about period-end coverage).

All state persists to `localStorage.mb_account`. The cancel and sign-out confirmations are custom bottom sheets, not native popups.

**API base autodetect** — when running in a Capacitor native shell (`file://` protocol), the app automatically targets `https://mebusan.com/api/*`, falling back to relative URLs on web. Offline-graceful throughout.

---

## 07 · Web portal polished

- Removed the `"For demonstration purposes, enter any credentials below"` copy and `"demo / demo2025"` hint — these would have looked cheap to any real client.
- Rewrote the offline-fallback wording from `"Demo mode"` to `"Reconnecting"`.
- **Fixed broken mobile nav** — the portal sidebar hides completely under 900px width. Previously this left mobile clients with no way to switch between sections. Added a horizontal-scrolling section switcher below the topbar, synced bidirectionally with the desktop sidebar.
- **Created proper `section-billing`** — plan summary with tier/cycle/renewal grid, payment method row, invoice list with PDF buttons, pause/cancel subscription controls.
- **Created proper `section-security`** — session status, password change request, 2FA enablement, recovery key, emergency support code, urgent contact with Signal analyst + encrypted email buttons, recent access log (portal / mobile / analyst message).

The portal now has a complete 8-section navigation: Dashboard / Alerts / Briefings / Feed / Watchlist / Billing / Security / Settings. All work on mobile and desktop.

---

## 08 · Web standards

- `/.well-known/security.txt` (RFC 9116 responsible disclosure)
- `humans.txt`
- RSS feed auto-discovery via `<link rel="alternate">` in the homepage head
- Sitemap link via `<link rel="sitemap">` in the homepage head
- Sitemap rebuilt comprehensively (50+ URLs)

---

## 09 · What was NOT added

Respecting the instruction "don't keep adding pages" — nothing new this pass. Focus was on polish, perfection, and closing loops:

- No new routes
- No new copy
- No new journal entries
- No new country files
- No new legal pages

All gains came from fixing, not expanding.

---

## 10 · Operator action items

Unchanged from v2 except for one:

- **NEW:** The app inside `/app/mebusan_app.html` (renamed from `mebusan_app_v7.html`) is the shipping single-file PWA. Update your Capacitor `npx cap sync` to pick up the new filename if you reference it explicitly (most setups point at the `/app/` directory and won't need changes).

---

**End of CHANGES_ELITE_V3.md**
