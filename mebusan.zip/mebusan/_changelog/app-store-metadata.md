# MEBUSAN · App Store submission package

Everything needed to submit to App Store Connect. Copy-paste where indicated.

---

## App Name
```
Mebusan
```

## Subtitle (30 char max)
```
Private Intelligence
```

## Promotional Text (170 char max — can change without submit)
```
Private monitoring for wealth held across borders. Signals, scanner, and AI briefing on banking, capital controls, regulation, and political risk in 42+ jurisdictions.
```

## Description (4000 char max)
```
Mebusan is private intelligence for individuals with wealth held across borders.

Banking pipelines. Capital controls. Regulatory deadlines. Political movement. Property market shifts. Payment-rail health. We watch what affects your position before the news cycle does, across 42+ jurisdictions.

The app gives you:

SIGNAL FEED
A live excerpt of the feed we distribute to clients. Banking, regulatory, capital-controls, political, and property signals across the jurisdictions that affect private wealth. Tap any signal to see the reasoning, source posture, and implication.

RISK SCANNER
Five questions, two minutes. A private read on your exposure across the jurisdictions you care about. Nothing is stored off-device. The result is a structured profile across Banking, Capital Controls, Regulatory, Political, and Exit-Liquidity dimensions.

ASK MEBUSAN
An AI analyst trained on our intelligence framework. Ask about any jurisdiction, any pipeline, any signal. Capital-control mechanics, beneficial-ownership deadlines, correspondent-bank shifts, the state of a specific country's banking pipeline.

ALERTS
Threshold alerts for movement in jurisdictions and categories you care about. Amber-only filtering. Daily summary if you want one, real-time if the signal breaches severity.

ACCOUNT
Preference tuning, notification controls, onboarding replay, privacy settings. You can change your jurisdictions and categories any time.

WHO THIS IS FOR
Private wealth owners. Family offices. High-net-worth individuals with exposure across multiple countries. Anyone who needs structured visibility on what is moving in the jurisdictions their capital sits in.

WHAT THIS IS NOT
Not legal advice. Not tax advice. Not investment advice. Mebusan is intelligence. It describes the state of rules, signals, and pipelines. It does not recommend specific filings, trades, or structures.

HOW IT WORKS
The app is free to explore. Full access, named-analyst coverage, and real-time alerts are available by application to Mebusan's paid tiers. Not every applicant is accepted; the service is intentionally small.

PRIVACY
Everything in the app works without an account. Preferences are stored on device. Signal feed requests are rate-limited and carry no identifying headers beyond your IP. Full privacy policy at mebusan.com/legal/privacy.

Mebusan is registered in Singapore as MEBUSAN AI PTE LTD.
```

## Keywords (100 char max, comma-separated)
```
intelligence,wealth,banking,finance,private,offshore,family office,regulatory,capital,briefing,signal
```

## Category
```
Primary: Finance
Secondary: Business
```

## Age Rating
```
4+ (no restricted content)
```

## Support URL
```
https://mebusan.com/contact.html
```

## Marketing URL
```
https://mebusan.com
```

## Privacy Policy URL
```
https://mebusan.com/legal/privacy.html
```

## Copyright
```
2026 MEBUSAN AI PTE LTD
```

---

## Version Info

**Version:** 7.0.0
**Build:** 1

**What's New in This Version:**
```
Initial App Store release. Private intelligence on 42+ jurisdictions. Signal feed, risk scanner, AI briefing, and threshold alerts.
```

---

## App Review Information

**Contact:**
- First name: Kerem
- Last name: Albayrak
- Phone: [from your Stripe/ACRA records]
- Email: k.a@mebusan.com

**Demo Account:**
Not required. All public-tier features work without login. For reviewer testing of authenticated flows:
- Demo URL: https://mebusan.com/portal-login.php
- Username: reviewer@apple-test.mebusan.com
- Password: [generate a one-time reviewer account before submission]

**Notes to Reviewer:**
```
Mebusan is a private-intelligence service. The app is a client of our service at mebusan.com.

All public-tier features (signal feed, risk scanner, AI briefing, alerts) work without login. No account is required to experience the full feature set shown in screenshots.

The "Apply for access" flow opens the web application at mebusan.com/apply.html. Paid subscriptions are handled server-side via Stripe on the web; the app does not use in-app purchase. This is a B2C intelligence service, not digital-content subscription sold via IAP — the paid offering is an ongoing intelligence relationship with human-analyst involvement, which falls outside IAP requirements per App Review Guidelines 3.1.3(f) (Goods and Services Outside of the App).

The AI Briefing feature uses Anthropic's Claude API server-side. User input is sent to our own server (api/ask.php) which relays to the API. No personal data is logged beyond standard access logs.

We publish a quarterly warrant canary at mebusan.com/warrant-canary.html.
```

---

## App Privacy (required in App Store Connect)

**Data Types Collected:**

| Type | Collected | Linked to user? | Used for tracking? | Purpose |
|---|---|---|---|---|
| IP Address | Yes | No | No | Rate limiting, abuse prevention |
| Device ID | No | — | — | — |
| Usage Data | No | — | — | — |
| Contact Info | No (unless they submit application) | — | — | — |
| User Content | Yes (chat messages) | No | No | Service functionality only |
| Diagnostics | No | — | — | — |
| Location | No | — | — | — |

**Data Not Collected:**
- Name (unless submitted via apply.html)
- Email (unless submitted via apply.html)
- Phone (unless opted in for verification)
- Device identifiers
- Advertising identifiers
- Purchase history (handled by Stripe on web)
- Location data

**Privacy Practices:**
- [x] Data is not used for tracking
- [x] Data is not linked to identity (anonymous usage)
- [x] Data collection is optional for most features

---

## Localization
Start with **English (U.S.)** only for the first release. Roll out translations after launch.

---

## In-App Purchase Declaration
**None.** Paid subscriptions are sold through mebusan.com directly; they are not digital content purchasable within the app. This falls under App Review Guideline 3.1.3(f).

---

## Sign-In Required Declaration
**Not for core features.** Sign-in is only required for the paid client portal, which is accessible via web browser. The app does not require a login to use any of its primary features.

---

## Screenshots Plan

You need screenshots at these sizes. Use the mockups in /screenshots/mockups/ as templates, then screenshot from the app running in Simulator.

**Required:**
- 6.9" iPhone (1320 × 2868 or 1290 × 2796) — iPhone 15 Pro Max
- 6.5" iPhone (1242 × 2688 or 1284 × 2778) — iPhone 14 Plus
- 6.1" iPhone (1179 × 2556) — iPhone 15
- 5.5" iPhone (1242 × 2208) — optional, older device
- iPad 12.9" (2048 × 2732) — if submitting iPad app
- iPad 11" (1668 × 2388) — if submitting iPad app

**Suggested shots (6 total):**
1. **Feed** — with amber Turkey signal at top, "Monitoring active" in status bar
2. **Signal detail sheet** — opened on a signal showing context/implication/why
3. **Scanner in progress** — step 3 of 5, with question and selected option
4. **Scanner results** — radar chart, score, recommended tier
5. **Ask Mebusan** — with example conversation visible
6. **Alerts / Account** — showing threshold alerts list

Each screenshot should have:
- Status bar at top showing brand
- Content that tells a story, not empty states
- Consistent dark theme
- No system-generated spam (no iOS dialogs, no debug overlays)

---

## Submission Checklist

- [ ] Bundle ID registered (com.mebusan.app)
- [ ] App record created in App Store Connect
- [ ] Metadata pasted (above)
- [ ] Screenshots uploaded at all required sizes
- [ ] App Privacy questionnaire completed
- [ ] Age rating set (4+)
- [ ] Category set (Finance primary)
- [ ] Pricing & Availability set (Free, all territories except those subject to sanctions)
- [ ] Build uploaded via Xcode (Archive → Distribute)
- [ ] Build selected in "Prepare for Submission"
- [ ] App Review Information filled in
- [ ] Export Compliance: No encryption (or standard HTTPS encryption, which is exempt)
- [ ] Submit for Review
- [ ] Respond to any reviewer questions within 24 hours

Expected review time: 24-48 hours for a clean first submission.
