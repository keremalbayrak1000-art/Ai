# Security

Mebusan handles the correspondence of principals whose information environment matters. This document explains what we protect against, how, and what you as an operator need to do.

## Threat model

| Threat | What it looks like | Our defence |
|---|---|---|
| **Scraping / reconnaissance** | Bots crawling for endpoints, file leaks, config | `.htaccess` blocks common probes; server fingerprinting removed; strict CSP |
| **Credential stuffing** | Automated login attempts on `/admin` | Rate limiting per-IP + per-endpoint; bcrypt password hashes; optional IP allowlist |
| **Session hijacking** | Stolen session cookies | `SameSite=Strict` + `HttpOnly` + `Secure` cookies; periodic regeneration |
| **CSRF** | State change triggered by another site | Double-submit CSRF tokens required on all POST/PUT/DELETE |
| **Clickjacking** | Site embedded in attacker iframe | `X-Frame-Options: SAMEORIGIN`, `frame-ancestors` CSP directive, client-side frame-busting |
| **XSS** | Injected scripts running in client context | Strict CSP; input sanitisers in `_security.php`; no `innerHTML` with user input |
| **MITM / downgrade** | Forced HTTP | HSTS 2 years + `upgrade-insecure-requests` CSP directive |
| **Enumeration** | Probing for valid accounts via response-time differences | Constant-time comparisons (`hash_equals`); uniform error responses |
| **E-sign forgery** | Replayed or tampered signatures | HMAC-bound tokens; document hash anchoring; audit log |
| **Bot signup** | Automated account creation / form-spam | Honeypot field + load-time check + interaction-count check + rate limit |
| **Data exfiltration** | Compromised server leaking briefings | Per-purpose derived keys; cache dirs `.htaccess`-denied; no PHP execution in cache |
| **Compelled disclosure** | Legal pressure on operators | Warrant canary (quarterly, signed); if it fails to renew, compromise should be assumed |

## Security layers

Defence is in depth. The stack has six layers, and an attacker must bypass all of them.

### 1. Network (Hostinger + optional Cloudflare)

Choose one:
- **Direct to Hostinger** (simpler): TLS handled by Hostinger's included cert. HSTS header via `.htaccess`.
- **Cloudflare in front** (stronger): Adds DDoS protection + bot management. Set `MEBUSAN_TRUST_PROXY=1` and `CF-Connecting-IP` will be used for rate limiting.

### 2. Apache (`.htaccess` stack)

- **`website/.htaccess`** — root hardening. Force HTTPS, strip server headers, strict CSP, HSTS, X-Frame-Options, Permissions-Policy, block common scanner probes, deny dotfiles.
- **`website/api/.htaccess`** — API-specific: no caching, no framing, block shared includes.
- **`website/admin/.htaccess`** — no caching, DENY framing, max CSP isolation, optional IP allowlist.
- **`website/cache/.htaccess`** — deny all direct access, block any PHP execution.
- **`website/emails/.htaccess`** — deny everything except the three public entrypoints.

### 3. PHP application (`_security.php`)

Every API endpoint includes it:

```php
require_once __DIR__ . '/_security.php';
MebusanSecurity::applyApiHeaders();
MebusanSecurity::rateLimit('bucket-name', 30, 600);
```

Features:

- **Derived keys**: `MebusanSecurity::secret('signing')`, `secret('session')`, etc. — each purpose gets its own HMAC-derived key from the master.
- **Rate limiting**: per-IP + per-bucket file-based counter. `429 Retry-After` response when exceeded.
- **CSRF**: `csrfToken()` / `requireCsrf()`.
- **HMAC signing tokens**: stateless, for e-sign / unsubscribe / password-reset flows. `issueSigningToken()` / `verifySigningToken()`.
- **Secure sessions**: `SameSite=Strict`, `HttpOnly`, `Secure`, regenerated every 30 min or on privilege change.
- **Audit log**: append-only at `cache/audit_log/YYYY-MM.log`. Every `auditLog()` call records: timestamp, event, masked IP, UA (first 200 chars), path, context.
- **IP / email masking**: never log raw PII to the audit file.
- **Admin IP allowlist**: optional, CIDR-aware.
- **Honeypot / timing**: `honeypotCheck()` / `timingCheck()` for signup-style forms.

### 4. Client-side (`js/security.js`)

Loaded on every page:

- Frame-busting (plus CSP `frame-ancestors` backs it up)
- Automatic honeypot injection into every form
- Fetch wrapper adds CSRF header + behavioural context (`X-Mebusan-Ctx`) to same-origin state-changing calls
- `.secure-content` class disables right-click/copy/print
- Sensitive clipboard auto-clear (30s) via `mebusanCopySensitive(text)`
- Soft devtools detection with warning banner (deterrence, not prevention)
- `window.opener` nulling from untrusted referrers

### 5. E-sign flow

The critical specifics:

- **Tokens** are HMAC-bound, 90-day expiry, derived from `MEBUSAN_SECRET`
- **Signature payload** is anchored to the unsigned-document SHA-256 hash — tampering the PDF invalidates the signature cryptographically
- **Audit log** records: session ID, document ID, email (masked), tier, method, session duration, interaction count, both document hashes, IP (masked), UA
- **Bot heuristics**: reject if session < 3s OR interactions < 3
- **Payload size capped** at 2 MB; stroke data sanitised (coordinate bounds + pressure clamping + count limits)
- **Signature storage**: `cache/signed_documents/<session_id>.pdf` (cache is `.htaccess`-denied; access is through `sign-doc.php` only with valid token)

### 6. Monitoring

- **Audit log** is the primary trail. Check `cache/audit_log/YYYY-MM.log` regularly.
- **Rate-limit triggers** are audit-logged under `rate-limited`.
- **Honeypot trips** are logged as `honeypot-tripped`.
- **CSRF failures** as `csrf-failed`.
- **Sign events** as `signed`, `sign-submit-rejected`, `sign-email-failed`.

If you see repeated rate-limits from the same masked IP, investigate. If audit log grows faster than a few MB/month, something's wrong.

## Operator checklist

Before production launch:

- [ ] Generated secrets via `./scripts/generate-secrets.sh`; added to Hostinger env
- [ ] `ADMIN_PASSWORD_HASH` set (bcrypt via `password_hash`)
- [ ] `MEBUSAN_ADMIN_IPS` set to your personal IP(s) — defence in depth for admin
- [ ] HTTPS cert provisioned by Hostinger
- [ ] Submitted to `hstspreload.org` after 30 days
- [ ] SPF / DKIM / DMARC records live on `mebusan.com`
- [ ] Mail provider domain verified
- [ ] Twilio old token (`d94b23dae265a0143f699e90eacee216`) rotated
- [ ] Cron jobs running (ingest-signals hourly, cron 5-min, queue 5-min)
- [ ] `cache/*` directories exist and are writable (via `post-deploy.sh`)
- [ ] `.htaccess` files all present (via `post-deploy.sh` verification)
- [ ] PGP key for warrant canary generated and fingerprint published
- [ ] Reviewed audit log format and set up offsite backup
- [ ] Disaster-recovery: noted how to re-provision cache dir structure

## Incident response

If you suspect compromise:

1. **Rotate `MEBUSAN_SECRET`** immediately. All HMAC tokens (signing, unsubscribe) become invalid; affected users will need to re-request.
2. **Rotate all API keys** — Stripe, Twilio, Resend, Anthropic.
3. **Review `cache/audit_log/`** for the 30 days preceding the incident.
4. **Let the warrant canary lapse** if the compromise involved legal compulsion — this is the signal to clients.
5. **Notify affected clients** via encrypted email (analyst-to-principal Signal if set up).
6. **Document** the incident in `_changelog/` — future you will thank you.

## Responsible disclosure

If you're a security researcher: email `security@mebusan.com`. We do not currently run a public bug bounty, but we will acknowledge and credit valid findings.

Please do not perform active exploitation against the production site. A coordinated report is always worth more than a live demo.
