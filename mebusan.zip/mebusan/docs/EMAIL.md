# Email system

Mebusan's email system is the backbone of client onboarding and ongoing communication. This doc covers the architecture, template inventory, provider setup, deliverability requirements, and operational concerns.

## Architecture

```
Signup flow (app/mebusan_app.html)
    │
    ├──► POST /emails/send.php?action=schedule_onboarding
    │         │
    │         ├──► POST /api/sign-request.php
    │         │        └──► Creates SGN-xxxx session in cache/signatures/
    │         │
    │         ├──► Sends engagement-sign-required email (unsigned PDF attached)
    │         │
    │         └──► Enqueues: welcome-01 (T+5min), welcome-02 (T+1h),
    │                         welcome-03 (T+4h), welcome-04 (T+24h),
    │                         welcome-05 (T+3d), welcome-06 (T+7d),
    │                         welcome-07 (T+14d)
    │
    └──► Cron every 5 min: php emails/queue.php → processDue()

Client signs → /sign.html → POST /api/sign-submit.php
    │
    ├──► Generates signed PDF
    ├──► Sends engagement-signed email (countersigned PDF attached)
    └──► Records audit entry
```

## Provider options

One of four mail providers, chosen by `MEBUSAN_MAIL_PROVIDER`:

| Provider | Pros | Cons | Monthly (10k sends) |
|---|---|---|---|
| **Resend** *(recommended)* | Modern API, clean dashboard, best inbox-landing in class | Newer player | $20 |
| Postmark | Transactional specialist, best reputation | Pricier for scale | $15 |
| SendGrid | Enterprise-grade | Heavier UI, slower deliverability | $20 |
| SMTP | Works anywhere | Most setup, weakest deliverability | Host-dependent |

Set `MEBUSAN_MAIL_PROVIDER=resend` and `RESEND_API_KEY=re_...` and you're done.

## DNS setup (required before first send)

Without these, every email goes to spam. No exceptions. Configure on `mebusan.com`:

### SPF

TXT record on `mebusan.com`:
- Resend: `v=spf1 include:_spf.resend.com ~all`
- Postmark: `v=spf1 a mx include:spf.mtasv.net ~all`
- SendGrid: `v=spf1 include:sendgrid.net ~all`

### DKIM

Provider-specific. Each gives you 1–3 CNAME records in their dashboard. Add them.

### DMARC

TXT on `_dmarc.mebusan.com`. Start permissive, tighten after two weeks of clean reports:

```
v=DMARC1; p=quarantine; rua=mailto:dmarc@mebusan.com; aspf=s; adkim=s; pct=100
```

Then move to `p=reject` after verified delivery.

### BIMI (optional but elite)

TXT on `default._bimi.mebusan.com` pointing to an SVG of the Mebusan mark. Gmail shows the logo next to the From line on mobile.

```
v=BIMI1; l=https://mebusan.com/brand/mebusan-bimi.svg;
```

## Template inventory

### Lifecycle (7)

Auto-scheduled by `scheduleOnboarding()` at these offsets after payment:

| Template | Offset | PDF attached | Signed by |
|---|---|---|---|
| engagement-sign-required | T+0 (immediate) | engagement-letter (unsigned) | desk |
| welcome-01-immediate | T+5min | welcome-pack (6 pages) | analyst |
| welcome-02-primer | T+1h | methodology (8 pages) | analyst |
| welcome-03-analyst | T+4h | — | assigned analyst |
| welcome-04-first-briefing | T+24h | — | analyst |
| welcome-05-security | T+3d | security-guide (4 pages) | desk |
| welcome-06-first-week | T+7d | — | **Kerem (founder, personally)** |
| welcome-07-two-weeks | T+14d | — | desk |

### Transactional (2)

Sent on-demand from application code:

| Template | Used by | Notes |
|---|---|---|
| verify-otp | `/api/verify.php` | Big 6-digit code display, 10-minute expiry |
| security-login-new-device | New-device login detection | Masked IP, device string, alert-analyst CTA |

### Billing (5)

Triggered by Stripe webhooks (see `api/stripe-webhook.php`):

| Template | Stripe event | PDF attached |
|---|---|---|
| billing-invoice-paid | `invoice.paid` | invoice (1 page) |
| billing-card-expiring | `customer.source.expiring` | — |
| billing-payment-failed | `invoice.payment_failed` | — |
| billing-plan-change | `subscription.updated` | — |
| billing-subscription-cancelled | `subscription.deleted` | — |

### Alerts (4)

Triggered by signal processing pipeline:

| Template | Trigger | Also fires |
|---|---|---|
| alert-threshold-critical | Critical threshold crossed | In-app overlay + Twilio voice call |
| alert-threshold-amber | Amber threshold crossed | — |
| alert-posture-change | Jurisdiction posture moves | — |
| briefing-weekly | Weekly scheduled send | briefing-template PDF (6 pages) |

### Analyst / meta (4)

| Template | When | Notes |
|---|---|---|
| analyst-reply | Analyst responds in portal | Preview only; full message in-app |
| quarterly-review-invitation | 14 days before quarter end | Private-tier only |
| canary-renewed | Quarterly canary resigning | Signed by Kerem |
| engagement-signed | After client signs | Countersigned PDF attached |

## PDF generators

All use pure-PHP `MinPDF` (no Composer, no external deps). Base-14 fonts only.

| Generator | Output | Used by |
|---|---|---|
| `welcome-pack.php` | 6 pages, personalised, signed by Kerem | welcome-01 |
| `methodology.php` | 8 pages | welcome-02 |
| `security-guide.php` | 4 pages | welcome-05 |
| `briefing-template.php` | 6 pages, five-section layout | briefing-weekly |
| `invoice.php` | 1 page with PAID stamp | billing-invoice-paid |
| `engagement-letter.php` | 5 pages + signature page (6 when signed) | engagement-sign-required |

Each generator is a closure that takes `$vars` and returns `['filename' => str, 'content' => bytes]`.

## Adding a new template

1. Create `emails/templates/<slug>.html` with `{{subject: ...}}` on line 1
2. Create `emails/templates/<slug>.txt` with plain-text equivalent
3. That's it — the mailer discovers it by filename

Variables use `{{var_name}}` syntax. Unused variables are stripped automatically.

## Sending an email

### From PHP

```php
require_once __DIR__ . '/website/emails/lib/mailer.php';
$mailer = new MebusanMailer();
$result = $mailer->send([
    'to'         => 'client@example.com',
    'to_name'    => 'M. Ahmadi',
    'template'   => 'welcome-01-immediate',
    'vars'       => [/* ... */],
    'attach_pdf' => 'welcome-pack',         // Optional — generator slug
    'category'   => 'lifecycle',
]);
```

### From HTTP (with internal key)

```bash
curl -X POST https://mebusan.com/emails/send.php \
  -H "X-Mebusan-Key: $MEBUSAN_INTERNAL_KEY" \
  -H "Content-Type: application/json" \
  -d '{"action":"send_now","email":{"to":"...","template":"...","vars":{}}}'
```

### Scheduling onboarding (from payment success)

```bash
curl -X POST https://mebusan.com/emails/send.php \
  -H "X-Mebusan-Key: $MEBUSAN_INTERNAL_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "action": "schedule_onboarding",
    "recipient": {
      "email": "client@example.com",
      "name": "M. Ahmadi",
      "name_slug": "ahmadi",
      "tier": "Advisory",
      "confirmation_id": "MBSN-7421",
      "first_briefing_date": "Monday, 28 April",
      "response_window": "24 hours",
      "coverage_summary": "Turkey, UAE, Switzerland",
      "analyst_name": "S. Aldemir",
      "analyst_first": "S.",
      "analyst_email": "desk@mebusan.com"
    }
  }'
```

This fires engagement-sign-required immediately, enqueues welcome-01 at T+5min, and welcomes 02-07 at T+1h / T+4h / T+24h / T+3d / T+7d / T+14d.

## Cron

Add to Hostinger cron panel:

```cron
*/5 * * * * cd /home/USER/public_html && php emails/queue.php >> cache/email_log/cron.log 2>&1
```

## Testing

Dry-run mode renders without sending:

```bash
php scripts/test-email.php you@test.com welcome-01-immediate
```

Check deliverability with [mail-tester.com](https://mail-tester.com). Target: **10/10**. Anything below 9 means a DNS record is wrong.

## Inbox-landing checklist

Before first production campaign:

- [ ] SPF published and resolves (`dig TXT mebusan.com`)
- [ ] DKIM CNAMEs published and resolve
- [ ] DMARC published with `rua` reporting
- [ ] Domain verified in provider dashboard
- [ ] Test send to Gmail → **Primary** tab (not Promotions)
- [ ] Test send to Outlook.com → Inbox (not Junk)
- [ ] Test send to Yahoo → Inbox (not Spam)
- [ ] mail-tester.com score ≥ 9/10
- [ ] HD logo renders inline in all three clients
- [ ] PDF attachment downloads and opens correctly
- [ ] Unsubscribe link works (both GET UI and one-click POST)
- [ ] Text-only version renders readably

## What the email system does NOT do (by design)

- **No tracking pixels.** Opens are not tracked.
- **No click tracking.** Clicks are not tracked.
- **No A/B testing.** Not our business.
- **No marketing automation.** The welcome sequence is the entire lifecycle.
- **No retention pressure.** Cancellation confirmations don't try to win anyone back.

These are deliberate. They reflect Mebusan's position on client relations. See `docs/BRAND.md` for the full rationale.
