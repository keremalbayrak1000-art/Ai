# Brand

The Mebusan brand is a narrow thing. Breaking any of these rules is worse than shipping nothing. This document is the expanded version of the brand section in `CLAUDE.md`.

## Positioning

Mebusan is private intelligence for wealth that crosses borders. It is not a compliance vendor, not a news service, not a fintech, not an investment advisor, not a bank, not a SaaS. When writing anything touching the brand, ask: *would a private banker of 20 years write this?* If no, rewrite.

## Voice

- **Clinical.** Specifics over generalities. Numbers when we have them.
- **Measured.** No hype, no superlatives, no promise-the-world.
- **Falsification-aware.** Every claim names the observation that would disprove it.
- **Signed.** Person-level accountability. "Your analyst". "Signed by Kerem".
- **Restrained.** Short sentences. Short paragraphs. No filler.
- **Quietly confident.** We don't sell. We explain.

## Colour

```
Background deep       #060504      body
Background card       #0a0806      panels
Cream primary         #e8e2d4      text, logo
Cream muted           rgba(232,226,212,0.72)   secondary text
Cream faint           rgba(232,226,212,0.55)   labels
Cream ghost           rgba(232,226,212,0.08 → 0.18)   borders
Amber accent          #c8a03a      attachment tags, highlights, Private-tier badge
Amber warm            #c87a4a      CRITICAL ALERTS ONLY
Green success         #3a7a58      signed / confirmed only (never promotional)
```

### Red is forbidden

Nowhere. Not errors, not warnings, not critical alerts. Warm amber (`#c87a4a`) takes red's role.

## Typography

| Use | Face | Weight | Tracking |
|---|---|---|---|
| Logo / wordmark | Josefin Sans | 300 | .38em |
| Body text | Inter (system fallback: `-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial`) | 400–500 | normal |
| Headings / display | Inter | 200 | -0.02em to -0.025em |
| Labels / meta | Menlo, Monaco, 'SF Mono', Courier | 400 | .1em to .2em + uppercase |

Display text reduces **weight**, not size. A 48px / 200-weight heading at -0.025em is the Mebusan signature.

## Shape

- **0.5px borders.** Everywhere. Never 1px.
- **Square corners.** Border-radius is effectively banned (inputs get 2px max, nothing else).
- **Hairline dividers**: 0.5px with `rgba(232,226,212,0.08)` fill.
- **Generous whitespace.** If it feels sparse, it's probably right.

## Forbidden words and phrases

Zero exceptions. These break the brand immediately.

**Tone violations:**
- "AI-powered" / "AI-driven" / "powered by AI" (Mebusan has AI; we don't market it)
- "club" (even when clients feel like members)
- "elite" / "exclusive" / "premium" / "boutique" (applied to us)
- "revolutionary" / "game-changing" / "disruptive" / "cutting-edge"
- "empower" / "unlock" / "seamless" / "innovative"
- "We're on a mission to…"
- "Meet your new…"
- "Get started with a free trial"
- "Book a demo"
- "Contact us for pricing"
- "Join thousands of…"

**Typography violations:**
- Em-dashes (`—`) in body copy — use en-dashes (`–`) or periods
- Emoji (rare exception: informal dev notes)

**UX violations:**
- Native `alert()` / `confirm()` / `prompt()` popups
- Stock photography
- Countdown timers on pricing
- Fake testimonials / fake press logos
- Auto-playing media
- Chat-bubble "virtual assistants"

**Content violations:**
- Dubai in Kerem's bio content
- Lebanon referenced more than once per document

## Tone examples

### Wrong → Right

| Wrong | Right |
|---|---|
| Welcome to Mebusan! We're so excited to have you. | Your file is open. |
| Our AI-powered platform delivers actionable insights. | We track postures and pipelines, with named falsification paths. |
| Get started with a free trial! | Apply for coverage. |
| Contact our amazing support team 24/7! | Reply to any email we send. It reaches your analyst. |
| Check out our premium tier! | Private tier is unlimited jurisdictions, 4-hour response. |
| We're on a mission to democratise intelligence. | We exist because the information that matters does not travel through normal channels. |
| Upgrade now to unlock advanced features! | Advisory adds Signal pairing, quarterly reviews, and event-triggered inserts. |

### Hero lines (use these as calibration)

> Private intelligence for wealth that crosses borders.

> Your file is open at Mebusan.

> We do not make predictions. We track postures.

> Every claim carries a confidence score and a named falsification path.

> Nothing else goes out routinely. If we break this rhythm, it is because something real happened.

## Logo

The Mebusan wordmark is Josefin Sans 300 with `.38em` letter-spacing, always in cream (`#e8e2d4`) on a deep-black background.

- **Web:** rendered as text (Google Fonts), never as an image
- **Email:** rendered as a CID-attached PNG (`logo-hd.png` at 600×150, or `@2x` for retina)
- **PDF:** rendered as Helvetica-Light tracked text (no custom font embedding needed)
- **App icon / favicon:** the letter `M` in the same weight/tracking, cream on deep-black square

Never stretch, recolour, place on light backgrounds, or animate the logo.

## Imagery

The Mebusan site uses almost no imagery. When it must:

- **Illustration only.** Simple line work in cream on deep-black.
- **No stock photography.** Ever.
- **No AI-generated imagery.** Given our position on AI marketing, using AI imagery would be inconsistent.
- **No portraits** (of Kerem, analysts, or anyone).

## Writing checklist

Before shipping copy, verify:

- [ ] No forbidden words
- [ ] No em-dashes in body copy
- [ ] No emoji
- [ ] Short sentences (most under 20 words)
- [ ] Specific numbers where we have them
- [ ] Named falsification (where applicable to a claim)
- [ ] Signed (for lifecycle content, by Kerem or the analyst)
- [ ] Reads like a private banker, not like SaaS marketing

If any check fails, rewrite.
