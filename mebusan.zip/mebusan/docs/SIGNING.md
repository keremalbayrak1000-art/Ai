# E-sign flow

Mebusan's engagement letter is signed inside the Mebusan brand environment. No DocuSign, no HelloSign, no third-party redirect. The whole flow is self-hosted, cryptographically anchored, and legally defensible.

## Why self-hosted

Every third party is a branding compromise and a data-leakage risk. DocuSign's flow would land clients on a DocuSign page, break our visual voice, and expose document metadata to a vendor with its own breach history.

The self-hosted flow:

- Keeps clients inside `mebusan.com` throughout
- Stores no document metadata with a third party
- Anchors signatures cryptographically to the unsigned document via SHA-256
- Ships with an audit log that we control
- Meets the same legal standards as commercial e-sign services (timestamp, intent, consent, audit trail)

## Flow diagram

```
1. Payment succeeds in mebusan_app.html
     │
     ▼
2. POST /emails/send.php  (action: schedule_onboarding)
     │
     ├──► Creates signing session at cache/signatures/SGN-xxxx.json
     ├──► Issues HMAC-bound token: <session_id>.<hmac>
     └──► Sends engagement-sign-required email
               └──► Email contains:
                     · Unsigned 5-page PDF as attachment
                     · "Review and sign" button → /sign.html?t=<token>

3. Client opens /sign.html
     │
     ├──► Fetches session metadata via /api/sign-session.php
     ├──► Streams PDF via /api/sign-doc.php (rendered inline in iframe)
     └──► Captures signature:
           · Drawn (canvas, pointer events, pressure-sensitive)
           · Typed (styled italic serif rendering)

4. Client submits via /api/sign-submit.php
     │
     ├──► Validates HMAC token
     ├──► Checks bot heuristics (session ≥3s, interactions ≥3)
     ├──► Sanitises signature payload (bounds, counts, sizes)
     ├──► Generates signed PDF with signature as native vector paths
     ├──► Computes SHA-256 of signed bytes
     ├──► Persists to cache/signed_documents/<session_id>.pdf
     ├──► Updates session: signed=true, adds attestation
     ├──► Writes audit entry
     └──► Sends engagement-signed email (countersigned PDF attached)

5. Client redirected to /sign-complete.html
     └──► Displays attestation: document ID, signed-at, method, hash
```

## Security properties

### Tokens are HMAC-bound

```
token = <session_id>.<hmac>
hmac  = substr(HMAC-SHA256(session_id, derive_key("signing")), 0, 32)
```

Cannot be forged without `MEBUSAN_SECRET`. Cannot be reused after signing (server checks `signed=true` flag).

### Document is cryptographically anchored

When a client signs, we compute the SHA-256 of the *unsigned* document and record it in the signature payload. If anyone later produces a "signed" version with different content, the hash mismatch proves tampering.

### Audit log is append-only

Every sign event lands in `cache/audit_log/YYYY-MM.log` with:

- Session ID
- Document ID
- Email (masked)
- Tier
- Method (drawn / typed)
- Both document hashes (unsigned base + signed)
- IP (masked)
- User agent (first 200 chars)
- Session duration (ms)
- Interaction count

This log is the legal evidence trail. Back it up offsite regularly.

### Bot heuristics

Signatures are rejected client-side AND server-side if:

- Session duration < 3 seconds (bot rushes)
- Interaction count < 3 (no pointerdown / keydown events)
- Payload > 2 MB (absurd stroke count)

Legitimate humans easily pass these — a user typing their name generates dozens of keydown events in several seconds.

### Signature storage

Signed PDFs live in `cache/signed_documents/` which is `.htaccess`-denied. Access is only through `/api/sign-doc.php` with a valid HMAC token.

## Legal standing

The flow meets the requirements of most electronic-signature laws:

| Jurisdiction | Law | Requirements | Our compliance |
|---|---|---|---|
| Singapore | Electronic Transactions Act 2010 | Intent, consent, attribution, integrity | ✓ all four |
| EU | eIDAS (simple/advanced electronic signature) | Intent, identity link, tamper-evidence | ✓ for simple; advanced requires PKI cert |
| US | ESIGN Act / UETA | Intent, consent, attribution, record retention | ✓ all four |
| UK | Electronic Communications Act 2000 | Comparable to eIDAS | ✓ for simple |

**Not covered:** qualified electronic signatures (QES) under eIDAS require a trust service provider-issued certificate. For contracts that specifically require QES, clients would need to sign via a separate flow (we'd add a DocuSign/Adobe Sign integration as a fallback only for those cases).

For Mebusan engagement letters, a simple electronic signature is sufficient and matches the standard used by law firms, asset managers, and most financial services.

## Anatomy of the signing page

`/sign.html` is a single self-contained HTML file. Zero dependencies, zero tracking. It matches the Mebusan aesthetic exactly:

- Josefin Sans wordmark header (rendered via system font fallback — no external font load)
- Embedded PDF viewer (browser native, no PDF.js dependency)
- Canvas signature panel with pressure-sensitive strokes
- Typed-signature fallback for devices without precise pointer input
- Consent checkbox (required before enable)
- Submit button (disabled until signature + consent present)

Frame-busting protects against attacker-embedding. CSP prevents any third-party resource loading.

## Configuration

No configuration is needed beyond the env vars:

- `MEBUSAN_SECRET` — derives the signing-key HMAC
- `MEBUSAN_INTERNAL_KEY` — used by scheduleOnboarding to mint sessions

Session lifetime defaults to 90 days. Change in `api/sign-request.php` if needed.

## Operational concerns

### Expired sessions

Sessions expire after 90 days. Expired tokens return `410 Gone`. Client should message desk to reissue.

### Lost signing link

Client can request a new link by emailing `desk@mebusan.com`. Operator runs:

```bash
php -r "
require 'website/api/_security.php';
\$s = MebusanSecurity::verifySigningToken('<old token or session_id.*>');
if (\$s) {
    \$token = MebusanSecurity::issueSigningToken(\$s['session_id']);
    echo 'https://mebusan.com/sign.html?t=' . \$token;
}
"
```

Then email the new link manually (or reuse `engagement-sign-required` template).

### Signed document retrieval

Client can download their signed copy anytime from the portal. Server-side retrieval for an audit:

```bash
ls cache/signed_documents/
# SGN-XXXX.pdf

# Verify hash matches audit log:
sha256sum cache/signed_documents/SGN-XXXX.pdf
grep SGN-XXXX cache/audit_log/*.log
```

### Signature verification

Any third party can verify:

1. Open the signed PDF → read the attestation on page 6
2. Extract the `base_hash` from the attestation
3. Regenerate the unsigned version with same inputs
4. Compare SHA-256 of the regenerated unsigned against the recorded base_hash

If they match, the signature is bound to the exact document the client saw.
