# Deployment

Step-by-step guide to getting Mebusan live on Hostinger from a clean checkout. Read once end-to-end before touching anything.

## Prerequisites

- Hostinger account with Business or higher plan (Premium may work, Business gives more headroom)
- Domain `mebusan.com` pointed to Hostinger nameservers
- SSH access enabled on your plan (Hostinger hPanel → Advanced → SSH Access)
- Local machine with `ssh`, `rsync`, `openssl`

## Phase 1: Domain & DNS

### 1.1 Point the domain

In Hostinger hPanel, ensure `mebusan.com` resolves to your shared IP. Verify:

```bash
dig mebusan.com +short
```

### 1.2 DNS records for email

Before any email send, publish:

- **SPF** — `TXT mebusan.com "v=spf1 include:_spf.resend.com ~all"` (for Resend)
- **DKIM** — 1–3 CNAME records from your mail provider's verification page
- **DMARC** — `TXT _dmarc.mebusan.com "v=DMARC1; p=quarantine; rua=mailto:dmarc@mebusan.com"`
- **MX** — set to Hostinger's default or your mail provider's (Resend receive is not needed for transactional)

Verify:

```bash
dig TXT mebusan.com +short        # should show v=spf1
dig TXT _dmarc.mebusan.com +short # should show v=DMARC1
```

### 1.3 SSL

Hostinger auto-provisions Let's Encrypt. Verify:

```bash
curl -I https://mebusan.com
# Expect: HTTP/2 200 + valid cert
```

If not auto-provisioned, hPanel → SSL → Install SSL.

## Phase 2: Environment

### 2.1 Clone the repo locally

```bash
git clone git@github.com:YOUR/mebusan.git
cd mebusan
```

### 2.2 Generate secrets

```bash
cp .env.example .env
./scripts/generate-secrets.sh >> .env
```

This adds `MEBUSAN_SECRET`, `MEBUSAN_INTERNAL_KEY`, `UNSUB_SECRET` to `.env`.

### 2.3 Fill remaining values

Edit `.env` and add:

- **Stripe** — live secret key, webhook secret, six price IDs
- **Twilio** — account SID, auth token, from-number, callback base
- **Mail provider** — API key
- **Anthropic** — API key (for AI analyst backbone)
- **Admin password hash** — generate with:

  ```bash
  php -r "echo password_hash('YOUR_ADMIN_PASSWORD_HERE', PASSWORD_BCRYPT);"
  ```

### 2.4 Configure SSH to Hostinger

On Hostinger hPanel → SSH Access, note: host, port, username.

Generate an SSH key (if you don't have one):

```bash
ssh-keygen -t ed25519 -f ~/.ssh/mebusan_ed25519 -C "mebusan-deploy"
```

Upload the public key to Hostinger (hPanel → SSH Access → Add key).

Add to `~/.ssh/config`:

```
Host mebusan
    HostName <your-hostinger-ssh-host>
    User <your-hostinger-username>
    Port <your-hostinger-port>
    IdentityFile ~/.ssh/mebusan_ed25519
    ServerAliveInterval 60
```

Test:

```bash
ssh mebusan
# Should drop you into ~/public_html or similar
```

## Phase 3: Stripe products

Create six products in Stripe dashboard:

| Product | Monthly price | Annual price |
|---|---|---|
| Monitor | $290 recurring | $2,940 annually (shown as $245/mo) |
| Advisory | $690 recurring | $7,020 annually (shown as $585/mo) |
| Private | $1,200 recurring | $12,240 annually (shown as $1,020/mo) |

Copy the six `price_...` IDs into `.env`.

Create webhook endpoint:

- URL: `https://mebusan.com/api/stripe-webhook.php`
- Events: `invoice.paid`, `invoice.payment_failed`, `customer.source.expiring`, `customer.subscription.updated`, `customer.subscription.deleted`, `checkout.session.completed`
- Copy the signing secret (`whsec_...`) to `.env`

## Phase 4: First deploy

### 4.1 Transfer env to host

Option A: Set via Hostinger hPanel → Advanced → PHP Configuration → Variables (cleanest).

Option B: Copy `.env` to the host, load from PHP:

```bash
rsync -av .env mebusan:~/public_html/.env
# Add a bootstrap that loads .env on every request — see website/api/_security.php
```

### 4.2 Run deploy

```bash
./scripts/deploy.sh
```

This rsyncs `website/` → `~/public_html/` on the host, excluding runtime state dirs.

### 4.3 Run post-deploy on host

```bash
ssh mebusan 'cd ~/public_html && bash scripts/post-deploy.sh'
```

This creates all writable cache dirs, sets permissions, verifies critical files, PHP-lints the security layer.

### 4.4 Smoke test

```bash
# Homepage
curl -I https://mebusan.com/
# Expect: 200, HSTS header, CSP header

# API health
curl https://mebusan.com/api/status.php
# Expect: {"ok":true,"time":"..."}

# Check security headers
curl -I https://mebusan.com/ | grep -iE '(strict-transport|content-security|x-frame|x-content)'
```

## Phase 5: Cron

In Hostinger hPanel → Cron Jobs, add three jobs:

```cron
# Hourly signal ingestion
0 * * * * cd /home/USER/public_html && php api/ingest-signals.php >> cache/email_log/cron.log 2>&1

# 5-minute main cron
*/5 * * * * cd /home/USER/public_html && php api/cron.php >> cache/email_log/cron.log 2>&1

# 5-minute email queue
*/5 * * * * cd /home/USER/public_html && php emails/queue.php >> cache/email_log/cron.log 2>&1
```

Replace `USER` with your Hostinger username (find it in `~/` on the host).

## Phase 6: Verification

### 6.1 Deliverability

```bash
php scripts/test-email.php you@yourself.com welcome-01-immediate
```

Check:

- Lands in Gmail **Primary**, not Promotions
- Lands in Outlook Inbox, not Junk
- HD logo renders inline
- PDF attachment opens cleanly
- Unsubscribe link works (preferences page loads)

Run [mail-tester.com](https://mail-tester.com) test. Target: **≥ 9/10**.

### 6.2 Sign flow

1. Trigger a test signup (test Stripe card: `4242 4242 4242 4242`)
2. Check inbox for engagement-sign-required
3. Click "Review and sign" → page loads with embedded PDF
4. Sign with mouse/finger → submit
5. Check inbox for engagement-signed email
6. Check `/home/USER/public_html/cache/signed_documents/SGN-XXXX.pdf` exists
7. Check audit log: `tail -5 cache/audit_log/$(date +%Y-%m).log`

### 6.3 Critical alert pipeline

```bash
curl -X POST https://mebusan.com/api/alert-call.php \
  -H "X-Mebusan-Key: $MEBUSAN_INTERNAL_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "phone": "+YOUR_PHONE_E164",
    "client_id": "TEST",
    "jurisdiction": "Test Coverage",
    "headline": "Test alert — please ignore",
    "analyst_phone": "+YOUR_PHONE_E164",
    "client_name": "Test"
  }'
```

Your phone should ring within 30 seconds. Answer, hear the Mebusan voice script, press 1 to acknowledge.

### 6.4 Admin

Visit `https://mebusan.com/admin/moderate.html`. Log in with `ADMIN_PASSWORD` (the one you hashed). Should land in the moderation UI.

## Phase 7: Ongoing operations

### Daily

- Log into `/admin/moderate.html` and approve/reject pending signals
- Spot-check `cache/email_log/$(date +%Y-%m).log` for any FAILED entries

### Weekly

- Review `cache/audit_log/` for rate-limit trips, CSRF failures, honeypot hits
- Send the weekly briefing (trigger via admin compose tool once built)

### Monthly

- Send monthly summary email
- Rotate Twilio auth token if suspicious activity

### Quarterly

- Sign and publish warrant canary (`warrant-canary.html`)
- Fire `canary-renewed` to all subscribers
- Review deliverability scores (mail-tester)

## Disaster recovery

### If the host is compromised

1. Rotate `MEBUSAN_SECRET` (invalidates all existing HMAC tokens)
2. Rotate all API keys (Stripe, Twilio, Resend, Anthropic)
3. Rotate `ADMIN_PASSWORD_HASH`
4. Review `cache/audit_log/` for the 30 days preceding the incident
5. Let warrant canary lapse at next quarterly if compromise involved legal compulsion
6. Notify affected clients via Signal (analyst-paired only)
7. Redeploy from git + fresh secrets

### If cache dirs are lost

Just run `bash scripts/post-deploy.sh` on the host. It recreates the structure.

### If a specific client signature is lost

The source of truth is the PDF in `cache/signed_documents/<session_id>.pdf`. Without that, the audit log preserves the hash which proves a signature existed but not its content.

**Back up `cache/audit_log/` and `cache/signed_documents/` offsite regularly.** These are the legal record.

## Migrating off Hostinger

The codebase has zero framework lock-in. To move:

1. Any PHP 8.0+ host with Apache (.htaccess) or nginx (translate rewrite rules)
2. SSH access
3. Cron support

Works on: DigitalOcean droplet + Apache, Linode, Vultr, AWS Lightsail, any VPS.

Does NOT work on: serverless (requires persistent filesystem), Heroku (ephemeral filesystem).
